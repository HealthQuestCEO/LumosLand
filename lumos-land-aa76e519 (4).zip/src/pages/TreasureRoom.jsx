
import React, { useState, useEffect } from "react";
import { LumoState } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Trophy, Zap, Coins, Award } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { add } from "date-fns";

export default function TreasureRoom() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [lumoState, setLumoState] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setIsLoading(true);
      const currentUser = await User.me();
      setUser(currentUser);

      let states = await LumoState.filter({ user_email: currentUser.email });
      
      if (states.length > 0) {
        setLumoState(states[0]);
      } else {
        // Create new LumoState if it doesn't exist
        const now = new Date().toISOString();
        const newState = await LumoState.create({
          user_email: currentUser.email,
          lumo_name: "Lumo",
          hunger: 100,
          thirst: 100,
          cleanliness: 100,
          emotional_need: 100, // Added this line
          current_emotion_state: "happy",
          last_fed_time: now,
          last_watered_time: now,
          last_cleaned_time: now,
          last_emotion_change_time: now,
          fly_away_check_time: add(new Date(), { days: 3 }).toISOString(),
          total_coins: 100,
          total_xp: 0
        });
        setLumoState(newState);
      }
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading || !lumoState) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="text-6xl mb-4 animate-bounce">🏆</div>
          <p className="text-[#1165b3] font-semibold">Loading treasure room...</p>
        </div>
      </div>
    );
  }

  const level = Math.floor(lumoState.total_xp / 500) + 1;
  const xpToNextLevel = 500 - (lumoState.total_xp % 500);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("Home"))}
          className="rounded-full"
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-sky-800 text-3xl font-bold">Treasure Room</h1>
          <p className="text-gray-600">Your achievements and progress</p>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6 mb-8">
        <motion.div
          whileHover={{ scale: 1.05 }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="border-2 border-yellow-500/30 bg-gradient-to-br from-yellow-50 to-amber-50">
            <CardHeader>
              <CardTitle className="text-center">
                <Zap className="w-8 h-8 mx-auto mb-2 text-yellow-600" />
                <div className="text-4xl font-bold text-yellow-600">{lumoState.total_xp || 0}</div>
                <div className="text-sm text-gray-600 mt-1">Total XP</div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center space-y-2">
                <p className="text-sm font-medium text-gray-700">Level {level}</p>
                <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-yellow-400 to-amber-500 transition-all duration-500"
                    style={{ width: `${((lumoState.total_xp % 500) / 500) * 100}%` }}
                  />
                </div>
                <p className="text-xs text-gray-500">{xpToNextLevel} XP to Level {level + 1}</p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          whileHover={{ scale: 1.05 }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="border-2 border-orange-500/30 bg-gradient-to-br from-orange-50 to-yellow-50">
            <CardHeader>
              <CardTitle className="text-center">
                <Coins className="w-8 h-8 mx-auto mb-2 text-orange-600" />
                <div className="text-4xl font-bold text-orange-600">{lumoState.total_coins || 0}</div>
                <div className="text-sm text-gray-600 mt-1">Total Coins</div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <p className="text-sm text-gray-600">Keep earning to unlock more items!</p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          whileHover={{ scale: 1.05 }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="border-2 border-[#66bfad]/30 bg-gradient-to-br from-green-50 to-teal-50">
            <CardHeader>
              <CardTitle className="text-center">
                <Trophy className="w-8 h-8 mx-auto mb-2 text-[#66bfad]" />
                <div className="text-4xl font-bold text-[#66bfad]">{lumoState.badges?.length || 0}</div>
                <div className="text-sm text-gray-600 mt-1">Badges Earned</div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <p className="text-sm text-gray-600">Complete challenges to earn badges!</p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <Card className="border-2 border-[#66bfad]/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-[#1165b3]">
            <Award className="w-6 h-6" />
            Achievements & Badges
          </CardTitle>
        </CardHeader>
        <CardContent>
          {lumoState.badges && lumoState.badges.length > 0 ? (
            <div className="grid md:grid-cols-2 gap-4">
              {lumoState.badges.map((badge, index) => (
                <div key={index} className="flex items-center gap-3 p-4 bg-gradient-to-r from-[#e0f8f5] to-white rounded-2xl">
                  <div className="text-4xl">🏆</div>
                  <div>
                    <p className="font-semibold text-[#1165b3]">{badge}</p>
                    <p className="text-sm text-gray-500">Earned!</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Trophy className="w-16 h-16 mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500 mb-4">No badges earned yet. Keep playing to unlock achievements!</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
