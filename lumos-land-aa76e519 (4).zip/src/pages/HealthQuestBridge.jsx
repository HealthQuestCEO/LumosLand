
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Link as LinkIcon, Download, Upload, CheckCircle, AlertCircle, RefreshCw } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function HealthQuestBridge() {
  const navigate = useNavigate();
  
  const [apiUrl, setApiUrl] = useState("https://app.base44.com");
  const [apiKey, setApiKey] = useState("");
  const [connectionStatus, setConnectionStatus] = useState(null);
  const [quests, setQuests] = useState([]);
  const [selectedQuest, setSelectedQuest] = useState(null);
  const [lessons, setLessons] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [syncResults, setSyncResults] = useState(null); // New state for full sync results

  const testConnection = async () => {
    setIsLoading(true);
    setConnectionStatus(null);
    setResult(null); // Clear previous results
    setSyncResults(null); // Clear previous sync results
    try {
      const response = await base44.functions.invoke('healthQuestBridge', {
        action: 'testConnection',
        apiUrl,
        apiKey
      });

      if (response.data.success) {
        setConnectionStatus({ success: true, message: 'Connected successfully!' });
      } else {
        setConnectionStatus({ success: false, message: response.data.error });
      }
    } catch (error) {
      setConnectionStatus({ success: false, message: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  const fetchQuests = async () => {
    setIsLoading(true);
    setResult(null); // Clear previous results
    setSyncResults(null); // Clear previous sync results
    try {
      const response = await base44.functions.invoke('healthQuestBridge', {
        action: 'fetchQuests',
        apiUrl,
        apiKey
      });

      if (response.data.success) {
        setQuests(response.data.quests);
      } else {
        alert('Failed to fetch quests: ' + response.data.error);
      }
    } catch (error) {
      alert('Error fetching quests: ' + error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchLessons = async (questId) => {
    setIsLoading(true);
    setSelectedQuest(questId);
    setResult(null); // Clear previous results
    setSyncResults(null); // Clear previous sync results
    try {
      const response = await base44.functions.invoke('healthQuestBridge', {
        action: 'fetchLessons',
        apiUrl,
        apiKey,
        questId
      });

      if (response.data.success) {
        setLessons(response.data.lessons);
      } else {
        alert('Failed to fetch lessons: ' + response.data.error);
      }
    } catch (error) {
      alert('Error fetching lessons: ' + error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const importLessons = async (questId) => {
    setIsLoading(true);
    setResult(null);
    setSyncResults(null); // Clear previous sync results
    try {
      const response = await base44.functions.invoke('healthQuestBridge', {
        action: 'importLessons',
        apiUrl,
        apiKey,
        questId
      });

      // The backend for importLessons returns 'imported' and 'total'.
      // We will map 'imported' to 'synced' for the generic result display.
      setResult({ ...response.data, synced: response.data.imported });
    } catch (error) {
      setResult({ success: false, error: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  const syncCompletions = async () => {
    setIsLoading(true);
    setResult(null);
    setSyncResults(null); // Clear previous sync results
    try {
      const response = await base44.functions.invoke('healthQuestBridge', {
        action: 'syncCompletions',
        apiUrl,
        apiKey
      });

      setResult(response.data);
    } catch (error) {
      setResult({ success: false, error: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  const syncUserProgress = async () => {
    setIsLoading(true);
    setResult(null);
    setSyncResults(null); // Clear previous sync results
    try {
      const response = await base44.functions.invoke('healthQuestBridge', {
        action: 'syncUserProgress',
        apiUrl,
        apiKey
      });

      setResult(response.data);
    } catch (error) {
      setResult({ success: false, error: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  const syncCareLoop = async () => {
    setIsLoading(true);
    setResult(null);
    setSyncResults(null); // Clear previous sync results
    try {
      const response = await base44.functions.invoke('healthQuestBridge', {
        action: 'syncCareLoop',
        apiUrl,
        apiKey
      });

      setResult(response.data);
    } catch (error) {
      setResult({ success: false, error: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  const fullSync = async () => {
    setIsLoading(true);
    setSyncResults(null);
    setResult(null); // Clear previous individual results
    try {
      const response = await base44.functions.invoke('healthQuestBridge', {
        action: 'fullSync',
        apiUrl,
        apiKey
      });

      setSyncResults(response.data);
    } catch (error) {
      setSyncResults({ success: false, error: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdminPanel"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1165b3]">HealthQuest API Bridge</h1>
          <p className="text-gray-600">Connect and sync with your existing platform</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Connection Setup */}
        <Card>
          <CardHeader>
            <CardTitle>🔗 API Connection</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">API URL</label>
              <Input
                value={apiUrl}
                onChange={(e) => setApiUrl(e.target.value)}
                placeholder="https://app.base44.com"
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">API Key</label>
              <Input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="Your HealthQuest API key"
              />
            </div>

            <Button
              onClick={testConnection}
              disabled={isLoading || !apiUrl || !apiKey}
              className="w-full bg-[#1165b3]"
            >
              <LinkIcon className="w-4 h-4 mr-2" />
              Test Connection
            </Button>

            {connectionStatus && (
              <Alert className={connectionStatus.success ? "bg-green-50 border-green-300" : "bg-red-50 border-red-300"}>
                {connectionStatus.success ? <CheckCircle className="h-4 w-4 text-green-600" /> : <AlertCircle className="h-4 w-4 text-red-600" />}
                <AlertDescription className={connectionStatus.success ? "text-green-800" : "text-red-800"}>
                  {connectionStatus.message}
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* Instructions */}
        <Card>
          <CardHeader>
            <CardTitle>📋 Setup Instructions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-sm space-y-2">
              <p><strong>Required API Endpoints:</strong></p>
              <ul className="list-disc list-inside space-y-1 text-gray-600">
                <li><code>GET /api/health</code> - Health check</li>
                <li><code>GET /api/quests</code> - List all quests</li>
                <li><code>GET /api/quests/:id/lessons</code> - Get lessons for quest</li>
                <li><code>POST /api/completions</code> - Sync completion data</li>
                <li><code>POST /api/user-progress</code> - Sync coins, XP, levels, badges</li>
                <li><code>POST /api/care-loop</code> - Sync emotion checks, naps, journal entries</li>
                <li><code>POST /api/full-sync</code> - Perform all sync actions</li>
              </ul>
            </div>

            <div className="text-sm space-y-2">
              <p><strong>Expected Lesson Format:</strong></p>
              <pre className="bg-gray-100 p-2 rounded text-xs overflow-x-auto">{`{
  "quest_id": "string",
  "lesson_number": 1,
  "title": "string",
  "game_format": "mcq|matching",
  "game_style": "bubble_pop|pin_mountain|glass_bridge",
  "questions": [...]
}`}</pre>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Import Section */}
      {connectionStatus?.success && (
        <Card className="mt-6">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>📥 Import Lessons</CardTitle>
              <Button
                onClick={fetchQuests}
                disabled={isLoading}
                variant="outline"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Fetch Quests
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {quests.length === 0 ? (
              <p className="text-gray-600 text-center py-8">
                Click "Fetch Quests" to load available content
              </p>
            ) : (
              <div className="grid md:grid-cols-2 gap-4">
                {quests.map((quest) => (
                  <Card key={quest.id} className="border-2 hover:border-[#66bfad] transition-all">
                    <CardHeader>
                      <CardTitle className="text-lg">{quest.name}</CardTitle>
                      <Badge>{quest.lesson_count || 0} lessons</Badge>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <Button
                        onClick={() => fetchLessons(quest.id)}
                        variant="outline"
                        className="w-full"
                        disabled={isLoading}
                      >
                        <Download className="w-4 h-4 mr-2" />
                        View Lessons
                      </Button>
                      <Button
                        onClick={() => importLessons(quest.id)}
                        className="w-full bg-[#66bfad]"
                        disabled={isLoading}
                      >
                        <Upload className="w-4 h-4 mr-2" />
                        Import to Lumo
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {lessons.length > 0 && (
              <div className="mt-6">
                <h3 className="font-bold mb-4">Preview: {lessons.length} lessons</h3>
                <div className="space-y-2 max-h-[300px] overflow-y-auto">
                  {lessons.map((lesson, idx) => (
                    <div key={idx} className="p-3 bg-gray-50 rounded">
                      <p className="font-medium">{lesson.title || lesson.name}</p>
                      <p className="text-sm text-gray-600">{lesson.game_style} - {lesson.game_format}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* NEW: Sync Progress Section */}
      {connectionStatus?.success && (
        <div className="grid md:grid-cols-3 gap-6 mt-6">
          {/* Sync Completions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">📚 Lesson Completions</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-4">
                Sync lesson completion data to HealthQuest
              </p>
              <Button
                onClick={syncCompletions}
                disabled={isLoading}
                className="w-full bg-[#66bfad]"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Sync Completions
              </Button>
            </CardContent>
          </Card>

          {/* Sync User Progress */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">🏆 User Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-4">
                Sync coins, XP, levels, and badges
              </p>
              <Button
                onClick={syncUserProgress}
                disabled={isLoading}
                className="w-full bg-[#ffa400]"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Sync Progress
              </Button>
            </CardContent>
          </Card>

          {/* Sync Care Loop */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">💖 Care Loop Data</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-4">
                Sync emotion checks, naps, journal entries
              </p>
              <Button
                onClick={syncCareLoop}
                disabled={isLoading}
                className="w-full bg-[#1165b3]"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Sync Care Loop
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* NEW: Full Sync Button */}
      {connectionStatus?.success && (
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>🔄 Full Bidirectional Sync</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">
              Sync ALL data (lessons, completions, user progress, care loop) between Lumo's Land and HealthQuest in one go.
            </p>
            <Button
              onClick={fullSync}
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-[#1165b3] to-[#66bfad] text-white text-lg py-6"
            >
              <RefreshCw className="w-5 h-5 mr-2" />
              {isLoading ? "Syncing..." : "Run Full Sync"}
            </Button>

            {syncResults && (
              <div className="mt-6 space-y-4">
                {syncResults.success ? (
                  <>
                    <Alert className="bg-green-50 border-green-300">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <AlertDescription className="text-green-800">
                        <strong>Sync Complete!</strong>
                        {syncResults.message && <p>{syncResults.message}</p>}
                      </AlertDescription>
                    </Alert>

                    <div className="grid md:grid-cols-3 gap-4">
                      {syncResults.results.completions && (
                        <Card className="border-2 border-green-200">
                          <CardContent className="pt-6">
                            <p className="text-sm font-semibold text-gray-700">Completions</p>
                            <p className="text-2xl font-bold text-green-600">{syncResults.results.completions.synced}</p>
                            <p className="text-xs text-gray-500">synced</p>
                          </CardContent>
                        </Card>
                      )}

                      {syncResults.results.userProgress && (
                        <Card className="border-2 border-orange-200">
                          <CardContent className="pt-6">
                            <p className="text-sm font-semibold text-gray-700">User Progress</p>
                            <p className="text-2xl font-bold text-orange-600">{syncResults.results.userProgress.synced}</p>
                            <p className="text-xs text-gray-500">synced</p>
                          </CardContent>
                        </Card>
                      )}

                      {syncResults.results.careLoop && (
                        <Card className="border-2 border-blue-200">
                          <CardContent className="pt-6">
                            <p className="text-sm font-semibold text-gray-700">Care Loop</p>
                            <p className="text-2xl font-bold text-blue-600">{syncResults.results.careLoop.synced}</p>
                            <p className="text-xs text-gray-500">synced</p>
                          </CardContent>
                        </Card>
                      )}
                    </div>
                    {/* Display errors if any part of the full sync had issues */}
                    {syncResults.errors && Object.keys(syncResults.errors).length > 0 && (
                      <Alert className="bg-orange-50 border-orange-300">
                        <AlertCircle className="h-4 w-4 text-orange-600" />
                        <AlertDescription className="text-orange-800">
                          <p className="font-semibold">Some Errors Occurred:</p>
                          {Object.entries(syncResults.errors).map(([key, value]) => (
                            <p key={key} className="text-xs mt-1">
                              <strong>{key}:</strong> {JSON.stringify(value)}
                            </p>
                          ))}
                        </AlertDescription>
                      </Alert>
                    )}
                  </>
                ) : (
                  <Alert className="bg-red-50 border-red-300">
                    <AlertCircle className="h-4 w-4 text-red-600" />
                    <AlertDescription className="text-red-800">
                      <p className="font-semibold">Full Sync Failed!</p>
                      <p>{syncResults.error}</p>
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Regular result display for individual sync operations (Import, Completions, User Progress, Care Loop) */}
      {result && !syncResults && (
        <Alert className={result.success ? "bg-green-50 border-green-300 mt-6" : "bg-red-50 border-red-300 mt-6"}>
          {result.success ? <CheckCircle className="h-4 w-4 text-green-600" /> : <AlertCircle className="h-4 w-4 text-red-600" />}
          <AlertDescription className={result.success ? "text-green-800" : "text-red-800"}>
            {result.success ? (
              <div>
                <p className="font-semibold">Success!</p>
                {result.message && <p>{result.message}</p>}
                {(result.synced !== undefined || result.imported !== undefined) && (
                  <p>Synced {result.synced || result.imported} of {result.total} items</p>
                )}
                {result.errors && result.errors.length > 0 && (
                  <details className="mt-2">
                    <summary className="cursor-pointer font-semibold">View Errors ({result.errors.length})</summary>
                    {result.errors.map((err, i) => (
                      <p key={i} className="text-xs mt-1">{err}</p>
                    ))}
                  </details>
                )}
              </div>
            ) : (
              <p>{result.error}</p>
            )}
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}
