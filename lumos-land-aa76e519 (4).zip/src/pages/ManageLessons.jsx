import React, { useState, useEffect } from "react";
import { GameLesson } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Trash2, AlertCircle, FileJson } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ManageLessons() {
  const navigate = useNavigate();
  const [lessons, setLessons] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    loadLessons();
  }, []);

  const loadLessons = async () => {
    try {
      setIsLoading(true);
      const allLessons = await GameLesson.list();
      setLessons(allLessons.sort((a, b) => (a.number || 0) - (b.number || 0)));
    } catch (error) {
      console.error("Error loading lessons:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteAll = async () => {
    if (!confirm(`Are you sure you want to delete ALL ${lessons.length} lessons? This cannot be undone!`)) {
      return;
    }

    setIsDeleting(true);
    try {
      for (const lesson of lessons) {
        await GameLesson.delete(lesson.id);
      }
      alert("All lessons deleted successfully!");
      await loadLessons();
    } catch (error) {
      console.error("Error deleting lessons:", error);
      alert("Error: " + error.message);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleDeleteOne = async (lesson) => {
    if (!confirm(`Delete lesson ${lesson.number}: ${lesson.name}?`)) {
      return;
    }

    try {
      await GameLesson.delete(lesson.id);
      alert("Lesson deleted!");
      await loadLessons();
    } catch (error) {
      console.error("Error deleting lesson:", error);
      alert("Error: " + error.message);
    }
  };

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  return (
    <div className="max-w-6xl mx-auto p-8">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Manage Lessons</CardTitle>
          <p className="text-sm text-gray-600 mt-2">
            View and delete existing lessons. Use{" "}
            <button
              onClick={() => navigate(createPageUrl("ImportLessons"))}
              className="text-blue-600 underline hover:text-blue-800"
            >
              Import Lessons
            </button>
            {" "}to upload new lessons from JSON.
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          <Alert className="bg-yellow-50 border-yellow-200">
            <AlertCircle className="h-4 w-4 text-yellow-600" />
            <AlertDescription className="text-yellow-800">
              <strong>Found {lessons.length} lessons</strong>
              <div className="mt-2">
                Before importing new lessons, delete all existing lessons to avoid duplicates and ID issues.
              </div>
            </AlertDescription>
          </Alert>

          <div className="flex gap-4">
            <Button
              onClick={handleDeleteAll}
              disabled={isDeleting || lessons.length === 0}
              variant="destructive"
              className="flex-1"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              {isDeleting ? "Deleting..." : `Delete All ${lessons.length} Lessons`}
            </Button>

            <Button
              onClick={() => navigate(createPageUrl("ImportLessons"))}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              <FileJson className="w-4 h-4 mr-2" />
              Import New Lessons
            </Button>
          </div>

          {lessons.length > 0 && (
            <div className="space-y-2">
              <h3 className="font-semibold">Current Lessons:</h3>
              {lessons.map((lesson) => (
                <div
                  key={lesson.id}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                >
                  <div className="flex-1">
                    <span className="font-semibold">Lesson {lesson.number}:</span> {lesson.name}
                    <span className="text-xs text-gray-500 ml-2">(ID: {lesson.id})</span>
                  </div>
                  <Button
                    onClick={() => handleDeleteOne(lesson)}
                    variant="ghost"
                    size="sm"
                    className="text-red-600 hover:text-red-800"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}