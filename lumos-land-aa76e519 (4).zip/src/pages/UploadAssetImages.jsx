import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle2, Upload, Copy, Image as ImageIcon, ArrowLeft, AlertCircle, Download, Trash2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

const ASSET_CATEGORIES = [
  { value: "lumo_emotions", label: "Lumo - Emotions", description: "Happy, sad, angry, brave, etc." },
  { value: "lumo_needs", label: "Lumo - Physical Needs", description: "Hungry, thirsty, dirty" },
  { value: "lumo_outfits", label: "Lumo - Wearing Outfits", description: "Lumo wearing items from Nook" },
  { value: "backgrounds", label: "Backgrounds", description: "Seasonal backgrounds, room backgrounds" },
  { value: "shop_items", label: "Shop Items", description: "Items for Lumo's Nook" },
  { value: "badges", label: "Badges & Awards", description: "Achievement badges" },
  { value: "npcs", label: "NPCs", description: "Glow Ridge characters" },
  { value: "ui_elements", label: "UI Elements", description: "Buttons, icons, decorations" },
  { value: "other", label: "Other", description: "Miscellaneous assets" }
];

export default function UploadAssetImages() {
  const navigate = useNavigate();
  const [uploading, setUploading] = useState(false);
  const [uploadedImages, setUploadedImages] = useState([]);
  const [status, setStatus] = useState({ type: "", message: "" });
  const [selectedCategory, setSelectedCategory] = useState("other");
  const [filterCategory, setFilterCategory] = useState("all");

  const handleFileUpload = async (event) => {
    const files = Array.from(event.target.files || []);
    if (files.length === 0) return;

    if (!selectedCategory) {
      setStatus({ type: "error", message: "Please select a category first!" });
      return;
    }

    setUploading(true);
    setStatus({ type: "", message: "" });
    
    const results = [];

    try {
      for (const file of files) {
        // Validate file type
        if (!file.type.startsWith('image/')) {
          results.push({
            name: file.name,
            category: selectedCategory,
            error: "Not an image file",
            url: null,
            uploadDate: new Date().toISOString()
          });
          continue;
        }

        // Validate file size (max 10MB for high-quality Lumo images)
        if (file.size > 10 * 1024 * 1024) {
          results.push({
            name: file.name,
            category: selectedCategory,
            error: "File too large (max 10MB)",
            url: null,
            uploadDate: new Date().toISOString()
          });
          continue;
        }

        try {
          const response = await base44.integrations.Core.UploadFile({ file });
          results.push({
            name: file.name,
            category: selectedCategory,
            url: response.file_url,
            error: null,
            uploadDate: new Date().toISOString(),
            size: (file.size / 1024).toFixed(2) + " KB"
          });
        } catch (err) {
          results.push({
            name: file.name,
            category: selectedCategory,
            error: err.message,
            url: null,
            uploadDate: new Date().toISOString()
          });
        }
      }

      setUploadedImages([...results, ...uploadedImages]);
      
      const successCount = results.filter(r => r.url).length;
      const errorCount = results.filter(r => r.error).length;
      
      if (successCount > 0) {
        setStatus({ 
          type: "success", 
          message: `✅ Uploaded ${successCount} image(s) to ${ASSET_CATEGORIES.find(c => c.value === selectedCategory)?.label}! ${errorCount > 0 ? `${errorCount} failed.` : ''}` 
        });
      } else {
        setStatus({ type: "error", message: "All uploads failed. Check file types and sizes." });
      }
    } catch (error) {
      setStatus({ type: "error", message: `Upload error: ${error.message}` });
    } finally {
      setUploading(false);
    }
  };

  const copyToClipboard = (url) => {
    navigator.clipboard.writeText(url);
    setStatus({ type: "success", message: "✅ URL copied to clipboard!" });
  };

  const deleteImage = (index) => {
    if (confirm("Remove this image from the list? (Note: The file will still exist in storage)")) {
      const newImages = [...uploadedImages];
      newImages.splice(index, 1);
      setUploadedImages(newImages);
    }
  };

  const exportJson = () => {
    const jsonData = uploadedImages
      .filter(img => img.url)
      .map(img => ({
        file_name: img.name,
        category: img.category,
        image_url: img.url,
        upload_date: img.uploadDate,
        size: img.size
      }));
    
    const dataStr = JSON.stringify(jsonData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'uploaded_images.json';
    link.click();
    URL.revokeObjectURL(url);
    setStatus({ type: "success", message: "✅ Exported URLs to JSON!" });
  };

  const filteredImages = filterCategory === "all" 
    ? uploadedImages 
    : uploadedImages.filter(img => img.category === filterCategory);

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdminPanel"))}
          className="rounded-full"
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1165b3]">🖼️ Upload Asset Images</h1>
          <p className="text-gray-600">Upload and manage ALL app images - Lumo, backgrounds, items, NPCs, etc.</p>
        </div>
      </div>

      {status.message && (
        <Alert className={`mb-6 ${
          status.type === "success" ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"
        }`}>
          {status.type === "success" ? <CheckCircle2 className="h-4 w-4 text-green-600" /> : <AlertCircle className="h-4 w-4 text-red-600" />}
          <AlertDescription className={status.type === "success" ? "text-green-800" : "text-red-800"}>
            {status.message}
          </AlertDescription>
        </Alert>
      )}

      {/* Upload Section */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>📤 Upload New Images</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              1. Select Asset Category
            </label>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Choose category..." />
              </SelectTrigger>
              <SelectContent>
                {ASSET_CATEGORIES.map(cat => (
                  <SelectItem key={cat.value} value={cat.value}>
                    <div>
                      <div className="font-semibold">{cat.label}</div>
                      <div className="text-xs text-gray-500">{cat.description}</div>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              2. Upload Images (Max 10MB each)
            </label>
            <input
              type="file"
              accept="image/*"
              multiple
              onChange={handleFileUpload}
              disabled={uploading || !selectedCategory}
              className="hidden"
              id="image-upload"
            />
            <label htmlFor="image-upload">
              <Button
                as="span"
                disabled={uploading || !selectedCategory}
                className="w-full bg-gradient-to-r from-[#66bfad] to-[#1165b3] text-white cursor-pointer"
              >
                <Upload className="w-4 h-4 mr-2" />
                {uploading ? "Uploading..." : "Choose Images to Upload"}
              </Button>
            </label>
            <p className="text-xs text-gray-500 mt-2">
              Supports: PNG, JPG, GIF, WebP • Max 10MB per file • Can select multiple files
            </p>
          </div>

          {uploadedImages.filter(img => img.url).length > 0 && (
            <Button
              onClick={exportJson}
              variant="outline"
              className="w-full"
            >
              <Download className="w-4 h-4 mr-2" />
              Export All URLs to JSON
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Uploaded Images Library */}
      {uploadedImages.length > 0 && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>📚 Uploaded Images Library ({filteredImages.length})</CardTitle>
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Filter by category..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {ASSET_CATEGORIES.map(cat => (
                    <SelectItem key={cat.value} value={cat.value}>
                      {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              {filteredImages.map((image, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className={`border-2 rounded-xl p-4 ${
                    image.error 
                      ? "border-red-300 bg-red-50" 
                      : "border-[#66bfad]/30 bg-white hover:shadow-lg transition-all"
                  }`}
                >
                  {image.url ? (
                    <>
                      <div className="flex items-start gap-4 mb-3">
                        <img 
                          src={image.url} 
                          alt={image.name}
                          className="w-24 h-24 object-cover rounded-lg border-2 border-gray-200"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between mb-1">
                            <h3 className="font-bold text-[#1165b3] truncate">{image.name}</h3>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => deleteImage(idx)}
                              className="text-red-500 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                          <p className="text-xs text-gray-500 mb-2">
                            {ASSET_CATEGORIES.find(c => c.value === image.category)?.label || image.category}
                          </p>
                          {image.size && (
                            <p className="text-xs text-gray-400">{image.size}</p>
                          )}
                        </div>
                      </div>
                      <div className="bg-gray-50 rounded p-2 mb-2">
                        <code className="text-xs text-gray-700 break-all">{image.url}</code>
                      </div>
                      <Button
                        onClick={() => copyToClipboard(image.url)}
                        size="sm"
                        className="w-full bg-[#66bfad] hover:bg-[#66bfad]/90 text-white"
                      >
                        <Copy className="w-3 h-3 mr-2" />
                        Copy URL
                      </Button>
                    </>
                  ) : (
                    <div className="flex items-center gap-3">
                      <AlertCircle className="w-5 h-5 text-red-500" />
                      <div>
                        <p className="font-semibold text-red-700">{image.name}</p>
                        <p className="text-sm text-red-600">{image.error}</p>
                      </div>
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Usage Guide */}
      <Card className="mt-6 border-2 border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="text-blue-800">📖 Asset Management Guide</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-sm text-blue-900">
          <div className="bg-white p-4 rounded-lg border border-blue-200">
            <h4 className="font-bold mb-2">🎨 Lumo Character Images</h4>
            <p>Upload new Lumo emotions, needs states, or Lumo wearing outfits. Use these URLs in:</p>
            <ul className="list-disc list-inside mt-2 space-y-1 text-xs">
              <li><code>components/lumo/LumoCharacter.jsx</code> - Update STATE_ASSETS object</li>
              <li>Shop items - For outfit previews</li>
            </ul>
          </div>

          <div className="bg-white p-4 rounded-lg border border-blue-200">
            <h4 className="font-bold mb-2">🏞️ Background Images</h4>
            <p>Seasonal backgrounds, room backgrounds. Update in:</p>
            <ul className="list-disc list-inside mt-2 space-y-1 text-xs">
              <li><code>components/lumo/LumoCharacter.jsx</code> - SEASONAL_BACKGROUNDS</li>
              <li>Castle rooms - Background images for each room</li>
            </ul>
          </div>

          <div className="bg-white p-4 rounded-lg border border-blue-200">
            <h4 className="font-bold mb-2">🛍️ Shop Items & Badges</h4>
            <p>Use the URL in your JSON imports:</p>
            <pre className="bg-blue-900 text-blue-100 p-2 rounded text-xs mt-2 overflow-x-auto">
{`{
  "item_id": "golden_crown",
  "item_name": "Golden Crown",
  "image_url": "YOUR_UPLOADED_URL_HERE",
  "price": 100
}`}
            </pre>
          </div>

          <div className="bg-amber-50 border border-amber-300 p-3 rounded-lg">
            <p className="text-amber-900">
              <strong>💡 Pro Tips:</strong>
            </p>
            <ul className="list-disc list-inside mt-2 space-y-1 text-xs text-amber-800">
              <li>Use PNG for transparency (Lumo images, items)</li>
              <li>Use JPG for photographs/backgrounds (smaller file size)</li>
              <li>Organize with categories for easy finding later</li>
              <li>Export to JSON to keep a backup of all your URLs</li>
              <li>Images are permanently stored - URLs never expire!</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}