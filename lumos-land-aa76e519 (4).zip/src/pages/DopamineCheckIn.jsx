import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import DopaminePauseScreen from "../components/dopamine/DopaminePauseScreen";
import DopamineFeelingsGrid from "../components/dopamine/DopamineFeelingsGrid";
import DopamineActivityScreen from "../components/dopamine/DopamineActivityScreen";
import DopamineReassessScreen from "../components/dopamine/DopamineReassessScreen";
import DopamineRewardScreen from "../components/dopamine/DopamineRewardScreen";

export default function DopamineCheckIn() {
  const [currentStep, setCurrentStep] = useState("loading");
  const [contentData, setContentData] = useState(null);
  const [sessionId, setSessionId] = useState(null);
  const [selectedFeeling, setSelectedFeeling] = useState(null);
  const [coinsEarned, setCoinsEarned] = useState(0);
  const [xpEarned, setXpEarned] = useState(0);
  const [activityStartTime, setActivityStartTime] = useState(null);

  useEffect(() => {
    loadContent();
  }, []);

  const loadContent = async () => {
    try {
      const response = await base44.functions.invoke('dopamineCheckin', {
        action: 'getContent'
      });
      setContentData(response.data);
      setCurrentStep("pause");
    } catch (error) {
      console.error("Error loading content:", error);
    }
  };

  const createSession = async () => {
    try {
      const response = await base44.functions.invoke('dopamineCheckin', {
        action: 'createSession'
      });
      setSessionId(response.data.session_id);
    } catch (error) {
      console.error("Error creating session:", error);
    }
  };

  const handlePauseYes = () => {
    alert("Great! Go grab a healthy snack 🥕");
  };

  const handlePauseNo = async () => {
    await createSession();
    setCurrentStep("feelings");
  };

  const handleSelectFeeling = async (feeling) => {
    setSelectedFeeling(feeling);
    
    try {
      await base44.functions.invoke('dopamineCheckin', {
        action: 'selectFeeling',
        sessionData: {
          session_id: sessionId,
          feeling_id: feeling.feeling_id
        }
      });
      
      setCurrentStep("activities");
    } catch (error) {
      console.error("Error selecting feeling:", error);
    }
  };

  const handleActivityComplete = async (activity, actualDuration) => {
    try {
      // Start activity tracking
      await base44.functions.invoke('dopamineCheckin', {
        action: 'startActivity',
        sessionData: {
          session_id: sessionId,
          activity_id: activity.activity_id,
          target_duration_sec: activity.preset_seconds
        }
      });

      // Complete activity and get coins
      const response = await base44.functions.invoke('dopamineCheckin', {
        action: 'completeActivity',
        sessionData: {
          session_id: sessionId,
          activity_id: activity.activity_id,
          actual_duration_sec: actualDuration
        }
      });

      setCoinsEarned(response.data.coins_earned);
      setCurrentStep("reassess");
    } catch (error) {
      console.error("Error completing activity:", error);
    }
  };

  const handleReassessSubmit = async (stillWantsSnack) => {
    try {
      const response = await base44.functions.invoke('dopamineCheckin', {
        action: 'submitReassess',
        sessionData: {
          session_id: sessionId,
          still_wants_snack: stillWantsSnack
        }
      });

      setXpEarned(response.data.xp_earned);
      setCurrentStep("rewards");
    } catch (error) {
      console.error("Error submitting reassess:", error);
    }
  };

  if (currentStep === "loading") {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-[#e0f8f5] to-[#66bfad]/20">
        <div className="text-center">
          <div className="text-6xl mb-4 animate-bounce">🧠</div>
          <p className="text-[#1165b3] font-semibold">Loading...</p>
        </div>
      </div>
    );
  }

  if (currentStep === "pause") {
    return (
      <DopaminePauseScreen
        content={contentData?.flow?.step1_pause_check}
        onYes={handlePauseYes}
        onNo={handlePauseNo}
      />
    );
  }

  if (currentStep === "feelings") {
    return (
      <DopamineFeelingsGrid
        feelings={contentData?.feelings}
        onSelectFeeling={handleSelectFeeling}
      />
    );
  }

  if (currentStep === "activities") {
    return (
      <DopamineActivityScreen
        activities={selectedFeeling?.activities}
        onComplete={handleActivityComplete}
      />
    );
  }

  if (currentStep === "reassess") {
    return (
      <DopamineReassessScreen
        content={contentData?.reassess}
        onSubmit={handleReassessSubmit}
      />
    );
  }

  if (currentStep === "rewards") {
    return (
      <DopamineRewardScreen
        coinsEarned={coinsEarned}
        xpEarned={xpEarned}
      />
    );
  }

  return null;
}