
import React, { useState, useEffect } from "react";
import { LumoState, JournalEntry, ActivityLog } from "@/api/entities";
import { User } from "@/api/entities";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, BookOpen, Bed, Sparkles, Home as HomeIcon, Shirt } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import JournalTab from "../components/castle/JournalTab";
import BedroomTab from "../components/castle/BedroomTab";
import StyleChamberTab from "../components/castle/StyleChamberTab";
import LivingRoomTab from "../components/castle/LivingRoomTab";
import HalloweenRoomTab from "../components/castle/HalloweenRoomTab";
import AtticTab from "../components/castle/AtticTab";
import ClassroomTab from "../components/castle/ClassroomTab"; // Added ClassroomTab import

export default function LumosCastle() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [lumoState, setLumoState] = useState(null);
  const [activityLog, setActivityLog] = useState(null);
  const [activeTab, setActiveTab] = useState("bedroom"); // Changed initial activeTab to "bedroom"
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setIsLoading(true);
      const currentUser = await User.me();
      setUser(currentUser);

      const states = await LumoState.filter({ user_email: currentUser.email });
      if (states.length > 0) {
        setLumoState(states[0]);
      }

      const today = new Date().toISOString().split('T')[0];
      const logs = await ActivityLog.filter({ user_email: currentUser.email, activity_date: today });
      if (logs.length > 0) {
        setActivityLog(logs[0]);
      } else {
        const newLog = await ActivityLog.create({
          user_email: currentUser.email,
          activity_date: today,
          lessons_completed: 0,
          journal_entries: 0,
          npc_interactions: 0,
          naps_taken: 0,
          emotion_recognitions: 0
        });
        setActivityLog(newLog);
      }
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  const tabs = [
    { id: "bedroom", label: "Bedroom", icon: Bed },
    { id: "style_chamber", label: "Style Chamber", icon: Shirt },
    { id: "living_room", label: "Living Room", icon: HomeIcon },
    { id: "classroom", label: "Classroom", icon: BookOpen }, // Added Classroom tab
    { id: "halloween_room", label: "Special Items", icon: Sparkles },
    { id: "attic", label: "Attic", icon: Sparkles },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("Home"))}
          className="rounded-full"
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[var(--color-primary-blue)]">🏰 Lumo's Castle</h1>
          <p className="text-gray-600">Rest, reflect, and recharge</p>
        </div>
      </div>

      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <Button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`rounded-2xl py-6 px-4 flex items-center gap-2 whitespace-nowrap ${
                activeTab === tab.id
                  ? "bg-gradient-to-r from-[#66b6ad] to-[#66b6ad]/80 text-white"
                  : "bg-white text-gray-600 border-2 border-gray-200"
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="hidden sm:inline">{tab.label}</span>
            </Button>
          );
        })}
      </div>

      <motion.div
        key={activeTab}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        {activeTab === "bedroom" && (
          <BedroomTab 
            user={user} 
            lumoState={lumoState} 
            activityLog={activityLog} 
            onUpdate={loadData} 
          />
        )}
        {activeTab === "style_chamber" && (
          <StyleChamberTab user={user} onUpdate={loadData} />
        )}
        {activeTab === "living_room" && (
          <LivingRoomTab user={user} onUpdate={loadData} />
        )}
        {activeTab === "classroom" && ( // Added ClassroomTab rendering
          <ClassroomTab user={user} onUpdate={loadData} />
        )}
        {activeTab === "halloween_room" && (
          <HalloweenRoomTab user={user} onUpdate={loadData} />
        )}
        {activeTab === "attic" && (
          <AtticTab user={user} onUpdate={loadData} />
        )}
      </motion.div>
    </div>
  );
}
