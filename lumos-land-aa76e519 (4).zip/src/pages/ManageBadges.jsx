import React, { useState, useEffect } from "react";
import { Badge as BadgeEntity } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Plus, Trash2, Save } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ManageBadges() {
  const navigate = useNavigate();
  const [badges, setBadges] = useState([]);
  const [isCreating, setIsCreating] = useState(false);
  const [newBadge, setNewBadge] = useState({
    badge_name: "",
    badge_emoji: "🏆",
    description: "",
    condition_type: "lessons_completed",
    condition_value: 5
  });

  useEffect(() => {
    loadBadges();
  }, []);

  const loadBadges = async () => {
    const allBadges = await BadgeEntity.list();
    setBadges(allBadges);
  };

  const handleCreate = async () => {
    try {
      await BadgeEntity.create({
        ...newBadge,
        badge_id: `badge_${Date.now()}`,
        is_active: true
      });
      await loadBadges();
      setIsCreating(false);
      setNewBadge({
        badge_name: "",
        badge_emoji: "🏆",
        description: "",
        condition_type: "lessons_completed",
        condition_value: 5
      });
      alert("Badge created successfully!");
    } catch (error) {
      console.error("Error creating badge:", error);
      alert("Error creating badge: " + error.message);
    }
  };

  const handleDelete = async (badgeId) => {
    if (!confirm("Are you sure you want to delete this badge?")) return;
    try {
      await BadgeEntity.delete(badgeId);
      await loadBadges();
      alert("Badge deleted successfully!");
    } catch (error) {
      console.error("Error deleting badge:", error);
      alert("Error deleting badge: " + error.message);
    }
  };

  const getConditionDescription = (badge) => {
    const conditions = {
      lessons_completed: `Complete ${badge.condition_value} lessons`,
      total_xp: `Earn ${badge.condition_value} XP`,
      total_coins: `Collect ${badge.condition_value} coins`,
      days_streak: `${badge.condition_value} day streak`,
      npc_interactions: `${badge.condition_value} NPC interactions`,
      journal_entries: `Write ${badge.condition_value} journal entries`
    };
    return conditions[badge.condition_type] || "Custom condition";
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdminPanel"))}
          className="rounded-full"
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold text-[#1165b3]">Manage Badges</h1>
          <p className="text-gray-600">Create badges with automatic unlock conditions</p>
        </div>
        <Button
          onClick={() => setIsCreating(true)}
          className="bg-[#66bfad]"
        >
          <Plus className="w-4 h-4 mr-2" />
          New Badge
        </Button>
      </div>

      {isCreating && (
        <Card className="mb-8 border-2 border-[#66bfad]">
          <CardHeader>
            <CardTitle>Create New Badge</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Badge Name</label>
                <Input
                  value={newBadge.badge_name}
                  onChange={(e) => setNewBadge({...newBadge, badge_name: e.target.value})}
                  placeholder="First Steps"
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Emoji</label>
                <Input
                  value={newBadge.badge_emoji}
                  onChange={(e) => setNewBadge({...newBadge, badge_emoji: e.target.value})}
                  placeholder="🏆"
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Description</label>
              <Textarea
                value={newBadge.description}
                onChange={(e) => setNewBadge({...newBadge, description: e.target.value})}
                placeholder="Complete your first lesson"
              />
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Condition Type</label>
                <Select
                  value={newBadge.condition_type}
                  onValueChange={(value) => setNewBadge({...newBadge, condition_type: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="lessons_completed">Lessons Completed</SelectItem>
                    <SelectItem value="total_xp">Total XP</SelectItem>
                    <SelectItem value="total_coins">Total Coins</SelectItem>
                    <SelectItem value="days_streak">Day Streak</SelectItem>
                    <SelectItem value="npc_interactions">NPC Interactions</SelectItem>
                    <SelectItem value="journal_entries">Journal Entries</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Target Value</label>
                <Input
                  type="number"
                  value={newBadge.condition_value}
                  onChange={(e) => setNewBadge({...newBadge, condition_value: parseInt(e.target.value)})}
                />
              </div>
            </div>

            <div className="flex gap-3">
              <Button onClick={handleCreate} className="bg-[#66bfad]">
                <Save className="w-4 h-4 mr-2" />
                Create Badge
              </Button>
              <Button onClick={() => setIsCreating(false)} variant="outline">
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {badges.map((badge) => (
          <Card key={badge.id} className="border-2 border-gray-200">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="text-4xl">{badge.badge_emoji}</div>
                  <div>
                    <CardTitle className="text-lg">{badge.badge_name}</CardTitle>
                    <p className="text-sm text-gray-600">{badge.description}</p>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="bg-blue-50 rounded-lg p-3">
                  <p className="text-sm font-semibold text-blue-900">Unlock Condition:</p>
                  <p className="text-sm text-blue-800">{getConditionDescription(badge)}</p>
                </div>
                <Button
                  onClick={() => handleDelete(badge.id)}
                  variant="outline"
                  size="sm"
                  className="w-full text-red-600 hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {badges.length === 0 && !isCreating && (
        <Card className="text-center py-12">
          <CardContent>
            <div className="text-6xl mb-4">🏆</div>
            <p className="text-gray-600 mb-4">No badges created yet</p>
            <Button onClick={() => setIsCreating(true)} className="bg-[#66bfad]">
              Create Your First Badge
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}