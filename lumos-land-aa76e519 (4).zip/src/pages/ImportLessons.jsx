import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ArrowLeft, Upload, CheckCircle, AlertCircle, FileText } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ImportLessons() {
  const navigate = useNavigate();
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [importing, setImporting] = useState(false);
  const [results, setResults] = useState(null);

  const handleFileSelect = (event) => {
    const files = Array.from(event.target.files);
    setSelectedFiles(files);
    setResults(null);
  };

  const handleImport = async () => {
    if (selectedFiles.length === 0) {
      alert("Please select at least one JSON file");
      return;
    }

    setImporting(true);
    const importResults = {
      total: selectedFiles.length,
      successful: 0,
      failed: 0,
      details: []
    };

    for (const file of selectedFiles) {
      try {
        const text = await file.text();
        const fileData = JSON.parse(text);

        // Handle both single lesson and multi-lesson files
        let lessonsToImport = [];
        
        if (fileData.pre_assessment || fileData.lessons || fileData.post_assessment || fileData.feedbackform) {
          // Multi-lesson file structure
          if (fileData.pre_assessment) lessonsToImport.push(...fileData.pre_assessment);
          if (fileData.lessons) lessonsToImport.push(...fileData.lessons);
          if (fileData.post_assessment) lessonsToImport.push(...fileData.post_assessment);
          if (fileData.feedbackform) lessonsToImport.push(...fileData.feedbackform);
        } else if (fileData.quest && (fileData.questions || fileData.question)) {
          // Single lesson file
          lessonsToImport.push(fileData);
        } else {
          throw new Error("Invalid file structure - must contain quest and questions/question fields");
        }

        // Import each lesson
        for (const lessonData of lessonsToImport) {
          try {
            // Determine game_format
            let game_format = "mcq"; // default
            
            if (lessonData.is_assessment || lessonData.assessment_type) {
              game_format = "likert";
            } else if (lessonData.type === "match" || lessonData.question) {
              // Matching format has a single "question" field, not "questions" array
              game_format = "matching";
            } else if (lessonData.questions && lessonData.questions.length > 0) {
              if (lessonData.questions[0].type === "match") {
                game_format = "matching";
              } else if (lessonData.questions[0].options && lessonData.score_mapping) {
                game_format = "likert";
              } else {
                game_format = "mcq";
              }
            }

            // Normalize questions format
            let normalizedQuestions = [];
            
            if (game_format === "matching" && lessonData.question) {
              // Matching format with single question field
              normalizedQuestions = [{
                question: lessonData.question,
                type: "match",
                options: lessonData.options || []
              }];
            } else if (lessonData.questions && Array.isArray(lessonData.questions)) {
              normalizedQuestions = lessonData.questions;
            }

            // Create normalized lesson object
            const normalizedLesson = {
              quest: lessonData.quest,
              number: lessonData.number !== undefined ? lessonData.number : 0,
              name: lessonData.name || lessonData.lesson_title || "Untitled Lesson",
              description: lessonData.description || "",
              lessonText: lessonData.lessonText || lessonData.lesson_text || "",
              game_format: game_format,
              game_style: lessonData.game_style || "bubble_pop",
              is_assessment: lessonData.is_assessment || false,
              assessment_type: lessonData.assessment_type || null,
              xp_reward: lessonData.xp_reward || lessonData.xp_total || 50,
              coins_reward: lessonData.coins_reward || lessonData.coins_total || 50,
              coins_per_correct: lessonData.coins_per_correct || 10,
              questions: normalizedQuestions,
              score_mapping: lessonData.score_mapping || null,
              max_score: lessonData.max_score || null,
              feedback: lessonData.feedback || null,
              keyTakeaways: lessonData.keyTakeaways || lessonData.universal_message || "",
              is_active: lessonData.is_active !== undefined ? lessonData.is_active : true
            };

            // Create the lesson
            await base44.entities.GameLesson.create(normalizedLesson);

            importResults.successful++;
          } catch (lessonError) {
            console.error(`Error importing lesson from ${file.name}:`, lessonError);
            importResults.failed++;
            importResults.details.push({
              filename: file.name,
              status: "error",
              message: `Lesson "${lessonData.name || 'unknown'}": ${lessonError.message}`
            });
          }
        }

        if (lessonsToImport.length > 0 && importResults.details.filter(d => d.filename === file.name && d.status === "error").length === 0) {
          importResults.details.push({
            filename: file.name,
            status: "success",
            message: `Successfully imported ${lessonsToImport.length} lesson(s)`
          });
        }

      } catch (error) {
        console.error(`Error processing file ${file.name}:`, error);
        importResults.failed++;
        importResults.details.push({
          filename: file.name,
          status: "error",
          message: error.message
        });
      }
    }

    setResults(importResults);
    setImporting(false);
    setSelectedFiles([]);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdminPanel"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1165b3]">📚 Import Lessons</h1>
          <p className="text-gray-600">Bulk import lesson JSON files</p>
        </div>
      </div>

      <Card className="border-2 border-[#66bfad]/30 shadow-lg">
        <CardHeader>
          <CardTitle className="text-[#1165b3]">Upload Lesson Files</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <Alert className="bg-blue-50 border-blue-300">
            <AlertCircle className="h-4 w-4 text-blue-600" />
            <AlertTitle className="text-blue-800">Supported Formats</AlertTitle>
            <AlertDescription className="text-blue-700">
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li><strong>MCQ:</strong> Questions with "options" array and "answer" index</li>
                <li><strong>Matching:</strong> Single "question" field with "options" array (ans, matching_answer)</li>
                <li><strong>Assessments:</strong> Likert scale with "options" and "score_mapping"</li>
                <li><strong>Multi-lesson files:</strong> With pre_assessment, lessons, post_assessment, feedbackform arrays</li>
              </ul>
            </AlertDescription>
          </Alert>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Select JSON Files</label>
              <input
                type="file"
                accept=".json"
                multiple
                onChange={handleFileSelect}
                className="block w-full text-sm text-gray-500
                  file:mr-4 file:py-3 file:px-6
                  file:rounded-full file:border-0
                  file:text-sm file:font-semibold
                  file:bg-[#66bfad] file:text-white
                  hover:file:bg-[#1165b3]
                  cursor-pointer"
              />
            </div>

            {selectedFiles.length > 0 && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="font-semibold text-gray-700 mb-2">
                  {selectedFiles.length} file(s) selected:
                </p>
                <ul className="text-sm text-gray-600 space-y-1">
                  {selectedFiles.map((file, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <FileText className="w-4 h-4" />
                      {file.name}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <Button
              onClick={handleImport}
              disabled={importing || selectedFiles.length === 0}
              className="w-full bg-gradient-to-r from-[#66bfad] to-[#1165b3] text-white text-lg py-6"
            >
              {importing ? (
                <>
                  <Upload className="w-5 h-5 mr-2 animate-pulse" />
                  Importing {selectedFiles.length} file(s)...
                </>
              ) : (
                <>
                  <Upload className="w-5 h-5 mr-2" />
                  Import Lessons
                </>
              )}
            </Button>
          </div>

          {results && (
            <Alert className={results.failed === 0 ? "bg-green-50 border-green-300" : "bg-yellow-50 border-yellow-300"}>
              <CheckCircle className={`h-4 w-4 ${results.failed === 0 ? "text-green-600" : "text-yellow-600"}`} />
              <AlertTitle className={results.failed === 0 ? "text-green-800" : "text-yellow-800"}>
                Import Complete
              </AlertTitle>
              <AlertDescription className={results.failed === 0 ? "text-green-700" : "text-yellow-700"}>
                <p className="mb-2">
                  Successfully imported lessons from <strong>{results.successful} / {results.total}</strong> files
                </p>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {results.details.map((detail, index) => (
                    <div key={index} className={`p-2 rounded ${
                      detail.status === "success" ? "bg-green-100" : "bg-red-100"
                    }`}>
                      <p className="font-semibold text-sm">{detail.filename}</p>
                      <p className={`text-xs ${
                        detail.status === "success" ? "text-green-700" : "text-red-700"
                      }`}>
                        {detail.message}
                      </p>
                    </div>
                  ))}
                </div>
              </AlertDescription>
            </Alert>
          )}

          <div className="flex gap-4">
            <Button
              variant="outline"
              onClick={() => navigate(createPageUrl("AdminPanel"))}
              className="flex-1"
            >
              Back to Admin Panel
            </Button>
            <Button
              variant="outline"
              onClick={() => navigate(createPageUrl("ManageLessons"))}
              className="flex-1"
            >
              View Imported Lessons
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}