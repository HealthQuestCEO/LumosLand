
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Plus, Trash2, Edit } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl, showLumoAlert, showLumoConfirm } from "@/components/utils";

export default function ManageSpinner() {
  const navigate = useNavigate();
  const [prizes, setPrizes] = useState([]);
  const [shopItems, setShopItems] = useState([]);
  const [editingPrize, setEditingPrize] = useState(null);
  const [formData, setFormData] = useState({
    prize_id: "",
    prize_name: "",
    prize_type: "coins",
    prize_amount: 10,
    item_id: "",
    probability_weight: 1,
    display_color: "#66bfad",
    is_active: true
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const allPrizes = await base44.entities.SpinnerPrize.list();
      setPrizes(allPrizes);

      const allItems = await base44.entities.ShopItem.list();
      setShopItems(allItems);
    } catch (error) {
      console.error("Error loading data:", error);
      showLumoAlert("Error Loading Data", "Could not load spinner prizes or shop items.", "error");
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      if (editingPrize) {
        await base44.entities.SpinnerPrize.update(editingPrize.id, formData);
        showLumoAlert("Prize Updated! ✨", "Your spinner prize has been updated successfully!", "success");
      } else {
        await base44.entities.SpinnerPrize.create(formData);
        showLumoAlert("Prize Added! 🎉", "New prize is now available on the spinner!", "success");
      }
      
      resetForm();
      await loadData();
    } catch (error) {
      console.error("Error saving prize:", error);
      showLumoAlert("Oops! Let's try again 🔄", error.message, "error");
    }
  };

  const handleEdit = (prize) => {
    setEditingPrize(prize);
    setFormData({
      prize_id: prize.prize_id,
      prize_name: prize.prize_name,
      prize_type: prize.prize_type,
      prize_amount: prize.prize_amount || 10,
      item_id: prize.item_id || "",
      probability_weight: prize.probability_weight || 1,
      display_color: prize.display_color || "#66bfad",
      is_active: prize.is_active !== false
    });
  };

  const handleDelete = async (id) => {
    showLumoConfirm(
      "Remove this prize?",
      "This prize will be removed from the spinner and will no longer be winnable.",
      async () => {
        try {
          await base44.entities.SpinnerPrize.delete(id);
          showLumoAlert("Prize Removed! 🗑️", "The prize has been removed from the spinner.", "success");
          await loadData();
        } catch (error) {
          console.error("Error deleting prize:", error);
          showLumoAlert("Oops! Something went wrong 🔄", error.message, "error");
        }
      }
    );
  };

  const resetForm = () => {
    setEditingPrize(null);
    setFormData({
      prize_id: "",
      prize_name: "",
      prize_type: "coins",
      prize_amount: 10,
      item_id: "",
      probability_weight: 1,
      display_color: "#66bfad",
      is_active: true
    });
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdminPanel"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1165b3]">🎡 Manage Spinner Prizes</h1>
          <p className="text-gray-600">Configure daily spinner prizes</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Form */}
        <Card>
          <CardHeader>
            <CardTitle>{editingPrize ? "Edit Prize" : "Add New Prize"}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>Prize ID (unique)</Label>
                <Input
                  value={formData.prize_id}
                  onChange={(e) => setFormData({...formData, prize_id: e.target.value})}
                  placeholder="e.g., coins_10, mystery_item_1"
                  required
                  disabled={!!editingPrize}
                />
              </div>

              <div>
                <Label>Prize Name</Label>
                <Input
                  value={formData.prize_name}
                  onChange={(e) => setFormData({...formData, prize_name: e.target.value})}
                  placeholder="e.g., 10 Coins, Mystery Item"
                  required
                />
              </div>

              <div>
                <Label>Prize Type</Label>
                <Select
                  value={formData.prize_type}
                  onValueChange={(value) => setFormData({...formData, prize_type: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="coins">Coins</SelectItem>
                    <SelectItem value="xp">XP</SelectItem>
                    <SelectItem value="item">Item (from Shop)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {formData.prize_type === "item" ? (
                <div>
                  <Label>Shop Item</Label>
                  <Select
                    value={formData.item_id}
                    onValueChange={(value) => setFormData({...formData, item_id: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select an item..." />
                    </SelectTrigger>
                    <SelectContent>
                      {shopItems.map((item) => (
                        <SelectItem key={item.id} value={item.item_id}>
                          {item.emoji} {item.item_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-gray-500 mt-1">
                    Item will be added to user's Attic automatically
                  </p>
                </div>
              ) : (
                <div>
                  <Label>Amount</Label>
                  <Input
                    type="number"
                    value={formData.prize_amount}
                    onChange={(e) => setFormData({...formData, prize_amount: parseInt(e.target.value)})}
                    min="1"
                    required
                  />
                </div>
              )}

              <div>
                <Label>Probability Weight (higher = more likely)</Label>
                <Input
                  type="number"
                  value={formData.probability_weight}
                  onChange={(e) => setFormData({...formData, probability_weight: parseInt(e.target.value)})}
                  min="1"
                  required
                />
                <p className="text-sm text-gray-500 mt-1">
                  Example: Weight 3 = 3x more likely than weight 1
                </p>
              </div>

              <div>
                <Label>Segment Color (hex)</Label>
                <div className="flex gap-2">
                  <Input
                    type="color"
                    value={formData.display_color}
                    onChange={(e) => setFormData({...formData, display_color: e.target.value})}
                    className="w-20"
                  />
                  <Input
                    value={formData.display_color}
                    onChange={(e) => setFormData({...formData, display_color: e.target.value})}
                    placeholder="#66bfad"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.is_active}
                  onChange={(e) => setFormData({...formData, is_active: e.target.checked})}
                  id="is_active"
                />
                <Label htmlFor="is_active">Active (available in spinner)</Label>
              </div>

              <div className="flex gap-3">
                <Button type="submit" className="flex-1 bg-[#1165b3]">
                  {editingPrize ? "Update Prize" : "Add Prize"}
                </Button>
                {editingPrize && (
                  <Button type="button" variant="outline" onClick={resetForm}>
                    Cancel
                  </Button>
                )}
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Prize List */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Current Prizes ({prizes.length})</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {prizes.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No prizes yet. Add your first one!</p>
              ) : (
                prizes.map((prize) => (
                  <div
                    key={prize.id}
                    className="flex items-center gap-3 p-4 border-2 rounded-xl"
                    style={{ borderColor: prize.display_color || "#66bfad" }}
                  >
                    <div
                      className="w-12 h-12 rounded-full flex items-center justify-center text-2xl"
                      style={{ backgroundColor: prize.display_color || "#66bfad" }}
                    >
                      {prize.prize_type === "xp" ? "⚡" : prize.prize_type === "coins" ? "🪙" : "🎁"}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-bold text-[#1165b3]">{prize.prize_name}</h4>
                      <p className="text-sm text-gray-600">
                        {prize.prize_type === "item" ? (
                          <>Item: {shopItems.find(i => i.item_id === prize.item_id)?.item_name || prize.item_id}</>
                        ) : (
                          <>{prize.prize_amount} {prize.prize_type}</>
                        )}
                        {" • "}Weight: {prize.probability_weight}
                      </p>
                      {!prize.is_active && (
                        <span className="text-xs text-red-600">Inactive</span>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => handleEdit(prize)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => handleDelete(prize.id)}
                      >
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-blue-800">💡 How it Works</CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-2 text-blue-900">
              <p><strong>Coins/XP:</strong> Added directly to user's balance</p>
              <p><strong>Items:</strong> Must select a shop item. It will be added to user's Attic automatically when won</p>
              <p><strong>Probability:</strong> Higher weights = more likely. Weight 3 is 3x more likely than weight 1</p>
              <p><strong>Colors:</strong> Choose different colors for each prize segment on the wheel</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
