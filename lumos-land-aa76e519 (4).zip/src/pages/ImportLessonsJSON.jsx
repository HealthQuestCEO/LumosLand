
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, Upload, Trash2, CheckCircle, AlertCircle, FileJson } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ImportLessonsJSON() {
  const navigate = useNavigate();
  const [jsonInput, setJsonInput] = useState("");
  const [isImporting, setIsImporting] = useState(false);
  const [importResults, setImportResults] = useState(null);
  const [error, setError] = useState(null);
  const [importProgress, setImportProgress] = useState("");
  const [jsonError, setJsonError] = useState(null);

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (!file) {
      setJsonError(null); // Clear any previous error if selection is cancelled
      return;
    }

    // Validate file type
    if (!file.name.endsWith('.json')) {
      setJsonError({
        message: "Invalid file type",
        details: "Please upload a .json file"
      });
      setJsonInput(""); // Clear input if invalid file type
      return;
    }

    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const text = e.target.result;
        setJsonInput(text);
        validateJSON(text); // Validate immediately after loading
        setImportResults(null); // Clear previous import results when new file is loaded
      } catch (err) {
        setJsonError({
          message: "Error reading file content",
          details: err.message
        });
        setJsonInput("");
      }
    };

    reader.onerror = () => {
      setJsonError({
        message: "Failed to read file",
        details: "Please try again or paste the JSON manually"
      });
      setJsonInput("");
    };

    reader.readAsText(file);
  };

  const validateJSON = (text) => {
    if (!text.trim()) {
      setJsonError(null);
      return false;
    }

    try {
      JSON.parse(text);
      setJsonError(null);
      return true;
    } catch (err) {
      // Extract line and column from error message
      const match = err.message.match(/position (\d+)|line (\d+)|column (\d+)/gi);
      
      setJsonError({
        message: err.message,
        details: "Common issues:\n• Missing comma between array items\n• Extra comma after last item\n• Unescaped quotes in strings\n• Missing closing bracket ] or brace }"
      });
      return false;
    }
  };

  const handleJSONChange = (text) => {
    setJsonInput(text);
    if (text.trim()) {
      validateJSON(text);
    } else {
      setJsonError(null);
    }
    setImportResults(null); // Clear previous import results when input changes
  };

  const handleImportBatch = async (batchName, batchData) => {
    try {
      const { data } = await base44.functions.invoke('importLessons', {
        action: 'import',
        healthQuestData: batchData
      });

      if (!data.success) {
        throw new Error(data.error || 'Import failed');
      }

      return data.imported;
    } catch (err) {
      throw new Error(`${batchName} failed: ${err.message}`);
    }
  };

  const handleImport = async () => {
    setIsImporting(true);
    setError(null);
    setImportResults(null);
    setImportProgress("Starting import...");

    try {
      const healthQuestData = JSON.parse(jsonInput);
      
      // Validate structure
      if (!healthQuestData.lessons && !healthQuestData.pre_assessment && 
          !healthQuestData.post_assessment && !healthQuestData.feedbackform) {
        throw new Error("Invalid HealthQuest format. Must contain at least one of: lessons, pre_assessment, post_assessment, feedbackform");
      }

      const totalResults = {
        pre_assessments: 0,
        lessons: 0,
        post_assessments: 0,
        feedback_forms: 0,
        total: 0,
        errors: []
      };

      // Import pre-assessments
      if (healthQuestData.pre_assessment) {
        setImportProgress(`Importing ${healthQuestData.pre_assessment.length} pre-assessments...`);
        const result = await handleImportBatch("Pre-assessments", {
          pre_assessment: healthQuestData.pre_assessment
        });
        totalResults.pre_assessments = result.pre_assessments;
        if (result.errors) totalResults.errors.push(...result.errors);
      }

      // Import lessons in batches of 10
      if (healthQuestData.lessons) {
        const lessons = healthQuestData.lessons;
        const batchSize = 10;
        const batches = Math.ceil(lessons.length / batchSize);

        for (let i = 0; i < batches; i++) {
          const start = i * batchSize;
          const end = Math.min(start + batchSize, lessons.length);
          const batch = lessons.slice(start, end);
          
          setImportProgress(`Importing lessons ${start + 1}-${end} of ${lessons.length}...`);
          
          const result = await handleImportBatch(`Lessons batch ${i + 1}`, {
            lessons: batch
          });
          
          totalResults.lessons += result.lessons;
          if (result.errors) totalResults.errors.push(...result.errors);
        }
      }

      // Import post-assessments
      if (healthQuestData.post_assessment) {
        setImportProgress(`Importing ${healthQuestData.post_assessment.length} post-assessments...`);
        const result = await handleImportBatch("Post-assessments", {
          post_assessment: healthQuestData.post_assessment
        });
        totalResults.post_assessments = result.post_assessments;
        if (result.errors) totalResults.errors.push(...result.errors);
      }

      // Import feedback forms
      if (healthQuestData.feedbackform) {
        setImportProgress(`Importing ${healthQuestData.feedbackform.length} feedback forms...`);
        const result = await handleImportBatch("Feedback forms", {
          feedbackform: healthQuestData.feedbackform
        });
        totalResults.feedback_forms = result.feedback_forms;
        if (result.errors) totalResults.errors.push(...result.errors);
      }

      totalResults.total = totalResults.pre_assessments + totalResults.lessons +
                          totalResults.post_assessments + totalResults.feedback_forms;

      setImportResults(totalResults);
      setJsonInput(""); // Clear input on success
      setJsonError(null);
      setImportProgress("Import complete!");
    } catch (err) {
      console.error("Import error:", err);
      setError(err.message);
    } finally {
      setIsImporting(false);
    }
  };

  const handleClearAll = async () => {
    if (!confirm("⚠️ This will mark ALL Adventure Academy lessons as inactive. Are you sure?")) {
      return;
    }

    try {
      const { data } = await base44.functions.invoke('importLessons', {
        action: 'clearAll'
      });

      if (!data.success) {
        throw new Error(data.error || 'Clear failed');
      }

      alert(`✅ Deactivated ${data.deactivated} lessons`);
      setImportResults(null);
    } catch (err) {
      alert("Error clearing lessons: " + err.message);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdminPanel"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1165b3]">📥 Import Lessons (JSON)</h1>
          <p className="text-gray-600">Paste HealthQuest JSON to import lessons directly</p>
        </div>
      </div>

      {/* How It Works */}
      <Card className="mb-6 border-2 border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-blue-800">
            ✅ How This Works
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <p>1. <strong>Imports in small batches</strong> (10 lessons at a time) to avoid timeouts</p>
          <p>2. <strong>Converts HealthQuest format</strong> (.ma[]/gpt groups) to lesson format automatically</p>
          <p>3. <strong>Creates 3 versions</strong> of each lesson based on type:</p>
          <ul className="ml-8 space-y-1 text-xs">
            <li>📝 <strong>MCQ lessons:</strong> bubble_pop, pin_mountain, glass_bridge</li>
            <li>🔗 <strong>Matching lessons:</strong> bubble_pop, sliding_match, connect_dots</li>
            <li>📊 <strong>Assessments:</strong> bubble_pop only</li>
          </ul>
          <p>4. 📄 Just paste your full HealthQuest JSON and click Import!</p>
        </CardContent>
      </Card>

      {/* JSON Validator Tool */}
      <Card className="border-2 border-purple-200 bg-purple-50">
        <CardHeader>
          <CardTitle className="text-purple-800 flex items-center gap-2">
            <FileJson className="w-5 h-5" />
            💡 JSON Validator Tip
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-purple-900">
          <p><strong>Before pasting here:</strong> Validate your JSON at <a href="https://jsonlint.com" target="_blank" rel="noopener noreferrer" className="underline text-blue-600">jsonlint.com</a></p>
          <p>It will show you the exact line/column where the error is!</p>
        </CardContent>
      </Card>

      {/* JSON Input */}
      <Card>
        <CardHeader>
          <CardTitle>Paste HealthQuest JSON</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* ✅ NEW: File Upload Button */}
          <div className="flex gap-3">
            <label className="flex-1">
              <input
                type="file"
                accept=".json"
                onChange={handleFileUpload}
                className="hidden"
                id="json-file-upload"
              />
              <Button
                type="button"
                variant="outline"
                className="w-full"
                onClick={() => document.getElementById('json-file-upload').click()}
              >
                <Upload className="w-4 h-4 mr-2" />
                📁 Upload JSON File
              </Button>
            </label>
            
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setJsonInput("");
                setJsonError(null);
                setImportResults(null);
                setError(null); // Clear general error as well
              }}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Clear
            </Button>
          </div>

          <Textarea
            placeholder='{"lessons": [...], "pre_assessment": [...], "post_assessment": [...], "feedbackform": [...]}'
            value={jsonInput}
            onChange={(e) => handleJSONChange(e.target.value)}
            className={`font-mono text-sm h-64 ${jsonError ? 'border-red-500' : ''}`}
          />

          {/* JSON Error */}
          {jsonError && (
            <Alert className="border-red-300 bg-red-50">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">
                <div className="space-y-2">
                  <p className="font-bold">❌ Invalid JSON</p>
                  <p className="text-sm">{jsonError.message}</p>
                  <div className="text-sm bg-white p-3 rounded border border-red-200 whitespace-pre-line">
                    {jsonError.details}
                  </div>
                  <p className="text-sm font-semibold">🔧 Fix: Copy your JSON to <a href="https://jsonlint.com" target="_blank" rel="noopener noreferrer" className="underline text-blue-600">jsonlint.com</a> to find the exact error</p>
                </div>
              </AlertDescription>
            </Alert>
          )}
          
          <div className="flex gap-3">
            <Button
              onClick={handleImport}
              disabled={!jsonInput.trim() || isImporting || !!jsonError}
              className="bg-[#1165b3]"
            >
              <Upload className="w-4 h-4 mr-2" />
              {isImporting ? "Importing..." : "Import Lessons"}
            </Button>

            <Button
              onClick={handleClearAll}
              variant="destructive"
              disabled={isImporting}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Clear All Lessons
            </Button>
          </div>

          {/* Progress */}
          {isImporting && importProgress && (
            <Alert className="border-blue-300 bg-blue-50">
              <AlertCircle className="h-4 w-4 text-blue-600 animate-spin" />
              <AlertDescription className="text-blue-800">
                {importProgress}
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Error */}
      {error && (
        <Alert className="border-red-300 bg-red-50">
          <AlertCircle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            {error}
          </AlertDescription>
        </Alert>
      )}

      {/* Results */}
      {importResults && (
        <Card className="border-2 border-green-300 bg-green-50">
          <CardHeader>
            <CardTitle className="text-green-800 flex items-center gap-2">
              <CheckCircle className="w-5 h-5" />
              Import Complete!
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-green-900">
            <p><strong>Pre-assessments:</strong> {importResults.pre_assessments} (includes 3 game_style versions each)</p>
            <p><strong>Lessons:</strong> {importResults.lessons} (includes 3 game_style versions each)</p>
            <p><strong>Post-assessments:</strong> {importResults.post_assessments} (includes 3 game_style versions each)</p>
            <p><strong>Feedback forms:</strong> {importResults.feedback_forms} (includes 3 game_style versions each)</p>
            <p className="text-lg font-bold mt-4">Total: {importResults.total} lesson variations imported</p>
            
            {importResults.errors && importResults.errors.length > 0 && (
              <div className="mt-4 p-4 bg-yellow-100 rounded">
                <p className="font-bold text-yellow-800 mb-2">⚠️ Errors during import:</p>
                <ul className="list-disc list-inside text-sm text-yellow-900">
                  {importResults.errors.map((err, idx) => (
                    <li key={idx}>{err}</li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
