

import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Home, LogOut, Settings } from "lucide-react";
import { base44 } from "@/api/base44Client";

const Header = () => {
    const [isAdmin, setIsAdmin] = useState(false);

    useEffect(() => {
        checkAdmin();
    }, []);

    const checkAdmin = async () => {
        try {
            const user = await base44.auth.me();
            setIsAdmin(user?.role === 'admin');
        } catch (error) {
            // console.error("Failed to check admin status:", error);
            setIsAdmin(false); // Ensure isAdmin is false on error
        }
    };

    return (
        <header className="bg-white shadow-sm sticky top-0 z-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-20">
                    <div className="flex items-center">
                        <Link to={createPageUrl("Home")} className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-gradient-to-br from-[#66bfad] to-[#1165b3] rounded-lg flex items-center justify-center text-white text-lg font-bold">LL</div>
                            <span className="text-xl font-bold bg-gradient-to-r from-[#1165b3] to-[#66bfad] bg-clip-text text-transparent">Lumo's Land (beta)</span>
                        </Link>
                    </div>
                    
                    <div className="flex items-center space-x-4 md:space-x-6">
                        <a href="https://app.base44.com/" target="_blank" rel="noopener noreferrer" title="Back to HealthQuest" className="transition-transform hover:scale-110">
                            <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68e72a9f947d6831aa76e519/f1e61e5ef_Untitleddesign25.png" alt="HealthQuest" className="h-10 w-10"/>
                        </a>
                        <Link to={createPageUrl("Home")} className="flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium text-gray-600 hover:bg-gray-100 transition-colors">
                            <Home className="w-5 h-5" />
                            <span className="hidden sm:inline">Home</span>
                        </Link>
                        {isAdmin && (
                            <Link to={createPageUrl("AdminPanel")} className="flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium text-gray-600 hover:bg-gray-100 transition-colors">
                                <Settings className="w-5 h-5" />
                                <span className="hidden sm:inline">Admin</span>
                            </Link>
                        )}
                        <button 
                            onClick={() => base44.auth.logout()}
                            className="flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium text-gray-600 hover:bg-gray-100 transition-colors"
                        >
                            <LogOut className="w-5 h-5" />
                            <span className="hidden sm:inline">Logout</span>
                        </button>
                    </div>
                </div>
            </div>
        </header>
    );
}

export default function Layout({ children, currentPageName }) {
  return (
    <div className="min-h-screen bg-[#e0f8f5]">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        * { font-family: 'Poppins', sans-serif; }
        :root {
          --color-primary-teal: #66bfad;
          --color-accent-orange: #ffa400;
          --color-accent-cyan: #00d1ff;
          --color-primary-blue-border: #1165b3;
          --color-bg-pale: #e0f8f5;
          --color-bg-light-gray: #e0e0e0;
          --color-bg-white: #ffffff;
        }
      `}</style>
      <Header />
      <main className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
          {children}
      </main>
    </div>
  );
}

