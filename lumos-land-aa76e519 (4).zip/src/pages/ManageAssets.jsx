import React, { useState, useEffect } from "react";
import { AssetMapping } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, Upload, Trash2, Save, Image as ImageIcon } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";

const LUMO_STATES = ["happy", "content", "angry", "sad", "sleepy", "playful", "brave", "confident", "anxious", "hungry", "thirsty", "dirty", "missing"];
const SEASONS = ["spring", "summer", "fall", "winter", "default"];

export default function ManageAssets() {
  const navigate = useNavigate();
  const [assets, setAssets] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [newAsset, setNewAsset] = useState({
    asset_type: "lumo_state",
    asset_key: "",
    display_name: "",
    description: "",
    scale: 2,
    custom_key: "" // For "other" option
  });
  const [uploadedFile, setUploadedFile] = useState(null);

  useEffect(() => {
    loadAssets();
  }, []);

  const loadAssets = async () => {
    const allAssets = await AssetMapping.list();
    setAssets(allAssets);
  };

  const handleFileSelect = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploading(true);
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setUploadedFile(file_url);
      alert("File uploaded! Now fill in the details and click 'Save Asset'");
    } catch (error) {
      alert("Upload failed: " + error.message);
    } finally {
      setUploading(false);
    }
  };

  const handleSaveAsset = async () => {
    if (!uploadedFile) {
      alert("Please upload an image first!");
      return;
    }
    
    // Use custom key if "other" is selected, otherwise use asset_key
    const finalKey = newAsset.asset_key === "other" ? newAsset.custom_key : newAsset.asset_key;
    
    if (!finalKey) {
      alert("Please enter a key/identifier!");
      return;
    }

    try {
      const existing = assets.find(a => a.asset_type === newAsset.asset_type && a.asset_key === finalKey);
      
      if (existing) {
        if (!confirm(`Replace existing ${newAsset.asset_type} for "${finalKey}"?`)) {
          return;
        }
        await AssetMapping.update(existing.id, {
          image_url: uploadedFile,
          display_name: newAsset.display_name || finalKey,
          description: newAsset.description,
          scale: newAsset.scale
        });
      } else {
        await AssetMapping.create({
          asset_type: newAsset.asset_type,
          asset_key: finalKey,
          image_url: uploadedFile,
          display_name: newAsset.display_name || finalKey,
          description: newAsset.description,
          scale: newAsset.scale
        });
      }

      alert("Asset saved successfully!");
      setUploadedFile(null);
      setNewAsset({
        asset_type: "lumo_state",
        asset_key: "",
        display_name: "",
        description: "",
        scale: 2,
        custom_key: ""
      });
      await loadAssets();
    } catch (error) {
      alert("Error saving asset: " + error.message);
    }
  };

  const handleDelete = async (asset) => {
    if (!confirm(`Delete ${asset.asset_type} "${asset.asset_key}"?`)) return;
    
    try {
      await AssetMapping.delete(asset.id);
      alert("Deleted successfully!");
      await loadAssets();
    } catch (error) {
      alert("Error deleting: " + error.message);
    }
  };

  const handleUpdateScale = async (asset, newScale) => {
    try {
      await AssetMapping.update(asset.id, { scale: newScale });
      await loadAssets();
    } catch (error) {
      alert("Error updating scale: " + error.message);
    }
  };

  const groupedAssets = {
    lumo_state: assets.filter(a => a.asset_type === "lumo_state"),
    background: assets.filter(a => a.asset_type === "background")
  };

  // Get available options based on asset type
  const getAssetKeyOptions = () => {
    if (newAsset.asset_type === "lumo_state") {
      return [...LUMO_STATES, "other"];
    } else if (newAsset.asset_type === "background") {
      return [...SEASONS, "other"];
    }
    return ["other"];
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdminPanel"))}
          className="rounded-full"
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1165b3]">📸 Asset Manager</h1>
          <p className="text-gray-600">Manage Lumo states, backgrounds, and outfits</p>
        </div>
      </div>

      <Alert className="mb-6 bg-blue-50 border-blue-200">
        <AlertDescription>
          <strong>💡 Dressed-Up Lumo:</strong> To show Lumo wearing an outfit, create a new Lumo state with a custom name (e.g., "happy_wearing_crown"). 
          Upload the image of Lumo wearing the item here, then in the shop item, add the custom state name. The shop will display that special image when purchased!
        </AlertDescription>
      </Alert>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Upload Section */}
        <Card>
          <CardHeader>
            <CardTitle>Upload New Asset</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">1. Asset Type</label>
              <Select
                value={newAsset.asset_type}
                onValueChange={(value) => setNewAsset({...newAsset, asset_type: value, asset_key: "", custom_key: ""})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="lumo_state">Lumo Character State</SelectItem>
                  <SelectItem value="background">Background/Season</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">2. Select Key/Identifier</label>
              <Select
                value={newAsset.asset_key}
                onValueChange={(value) => setNewAsset({...newAsset, asset_key: value, display_name: value === "other" ? "" : value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Choose option" />
                </SelectTrigger>
                <SelectContent>
                  {getAssetKeyOptions().map(option => (
                    <SelectItem key={option} value={option}>
                      {option === "other" ? "✏️ Custom (type your own)" : option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Custom key input when "other" is selected */}
            {newAsset.asset_key === "other" && (
              <div>
                <label className="text-sm font-medium mb-2 block">Custom Key Name</label>
                <Input
                  placeholder="e.g., happy_wearing_crown, summer_beach"
                  value={newAsset.custom_key}
                  onChange={(e) => setNewAsset({...newAsset, custom_key: e.target.value, display_name: e.target.value})}
                />
                <p className="text-xs text-gray-500 mt-1">Use lowercase with underscores, e.g., "happy_wearing_hat"</p>
              </div>
            )}

            {newAsset.asset_type === "lumo_state" && (
              <div>
                <label className="text-sm font-medium mb-2 block">3. Lumo Scale (Size)</label>
                <div className="flex items-center gap-4">
                  <Input
                    type="number"
                    step="0.1"
                    min="0.5"
                    max="4"
                    value={newAsset.scale}
                    onChange={(e) => setNewAsset({...newAsset, scale: parseFloat(e.target.value)})}
                    className="w-24"
                  />
                  <span className="text-sm text-gray-600">
                    {newAsset.scale}x (default: 2x)
                  </span>
                </div>
              </div>
            )}

            <div>
              <label className="text-sm font-medium mb-2 block">4. Upload Image</label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileSelect}
                  className="hidden"
                  id="asset-upload"
                />
                <label htmlFor="asset-upload" className="cursor-pointer">
                  <ImageIcon className="w-12 h-12 mx-auto mb-2 text-gray-400" />
                  <p className="text-sm text-gray-600">
                    {uploading ? "Uploading..." : uploadedFile ? "✅ Image uploaded!" : "Click to upload image"}
                  </p>
                </label>
              </div>
              {uploadedFile && (
                <img src={uploadedFile} alt="Preview" className="mt-2 max-h-32 mx-auto" />
              )}
            </div>

            <Button
              onClick={handleSaveAsset}
              disabled={!uploadedFile || (!newAsset.asset_key && !newAsset.custom_key)}
              className="w-full bg-gradient-to-r from-[#66bfad] to-[#1165b3] text-white"
            >
              <Save className="w-4 h-4 mr-2" />
              Save Asset
            </Button>
          </CardContent>
        </Card>

        {/* Asset Chart */}
        <div className="space-y-6">
          {/* Lumo States Chart */}
          <Card>
            <CardHeader>
              <CardTitle>🐾 Lumo Character States ({groupedAssets.lumo_state.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                {LUMO_STATES.map(state => {
                  const asset = groupedAssets.lumo_state.find(a => a.asset_key === state);
                  return (
                    <div
                      key={state}
                      className={`border-2 rounded-lg p-3 ${asset ? 'border-green-300 bg-green-50' : 'border-gray-200 bg-gray-50'}`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-semibold capitalize">{state}</span>
                        {asset ? (
                          <span className="text-green-600 text-xs">✓</span>
                        ) : (
                          <span className="text-gray-400 text-xs">○</span>
                        )}
                      </div>
                      {asset && (
                        <div className="space-y-2">
                          <img src={asset.image_url} alt={state} className="w-full h-20 object-contain bg-white rounded" />
                          <div className="flex items-center gap-2">
                            <Input
                              type="number"
                              step="0.1"
                              min="0.5"
                              max="4"
                              value={asset.scale || 2}
                              onChange={(e) => handleUpdateScale(asset, parseFloat(e.target.value))}
                              className="h-7 text-xs"
                            />
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleDelete(asset)}
                              className="h-7 px-2"
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
                
                {/* Show custom/other states */}
                {groupedAssets.lumo_state.filter(a => !LUMO_STATES.includes(a.asset_key)).map(asset => (
                  <div
                    key={asset.asset_key}
                    className="border-2 rounded-lg p-3 border-purple-300 bg-purple-50"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-semibold">{asset.asset_key}</span>
                      <span className="text-purple-600 text-xs">★</span>
                    </div>
                    <div className="space-y-2">
                      <img src={asset.image_url} alt={asset.asset_key} className="w-full h-20 object-contain bg-white rounded" />
                      <div className="flex items-center gap-2">
                        <Input
                          type="number"
                          step="0.1"
                          min="0.5"
                          max="4"
                          value={asset.scale || 2}
                          onChange={(e) => handleUpdateScale(asset, parseFloat(e.target.value))}
                          className="h-7 text-xs"
                        />
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDelete(asset)}
                          className="h-7 px-2"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Backgrounds Chart */}
          <Card>
            <CardHeader>
              <CardTitle>🌄 Backgrounds ({groupedAssets.background.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                {SEASONS.map(season => {
                  const asset = groupedAssets.background.find(a => a.asset_key === season);
                  return (
                    <div
                      key={season}
                      className={`border-2 rounded-lg p-3 ${asset ? 'border-blue-300 bg-blue-50' : 'border-gray-200 bg-gray-50'}`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-semibold capitalize">{season}</span>
                        {asset ? (
                          <span className="text-blue-600 text-xs">✓</span>
                        ) : (
                          <span className="text-gray-400 text-xs">○</span>
                        )}
                      </div>
                      {asset && (
                        <div className="space-y-2">
                          <img src={asset.image_url} alt={season} className="w-full h-20 object-cover rounded" />
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleDelete(asset)}
                            className="h-7 w-full"
                          >
                            <Trash2 className="w-3 h-3 mr-1" />
                            Delete
                          </Button>
                        </div>
                      )}
                    </div>
                  );
                })}

                {/* Show custom backgrounds */}
                {groupedAssets.background.filter(a => !SEASONS.includes(a.asset_key)).map(asset => (
                  <div
                    key={asset.asset_key}
                    className="border-2 rounded-lg p-3 border-purple-300 bg-purple-50"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-semibold">{asset.asset_key}</span>
                      <span className="text-purple-600 text-xs">★</span>
                    </div>
                    <div className="space-y-2">
                      <img src={asset.image_url} alt={asset.asset_key} className="w-full h-20 object-cover rounded" />
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => handleDelete(asset)}
                        className="h-7 w-full"
                      >
                        <Trash2 className="w-3 h-3 mr-1" />
                        Delete
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}