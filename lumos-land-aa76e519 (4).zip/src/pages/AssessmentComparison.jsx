
import React, { useState, useEffect } from "react";
import { AssessmentScore, GameLesson } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, BarChart3, Users, TrendingUp, Info, RefreshCw } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from "recharts";

export default function AssessmentComparison() {
  const navigate = useNavigate();
  const [assessments, setAssessments] = useState([]);
  const [lessons, setLessons] = useState([]);
  const [isLoading, setIsLoading] = useState(true); // Renamed from 'loading' to 'isLoading'

  // Removed filter states as per outline:
  // const [selectedQuest, setSelectedQuest] = useState("all");
  // const [selectedAgeGroup, setSelectedAgeGroup] = useState("all");
  // const [selectedRole, setSelectedRole] = useState("all");
  // const [selectedLessonType, setSelectedLessonType] = useState("assessment");

  const [aggregatedData, setAggregatedData] = useState(null);

  // New states for overall performance metrics
  const [preScore, setPreScore] = useState(null);
  const [postScore, setPostScore] = useState(null);
  const [overallImprovement, setOverallImprovement] = useState(null);
  const [participantCount, setParticipantCount] = useState(0);
  const [lessonsAnalyzedCount, setLessonsAnalyzedCount] = useState(0);

  // Removed availableQuests as the quest filter is removed
  // const [availableQuests, setAvailableQuests] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  // Recalculate aggregates whenever raw data changes
  useEffect(() => {
    if (assessments.length > 0 && lessons.length > 0) {
      calculateAggregates();
    } else if (assessments.length === 0 && lessons.length === 0 && !isLoading) {
      // If no data after loading, clear aggregated metrics
      setAggregatedData(null);
      setPreScore(null);
      setPostScore(null);
      setOverallImprovement(null);
      setParticipantCount(0);
      setLessonsAnalyzedCount(0);
    }
  }, [assessments, lessons, isLoading]); // Removed filter dependencies as filters are removed

  const loadData = async () => {
    try {
      setIsLoading(true);
      const allAssessments = await AssessmentScore.list();
      const allLessons = await GameLesson.list();

      setAssessments(allAssessments);
      setLessons(allLessons);

      // Removed extraction of unique quests as filter is removed
      // const quests = [...new Set(allLessons.map(l => l.quest).filter(Boolean))];
      // setAvailableQuests(quests);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const calculateAggregates = () => {
    // With filters removed, we process all relevant assessments.
    // Assuming for 'Assessment Progress Tracker', we focus on lessons marked as assessments.
    let filteredAssessments = assessments.filter(assessment => {
      const lesson = lessons.find(l => l.id === assessment.lesson_id);
      return lesson && lesson.is_assessment; // Only include actual assessments
    });

    if (filteredAssessments.length === 0) {
      setAggregatedData(null);
      setPreScore(null);
      setPostScore(null);
      setOverallImprovement(null);
      setParticipantCount(0);
      setLessonsAnalyzedCount(0);
      return;
    }

    // Group by lesson_id and assessment_type
    const grouped = {};

    filteredAssessments.forEach(assessment => {
      const key = `${assessment.lesson_id}_${assessment.assessment_type}`;
      if (!grouped[key]) {
        grouped[key] = {
          lesson_id: assessment.lesson_id,
          assessment_type: assessment.assessment_type,
          scores: [],
          max_score: assessment.max_score
        };
      }
      grouped[key].scores.push(assessment.total_score);
    });

    // Calculate averages and prepare chart data
    const lessonGroups = {};

    Object.values(grouped).forEach(group => {
      const lesson = lessons.find(l => l.id === group.lesson_id);
      if (!lesson) return;

      const lessonName = lesson.name;
      if (!lessonGroups[lessonName]) {
        lessonGroups[lessonName] = {
          name: lessonName,
          quest: lesson.quest,
          ageRange: `${lesson.minAge}-${lesson.maxAge}`,
          role: lesson.forRole,
          participantCount: 0 // Initialize participantCount for the lesson
        };
      }

      const avg = group.scores.reduce((a, b) => a + b, 0) / group.scores.length;
      const percentage = (avg / group.max_score) * 100;

      lessonGroups[lessonName][`${group.assessment_type}_avg`] = percentage.toFixed(1);
      lessonGroups[lessonName][`${group.assessment_type}_count`] = group.scores.length;

      // Summing all submissions for this lesson (pre + post)
      lessonGroups[lessonName].participantCount += group.scores.length;
    });

    const data = Object.values(lessonGroups);

    // Calculate improvement for each lesson
    data.forEach(item => {
      if (item.pre_avg && item.post_avg) {
        item.improvement = (parseFloat(item.post_avg) - parseFloat(item.pre_avg)).toFixed(1);
      }
    });

    setAggregatedData(data);

    // --- Derive overall metrics for the new UI ---
    let currentTotalParticipants = 0;
    const lessonsWithPrePost = data.filter(d => d.pre_avg && d.post_avg);

    // For overall pre/post, average across lessons that have both
    const sumPreScores = lessonsWithPrePost.reduce((sum, item) => sum + parseFloat(item.pre_avg), 0);
    const sumPostScores = lessonsWithPrePost.reduce((sum, item) => sum + parseFloat(item.post_avg), 0);

    const overallPreAvg = lessonsWithPrePost.length > 0 ? sumPreScores / lessonsWithPrePost.length : null;
    const overallPostAvg = lessonsWithPrePost.length > 0 ? sumPostScores / lessonsWithPrePost.length : null;

    setPreScore(overallPreAvg);
    setPostScore(overallPostAvg);

    if (overallPreAvg !== null && overallPostAvg !== null) {
      setOverallImprovement((overallPostAvg - overallPreAvg).toFixed(1));
    } else {
      setOverallImprovement(null);
    }

    // Calculate total participants (sum of unique participants across all lessons, or sum of all participations)
    // The previous logic for participantCount was a cumulative sum of all scores. Let's keep that.
    currentTotalParticipants = data.reduce((sum, item) => sum + (item.participantCount || 0), 0);
    setParticipantCount(currentTotalParticipants);

    setLessonsAnalyzedCount(data.length);
  };

  // Removed filter helper functions as filters are removed
  // const getAgeGroups = () => { /* ... */ };
  // const getRoles = () => { /* ... */ };
  // const getLessonTypes = () => { /* ... */ };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#e0f8f5] to-[#66bfad]/20 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("AdventureAcademy"))} // Changed navigation target
            className="rounded-full"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-[#1165b3]">Assessment Progress Tracker</h1> {/* Changed title */}
            <p className="text-gray-600">See how much you've grown!</p> {/* Changed description */}
          </div>
        </div>

        {/* Removed Privacy Notice Alert as per outline */}
        {/* Removed Filters Card as per outline */}

        {isLoading ? ( // Changed loading state UI and icon
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <RefreshCw className="w-8 h-8 animate-spin text-[#66bfad] mx-auto mb-4" />
              <p className="text-gray-600">Loading your progress...</p>
            </div>
          </div>
        ) : !preScore || !postScore ? ( // Changed 'no data' condition
          <Card className="border-2 border-[#1165b3]/20">
            <CardContent className="py-12 text-center">
              <BarChart3 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-700 mb-2">
                Complete Both Assessments
              </h3>
              <p className="text-gray-600">
                Take the pre and post assessments to see your amazing growth!
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {/* Summary Cards */}
            <div className="grid md:grid-cols-3 gap-6">
              <Card className="border-2 border-[#66bfad] bg-gradient-to-br from-[#e0f8f5] to-white">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <div className="bg-blue-100 p-3 rounded-full">
                      <Users className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Total Participants</p>
                      <p className="text-2xl font-bold text-[#1165b3]">
                        {participantCount}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-[#1165b3] bg-gradient-to-br from-[#e0f8f5] to-white">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <div className="bg-green-100 p-3 rounded-full">
                      <BarChart3 className="w-6 h-6 text-green-600" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Lessons Analyzed</p>
                      <p className="text-2xl font-bold text-[#1165b3]">{lessonsAnalyzedCount}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-[#ffa400] bg-gradient-to-br from-[#e0f8f5] to-white">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <div className="bg-orange-100 p-3 rounded-full">
                      <TrendingUp className="w-6 h-6 text-orange-600" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Avg Improvement</p>
                      <p className="text-2xl font-bold text-[#1165b3]">
                        {overallImprovement !== null ? `${overallImprovement}%` : '-'}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Bar Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="text-[#1165b3]">Pre vs Post Assessment Scores (Avg %)</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={aggregatedData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={120} />
                    <YAxis label={{ value: 'Score (%)', angle: -90, position: 'insideLeft' }} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="pre_avg" fill="#1165b3" name="Pre-Assessment" />
                    <Bar dataKey="post_avg" fill="#66bfad" name="Post-Assessment" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Line Chart - Improvement Trend */}
            <Card>
              <CardHeader>
                <CardTitle className="text-[#1165b3]">Improvement Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={aggregatedData.filter(d => d.improvement)}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={120} />
                    <YAxis label={{ value: 'Improvement (%)', angle: -90, position: 'insideLeft' }} />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="improvement" stroke="#ffa400" strokeWidth={3} name="Improvement" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Data Table */}
            <Card>
              <CardHeader>
                <CardTitle className="text-[#1165b3]">Detailed Results</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="text-left p-3 font-semibold">Lesson Name</th>
                        <th className="text-left p-3 font-semibold">Quest</th>
                        <th className="text-left p-3 font-semibold">Age Range</th>
                        <th className="text-left p-3 font-semibold">Role</th>
                        <th className="text-center p-3 font-semibold">Pre (n)</th>
                        <th className="text-center p-3 font-semibold">Pre Avg</th>
                        <th className="text-center p-3 font-semibold">Post (n)</th>
                        <th className="text-center p-3 font-semibold">Post Avg</th>
                        <th className="text-center p-3 font-semibold">Improvement</th>
                      </tr>
                    </thead>
                    <tbody>
                      {aggregatedData?.map((item, idx) => ( // Use optional chaining for aggregatedData
                        <tr key={idx} className="border-t hover:bg-gray-50">
                          <td className="p-3">{item.name}</td>
                          <td className="p-3">{item.quest}</td>
                          <td className="p-3">{item.ageRange}</td>
                          <td className="p-3 capitalize">{item.role}</td>
                          <td className="text-center p-3">{item.pre_count || '-'}</td>
                          <td className="text-center p-3">{item.pre_avg ? `${item.pre_avg}%` : '-'}</td>
                          <td className="text-center p-3">{item.post_count || '-'}</td>
                          <td className="text-center p-3">{item.post_avg ? `${item.post_avg}%` : '-'}</td>
                          <td className="text-center p-3">
                            {item.improvement ? (
                              <span className={`font-semibold ${parseFloat(item.improvement) > 0 ? 'text-green-600' : 'text-red-600'}`}>
                                {item.improvement > 0 ? '+' : ''}{item.improvement}%
                              </span>
                            ) : '-'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
