import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, Plus, Edit, Trash2, Save, X, AlertCircle, Info } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ManageShopItems() {
  const navigate = useNavigate();
  const [items, setItems] = useState([]);
  const [editingItem, setEditingItem] = useState(null);
  const [isCreating, setIsCreating] = useState(false);
  const [formData, setFormData] = useState({});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadItems();
  }, []);

  const loadItems = async () => {
    try {
      setIsLoading(true);
      const allItems = await base44.entities.ShopItem.list();
      setItems(allItems);
    } catch (error) {
      console.error("Error loading items:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreate = () => {
    setIsCreating(true);
    setFormData({
      item_id: `item_${Date.now()}`,
      item_name: "",
      emoji: "",
      image_url: "",
      item_type: "physical",
      sub_type: "",
      price: 10,
      description: "",
      treats: "",
      effect_amount: 100,
      emotion_result: "",
      is_active: true,
      available_from: "",
      available_until: "",
      custom_type: ""
    });
  };

  const handleEdit = (item) => {
    setEditingItem(item);
    setFormData({ ...item });
  };

  const handleSave = async () => {
    try {
      // Clean up data based on item_type
      const cleanData = { ...formData };
      
      // If physical/emotional, remove sub_type
      if (cleanData.item_type === "physical" || cleanData.item_type === "emotional") {
        delete cleanData.sub_type;
      }
      
      // If not emotional, remove emotion_result
      if (cleanData.item_type !== "emotional") {
        delete cleanData.emotion_result;
      }
      
      // If not physical/emotional, remove treats and effect_amount
      if (cleanData.item_type !== "physical" && cleanData.item_type !== "emotional") {
        delete cleanData.treats;
        delete cleanData.effect_amount;
      }

      if (editingItem) {
        await base44.entities.ShopItem.update(editingItem.id, cleanData);
      } else {
        await base44.entities.ShopItem.create(cleanData);
      }
      
      await loadItems();
      setEditingItem(null);
      setIsCreating(false);
      setFormData({});
    } catch (error) {
      console.error("Error saving item:", error);
      alert("Error saving item: " + error.message);
    }
  };

  const handleDelete = async (item) => {
    if (!confirm(`Delete ${item.item_name}?`)) return;
    
    try {
      await base44.entities.ShopItem.delete(item.id);
      await loadItems();
    } catch (error) {
      console.error("Error deleting item:", error);
      alert("Error deleting item: " + error.message);
    }
  };

  const handleCancel = () => {
    setEditingItem(null);
    setIsCreating(false);
    setFormData({});
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="text-6xl mb-4 animate-bounce">🛍️</div>
          <p className="text-[#1165b3] font-semibold">Loading shop items...</p>
        </div>
      </div>
    );
  }

  const isEditing = editingItem || isCreating;

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdminPanel"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold text-[#1165b3]">Manage Shop Items</h1>
          <p className="text-gray-600">Add and edit items for Lumo's Nook</p>
        </div>
        {!isEditing && (
          <Button onClick={handleCreate} className="bg-[#66bfad]">
            <Plus className="w-4 h-4 mr-2" />
            Add New Item
          </Button>
        )}
      </div>

      {/* Info Alert */}
      <Alert className="mb-6 bg-blue-50 border-blue-300">
        <Info className="h-4 w-4 text-blue-600" />
        <AlertDescription className="text-blue-800">
          <strong>Item Types:</strong>
          <ul className="list-disc list-inside mt-2 ml-4 space-y-1">
            <li><strong>Physical & Emotional:</strong> Consumables - can be purchased unlimited times (restores needs immediately)</li>
            <li><strong>Decor, Outfit, Seasonal:</strong> One-time purchases - go to inventory/attic and can only be bought once</li>
          </ul>
        </AlertDescription>
      </Alert>

      {isEditing && (
        <Card className="mb-8 border-2 border-[#66bfad]">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>{editingItem ? "Edit Item" : "Create New Item"}</span>
              <div className="flex gap-2">
                <Button onClick={handleSave} size="sm" className="bg-green-600">
                  <Save className="w-4 h-4 mr-2" />
                  Save
                </Button>
                <Button onClick={handleCancel} size="sm" variant="outline">
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold mb-2">Item ID *</label>
                <Input
                  value={formData.item_id || ""}
                  onChange={(e) => setFormData({...formData, item_id: e.target.value})}
                  placeholder="unique_item_id"
                  disabled={editingItem !== null}
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">Item Name *</label>
                <Input
                  value={formData.item_name || ""}
                  onChange={(e) => setFormData({...formData, item_name: e.target.value})}
                  placeholder="Cool Item"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">Emoji</label>
                <Input
                  value={formData.emoji || ""}
                  onChange={(e) => setFormData({...formData, emoji: e.target.value})}
                  placeholder="🎁"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">Price (Coins) *</label>
                <Input
                  type="number"
                  value={formData.price || 10}
                  onChange={(e) => setFormData({...formData, price: parseInt(e.target.value)})}
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-semibold mb-2">Image URL</label>
                <Input
                  value={formData.image_url || ""}
                  onChange={(e) => setFormData({...formData, image_url: e.target.value})}
                  placeholder="https://..."
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-semibold mb-2">Description *</label>
                <Textarea
                  value={formData.description || ""}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="Describe the item..."
                  rows={3}
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">Item Type *</label>
                <select
                  value={formData.item_type || "physical"}
                  onChange={(e) => setFormData({...formData, item_type: e.target.value})}
                  className="w-full border-2 border-gray-300 rounded-lg p-2"
                >
                  <option value="physical">Physical (Consumable)</option>
                  <option value="emotional">Emotional (Consumable)</option>
                  <option value="decor">Decor (One-time)</option>
                  <option value="outfit">Outfit (One-time)</option>
                  <option value="seasonal">Seasonal (One-time)</option>
                </select>
                <p className="text-xs text-gray-500 mt-1">
                  {(formData.item_type === "physical" || formData.item_type === "emotional") 
                    ? "✅ Can be purchased unlimited times" 
                    : "⚠️ Can only be purchased once per user"}
                </p>
              </div>

              {/* Sub-type (for decor/outfit/seasonal) */}
              {(formData.item_type === "decor" || formData.item_type === "outfit" || formData.item_type === "seasonal") && (
                <div>
                  <label className="block text-sm font-semibold mb-2">Sub-type</label>
                  <select
                    value={formData.sub_type || ""}
                    onChange={(e) => setFormData({...formData, sub_type: e.target.value})}
                    className="w-full border-2 border-gray-300 rounded-lg p-2"
                  >
                    <option value="">None</option>
                    <option value="outfit">Outfit</option>
                    <option value="accessory">Accessory</option>
                    <option value="decor">Decor</option>
                  </select>
                  <p className="text-xs text-gray-500 mt-1">Determines where item goes in inventory</p>
                </div>
              )}

              {/* Treats (for physical/emotional) */}
              {(formData.item_type === "physical" || formData.item_type === "emotional") && (
                <div>
                  <label className="block text-sm font-semibold mb-2">
                    {formData.item_type === "physical" ? "Restores *" : "Treats Emotion *"}
                  </label>
                  {formData.item_type === "physical" ? (
                    <select
                      value={formData.treats || ""}
                      onChange={(e) => setFormData({...formData, treats: e.target.value})}
                      className="w-full border-2 border-gray-300 rounded-lg p-2"
                    >
                      <option value="">Select...</option>
                      <option value="hunger">Hunger</option>
                      <option value="thirst">Thirst</option>
                      <option value="cleanliness">Cleanliness/Hygiene</option>
                    </select>
                  ) : (
                    <select
                      value={formData.treats || ""}
                      onChange={(e) => setFormData({...formData, treats: e.target.value})}
                      className="w-full border-2 border-gray-300 rounded-lg p-2"
                    >
                      <option value="">Select...</option>
                      <option value="sad">Sad</option>
                      <option value="anxious">Anxious</option>
                      <option value="angry">Angry</option>
                      <option value="sleepy">Sleepy</option>
                      <option value="playful">Playful</option>
                      <option value="brave">Brave</option>
                      <option value="confident">Confident</option>
                    </select>
                  )}
                </div>
              )}

              {/* Effect Amount (for physical items) */}
              {formData.item_type === "physical" && (
                <div>
                  <label className="block text-sm font-semibold mb-2">Effect Amount (%)</label>
                  <Input
                    type="number"
                    min="1"
                    max="100"
                    value={formData.effect_amount || 100}
                    onChange={(e) => setFormData({...formData, effect_amount: parseInt(e.target.value)})}
                  />
                  <p className="text-xs text-gray-500 mt-1">How much % to restore (1-100)</p>
                </div>
              )}

              {/* Emotion Result (for emotional items) */}
              {formData.item_type === "emotional" && (
                <div>
                  <label className="block text-sm font-semibold mb-2">Result Emotion</label>
                  <select
                    value={formData.emotion_result || ""}
                    onChange={(e) => setFormData({...formData, emotion_result: e.target.value})}
                    className="w-full border-2 border-gray-300 rounded-lg p-2"
                  >
                    <option value="">Default (happy/content)</option>
                    <option value="happy">Happy</option>
                    <option value="content">Content</option>
                    <option value="playful">Playful</option>
                    <option value="confident">Confident</option>
                    <option value="brave">Brave</option>
                    <option value="calm">Calm</option>
                  </select>
                  <p className="text-xs text-gray-500 mt-1">What emotion Lumo becomes after use</p>
                </div>
              )}

              <div>
                <label className="block text-sm font-semibold mb-2">Available From</label>
                <Input
                  type="date"
                  value={formData.available_from || ""}
                  onChange={(e) => setFormData({...formData, available_from: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">Available Until</label>
                <Input
                  type="date"
                  value={formData.available_until || ""}
                  onChange={(e) => setFormData({...formData, available_until: e.target.value})}
                />
              </div>

              <div className="md:col-span-2">
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={formData.is_active !== false}
                    onChange={(e) => setFormData({...formData, is_active: e.target.checked})}
                    className="w-4 h-4"
                  />
                  <span className="font-semibold">Active (visible in shop)</span>
                </label>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Items List */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map((item) => (
          <Card key={item.id} className="border-2 border-gray-200">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <div className="text-3xl mb-2">{item.emoji || "📦"}</div>
                  <CardTitle className="text-lg">{item.item_name}</CardTitle>
                </div>
                <div className="flex gap-1">
                  <Button size="sm" variant="ghost" onClick={() => handleEdit(item)}>
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => handleDelete(item)}>
                    <Trash2 className="w-4 h-4 text-red-600" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              <p className="text-sm text-gray-600">{item.description}</p>
              <div className="flex flex-wrap gap-2">
                <Badge className="bg-[#ffa400]">{item.price} 🪙</Badge>
                <Badge variant="outline" className="capitalize">{item.item_type}</Badge>
                {(item.item_type === "physical" || item.item_type === "emotional") && (
                  <Badge className="bg-green-100 text-green-800">Consumable</Badge>
                )}
                {(item.item_type === "decor" || item.item_type === "outfit" || item.item_type === "seasonal") && (
                  <Badge className="bg-purple-100 text-purple-800">One-time</Badge>
                )}
                {!item.is_active && <Badge className="bg-red-100 text-red-800">Inactive</Badge>}
              </div>
              {item.treats && (
                <p className="text-xs text-gray-500">
                  {item.item_type === "physical" ? "Restores:" : "Treats:"} {item.treats}
                </p>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {items.length === 0 && !isEditing && (
        <Card className="border-2 border-gray-200">
          <CardContent className="text-center py-12">
            <div className="text-6xl mb-4">🛍️</div>
            <p className="text-gray-600 mb-4">No shop items yet</p>
            <Button onClick={handleCreate} className="bg-[#66bfad]">
              <Plus className="w-4 h-4 mr-2" />
              Create First Item
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}