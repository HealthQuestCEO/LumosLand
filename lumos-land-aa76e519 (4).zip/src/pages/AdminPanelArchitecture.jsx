
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Database, GitBranch, Users, AlertTriangle, CheckCircle2, XCircle, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Alert, AlertDescription } from "@/components/ui/alert"; // Added Alert and AlertDescription import

export default function AdminPanelArchitecture() {
  const navigate = useNavigate();

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdminPanel"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1165b3]">Admin Panel Architecture</h1>
          <p className="text-gray-600">Current state & critical questions answered</p>
        </div>
      </div>

      {/* Question 1: Where data is saved */}
      <Card className="mb-6 border-2 border-[#66bfad]">
        <CardHeader className="bg-gradient-to-r from-[#66bfad] to-[#1165b3] text-white">
          <CardTitle className="flex items-center gap-2">
            <Database className="w-6 h-6" />
            Q1: Where does the admin panel save lesson data?
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <div className="bg-green-50 p-4 rounded-lg border-2 border-green-200">
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-green-900 mb-2">✅ CURRENT: Base44 Database (Supabase)</h3>
                <ul className="list-disc list-inside space-y-1 text-sm text-green-800">
                  <li><strong>Storage:</strong> All entities stored in Base44's Supabase database</li>
                  <li><strong>Access:</strong> Via <code className="bg-green-100 px-1 rounded">base44.entities.GameLesson.create()</code></li>
                  <li><strong>Persistence:</strong> Data persists across browser sessions</li>
                  <li><strong>Real-time:</strong> Changes visible immediately to all users</li>
                  <li><strong>Backup:</strong> Handled by Base44/Supabase infrastructure</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-red-50 p-4 rounded-lg border-2 border-red-200">
            <div className="flex items-start gap-3">
              <XCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-red-900 mb-2">❌ NOT USED:</h3>
                <ul className="list-disc list-inside space-y-1 text-sm text-red-800">
                  <li><strong>localStorage:</strong> Not used for lesson storage</li>
                  <li><strong>JSON files in repo:</strong> Only used for initial import, not for saving</li>
                  <li><strong>GitHub sync:</strong> Not implemented</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg border-2 border-blue-200">
            <h3 className="font-bold text-blue-900 mb-2">💡 What This Means:</h3>
            <p className="text-sm text-blue-800">
              Lessons you create/import are stored in the cloud database. They're safe and accessible from any device, 
              but there's <strong>no version control or backup to GitHub</strong>. If you delete a lesson in the admin panel, 
              it's gone (unless Base44 has backup policies).
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Question 2: Export/Publish functionality */}
      <Card className="mb-6 border-2 border-[#ffa400]">
        <CardHeader className="bg-gradient-to-r from-[#ffa400] to-[#ff8c00] text-white">
          <CardTitle className="flex items-center gap-2">
            <GitBranch className="w-6 h-6" />
            Q2: Is there a 'Publish' or 'Export' button?
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <div className="bg-red-50 p-4 rounded-lg border-2 border-red-200">
            <div className="flex items-start gap-3">
              <XCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-red-900 mb-2">❌ MISSING: Export Functionality</h3>
                <ul className="list-disc list-inside space-y-1 text-sm text-red-800">
                  <li>No "Export to JSON" button currently exists</li>
                  <li>No way to download lesson data as files</li>
                  <li>No automatic GitHub commit/sync</li>
                  <li>No backup export for disaster recovery</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-green-50 p-4 rounded-lg border-2 border-green-200">
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-green-900 mb-2">✅ WHAT EXISTS: Import Only</h3>
                <ul className="list-disc list-inside space-y-1 text-sm text-green-800">
                  <li><strong>ImportLessonsJSON:</strong> Paste JSON to import lessons</li>
                  <li><strong>HealthQuestBridge:</strong> Fetch lessons from HQ API/Firebase</li>
                  <li><strong>Manual admin panel:</strong> Create lessons one-by-one via forms</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-yellow-50 p-4 rounded-lg border-2 border-yellow-300">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-6 h-6 text-yellow-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-yellow-900 mb-2">⚠️ CRITICAL GAP FOR HEALTHQUEST:</h3>
                <p className="text-sm text-yellow-800 mb-2">
                  For HealthQuest integration, you need a way to:
                </p>
                <ul className="list-disc list-inside space-y-1 text-sm text-yellow-800">
                  <li>Export all lessons as JSON (for sending to HQ team)</li>
                  <li>Version control lesson changes</li>
                  <li>Roll back to previous versions if needed</li>
                  <li>Share lesson data between Lumo's Land and HealthQuest</li>
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* NEW: Question about Images */}
      <Card className="mb-6 border-2 border-red-500">
        <CardHeader className="bg-gradient-to-r from-red-500 to-red-600 text-white">
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-6 h-6" />
            ⚠️ CRITICAL: What About Images?
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <Alert className="bg-yellow-50 border-yellow-300">
            <AlertCircle className="h-4 w-4 text-yellow-600" />
            <AlertDescription className="text-yellow-800">
              <strong>IMPORTANT:</strong> Current exports only include JSON data (which has image URLs). 
              The actual image files are NOT included in exports!
            </AlertDescription>
          </Alert>

          <div className="space-y-3">
            <div className="bg-white p-4 rounded-lg border-2 border-gray-200">
              <h4 className="font-bold text-gray-900 mb-3">📸 Where Images Are Stored:</h4>
              
              <div className="space-y-3 text-sm">
                <div className="bg-blue-50 p-3 rounded border border-blue-200">
                  <p className="font-semibold text-blue-900 mb-1">🦋 Lumo Character Assets</p>
                  <p className="text-blue-800 mb-2">Stored in: <code className="bg-blue-100 px-2 py-1 rounded">Base44 Public Storage</code></p>
                  <p className="text-xs text-blue-700">Mapped via: <code>AssetMapping</code> entity</p>
                  <ul className="list-disc list-inside ml-3 mt-2 space-y-1 text-blue-700">
                    <li>Happy Lumo, Sad Lumo, Angry Lumo, etc.</li>
                    <li>Backgrounds (Winter, Spring, Summer, Fall)</li>
                    <li>URLs stored in AssetMapping entity</li>
                  </ul>
                </div>

                <div className="bg-green-50 p-3 rounded border border-green-200">
                  <p className="font-semibold text-green-900 mb-1">🛍️ Shop Item Images</p>
                  <p className="text-green-800 mb-2">Stored in: <code className="bg-green-100 px-2 py-1 rounded">Base44 Public Storage</code></p>
                  <p className="text-xs text-green-700">Referenced in: <code>ShopItem.image_url</code></p>
                  <ul className="list-disc list-inside ml-3 mt-2 space-y-1 text-green-700">
                    <li>Food items, clothes, decorations</li>
                    <li>Uploaded via "Upload Assets" in Admin Panel</li>
                    <li>URLs like: qtrypzzcjebvfcihiynt.supabase.co/storage/...</li>
                  </ul>
                </div>

                <div className="bg-purple-50 p-3 rounded border border-purple-200">
                  <p className="font-semibold text-purple-900 mb-1">🏆 Badge/Achievement Images</p>
                  <p className="text-purple-800 mb-2">Stored in: <code className="bg-purple-100 px-2 py-1 rounded">Base44 Public Storage</code></p>
                  <p className="text-xs text-purple-700">Referenced in: <code>Badge.badge_emoji</code> or custom URLs</p>
                  <ul className="list-disc list-inside ml-3 mt-2 space-y-1 text-purple-700">
                    <li>Most use emojis (no images needed)</li>
                    <li>Custom badges can have image URLs</li>
                  </ul>
                </div>

                <div className="bg-orange-50 p-3 rounded border border-orange-200">
                  <p className="font-semibold text-orange-900 mb-1">🎨 Other Admin-Uploaded Images</p>
                  <p className="text-orange-800 mb-2">Stored in: <code className="bg-orange-100 px-2 py-1 rounded">Base44 Public Storage</code></p>
                  <ul className="list-disc list-inside ml-3 mt-2 space-y-1 text-orange-700">
                    <li>NPC images (Glow Ridge)</li>
                    <li>Recipe images (Mindful Kitchen)</li>
                    <li>Announcement icons</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="bg-red-50 p-4 rounded-lg border-2 border-red-300">
              <h4 className="font-bold text-red-900 mb-2">❌ What's NOT Being Backed Up:</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-red-800">
                <li>Actual image files (only URLs are exported)</li>
                <li>If Base44 storage goes down, images are lost</li>
                <li>No version history for images</li>
                <li>No easy way to migrate images to another platform</li>
              </ul>
            </div>

            <div className="bg-green-50 p-4 rounded-lg border-2 border-green-300">
              <h4 className="font-bold text-green-900 mb-2">✅ Solution: Image Export Added!</h4>
              <p className="text-sm text-green-800 mb-3">
                Go to <strong>Admin Panel → Export Data</strong> to download:
              </p>
              <ul className="list-disc list-inside space-y-1 text-sm text-green-800">
                <li><strong>JSON export</strong> - All data + image URLs</li>
                <li><strong>Image manifest</strong> - List of all images to download</li>
                <li><strong>Asset mappings</strong> - What images map to what (Lumo states, backgrounds)</li>
              </ul>
              <p className="text-xs text-green-700 mt-3 italic">
                Note: You'll need to manually download images from URLs (or use the batch download feature)
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Question 3: GitHub auto-commit */}
      <Card className="mb-6 border-2 border-purple-500">
        <CardHeader className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
          <CardTitle className="flex items-center gap-2">
            <GitBranch className="w-6 h-6" />
            Q3: Can admin panel auto-commit to GitHub?
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <div className="bg-red-50 p-4 rounded-lg border-2 border-red-200">
            <div className="flex items-start gap-3">
              <XCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-red-900 mb-2">❌ NOT IMPLEMENTED</h3>
                <p className="text-sm text-red-800 mb-2">No GitHub integration currently exists. This would require:</p>
                <ul className="list-disc list-inside space-y-1 text-sm text-red-800">
                  <li>GitHub API authentication (Personal Access Token or GitHub App)</li>
                  <li>Backend function to create commits</li>
                  <li>Export logic to convert database → JSON files</li>
                  <li>UI button: "Save to GitHub" or automatic on every change</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg border-2 border-blue-200">
            <h3 className="font-bold text-blue-900 mb-2">🔧 Implementation Options:</h3>
            <div className="space-y-3 text-sm text-blue-800">
              <div className="bg-white p-3 rounded border border-blue-200">
                <p className="font-semibold mb-1">Option A: Manual Export (Quick Fix)</p>
                <p>Add "Export All Lessons" button → downloads JSON → user manually commits to GitHub</p>
                <p className="text-xs text-blue-600 mt-1">⏱️ Easy to implement (1-2 hours)</p>
              </div>
              <div className="bg-white p-3 rounded border border-blue-200">
                <p className="font-semibold mb-1">Option B: Semi-Automatic (Recommended)</p>
                <p>"Export & Download" → downloads ZIP with all JSON files → user commits via GitHub Desktop/CLI</p>
                <p className="text-xs text-blue-600 mt-1">⏱️ Medium complexity (4-6 hours)</p>
              </div>
              <div className="bg-white p-3 rounded border border-blue-200">
                <p className="font-semibold mb-1">Option C: Full Auto-Commit (Complex)</p>
                <p>Backend function uses GitHub API to auto-commit changes → requires GitHub token management</p>
                <p className="text-xs text-blue-600 mt-1">⏱️ High complexity (1-2 days) + security considerations</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Question 4: Multi-user support */}
      <Card className="mb-6 border-2 border-cyan-500">
        <CardHeader className="bg-gradient-to-r from-cyan-500 to-cyan-600 text-white">
          <CardTitle className="flex items-center gap-2">
            <Users className="w-6 h-6" />
            Q4: Does admin panel support multiple users?
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <div className="bg-green-50 p-4 rounded-lg border-2 border-green-200">
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-green-900 mb-2">✅ YES: Multi-Admin Supported</h3>
                <ul className="list-disc list-inside space-y-1 text-sm text-green-800">
                  <li><strong>User Entity:</strong> Has <code className="bg-green-100 px-1 rounded">role</code> field (admin/user)</li>
                  <li><strong>Access Control:</strong> Admin panel checks <code className="bg-green-100 px-1 rounded">user.role === 'admin'</code></li>
                  <li><strong>Authentication:</strong> Handled by Base44 auth system</li>
                  <li><strong>Multiple admins:</strong> Can have unlimited admin users</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg border-2 border-blue-200">
            <h3 className="font-bold text-blue-900 mb-2">👥 How to Add Clinic Staff as Admins:</h3>
            <ol className="list-decimal list-inside space-y-2 text-sm text-blue-800">
              <li>
                <strong>Invite user via Base44 Dashboard:</strong>
                <ul className="list-disc list-inside ml-6 mt-1">
                  <li>Go to base44.com → Your App → Users</li>
                  <li>Click "Invite User"</li>
                  <li>Enter their email</li>
                </ul>
              </li>
              <li>
                <strong>Set role to 'admin':</strong>
                <ul className="list-disc list-inside ml-6 mt-1">
                  <li>After user accepts invite, edit their record</li>
                  <li>Change <code className="bg-blue-100 px-1 rounded">role</code> from "user" to "admin"</li>
                </ul>
              </li>
              <li>
                <strong>User can now access Admin Panel</strong>
              </li>
            </ol>
          </div>

          <div className="bg-yellow-50 p-4 rounded-lg border-2 border-yellow-300">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-6 h-6 text-yellow-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-yellow-900 mb-2">⚠️ Security Considerations:</h3>
                <ul className="list-disc list-inside space-y-1 text-sm text-yellow-800">
                  <li>All admins have full access (no granular permissions)</li>
                  <li>Any admin can delete/modify any lesson</li>
                  <li>No audit log of who changed what (could add this)</li>
                  <li>No approval workflow (changes are immediate)</li>
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recommendations */}
      <Card className="border-2 border-green-500">
        <CardHeader className="bg-gradient-to-r from-green-500 to-green-600 text-white">
          <CardTitle>🎯 Recommendations for HealthQuest Integration</CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <div className="space-y-3">
            <div className="bg-white p-4 rounded-lg border-2 border-green-200">
              <h3 className="font-bold text-green-900 mb-2">1. ✅ Export Functionality (COMPLETED!)</h3>
              <p className="text-sm text-gray-700 mb-2">
                You can now export all lessons, shop items, NPCs, and complete app data as JSON files.
              </p>
              <Button 
                size="sm"
                onClick={() => navigate(createPageUrl("ExportData"))}
                className="bg-green-600"
              >
                Go to Export Data →
              </Button>
            </div>

            <div className="bg-white p-4 rounded-lg border-2 border-orange-200">
              <h3 className="font-bold text-orange-900 mb-2">2. 🖼️ Image Backup Strategy (NEW!)</h3>
              <p className="text-sm text-gray-700 mb-2">Recommended approach:</p>
              <ol className="list-decimal list-inside text-sm text-gray-700 ml-4 space-y-1">
                <li>Export JSON + image manifest regularly</li>
                <li>Keep a copy of all image URLs</li>
                <li>Consider hosting critical images on HealthQuest's CDN</li>
                <li>Store Lumo character states locally as backup</li>
              </ol>
            </div>

            <div className="bg-white p-4 rounded-lg border-2 border-blue-200">
              <h3 className="font-bold text-blue-900 mb-2">3. Document Data Flow (HIGH PRIORITY)</h3>
              <p className="text-sm text-gray-700">
                Create clear documentation of:
              </p>
              <ul className="list-disc list-inside text-sm text-gray-700 ml-4 mt-1">
                <li>How lessons flow from HealthQuest → Lumo's Land</li>
                <li>How progress flows from Lumo's Land → HealthQuest</li>
                <li>Which system is source of truth for what data</li>
                <li>Where images are hosted and backed up</li>
              </ul>
            </div>

            <div className="bg-white p-4 rounded-lg border-2 border-purple-200">
              <h3 className="font-bold text-purple-900 mb-2">4. Add Audit Logging (MEDIUM PRIORITY)</h3>
              <p className="text-sm text-gray-700">
                Track who created/modified/deleted lessons for accountability
              </p>
            </div>

            <div className="bg-white p-4 rounded-lg border-2 border-yellow-200">
              <h3 className="font-bold text-yellow-900 mb-2">5. GitHub Integration (LOW PRIORITY)</h3>
              <p className="text-sm text-gray-700">
                Nice-to-have for version control, but manual export works fine for now
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
