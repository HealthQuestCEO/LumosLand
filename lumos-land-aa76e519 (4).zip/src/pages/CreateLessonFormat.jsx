
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ArrowLeft, Upload, Save, FileJson, Eye, Plus, Trash2, AlertCircle, Check } from "lucide-react"; // Added 'Check'
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function CreateLessonFormat() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    quest: "",
    number: 0,
    name: "",
    description: "",
    lessonText: "",
    game_format: "mcq",
    game_style: "bubble_pop",
    is_assessment: false,
    assessment_type: null,
    xp_reward: 50,
    coins_reward: 50,
    coins_per_correct: 10,
    questions: [],
    score_mapping: null,
    max_score: null,
    feedback: null,
    keyTakeaways: "",
    is_active: true
  });

  const [jsonInput, setJsonInput] = useState("");
  const [showPreview, setShowPreview] = useState(false);
  const [saving, setSaving] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [jsonError, setJsonError] = useState(null);
  const [activeTab, setActiveTab] = useState("manual");
  const [parseSuccess, setParseSuccess] = useState(false); // Added parseSuccess state

  const mcqExample = {
    quest: "KindnessCrusaders",
    number: 1,
    name: "Understanding Kindness",
    description: "Learn about being kind",
    lessonText: "Welcome! Today we'll learn about kindness and empathy.",
    game_format: "mcq",
    game_style: "bubble_pop",
    xp_reward: 50,
    coins_reward: 50,
    coins_per_correct: 10,
    questions: [
      {
        question: "What is an act of kindness?",
        type: "mcq",
        answers: [
          { text: "Helping someone", correct: true, rationale: "Yes! Helping others is kind." },
          { text: "Being mean", correct: false, rationale: "No, being mean is not kind." },
          { text: "Ignoring people", correct: false },
          { text: "Taking things", correct: false }
        ]
      }
    ],
    keyTakeaways: "Remember to be kind to everyone!",
    is_active: true
  };

  const matchingExample = {
    quest: "KindnessCrusaders",
    number: 2,
    name: "Matching Kindness Actions",
    description: "Match ways to help with the kindness they show",
    lessonText: "Let's match acts of kindness with what they mean!",
    game_format: "matching",
    game_style: "bubble_pop",
    xp_reward: 50,
    coins_reward: 50,
    coins_per_correct: 10,
    questions: [
      {
        question: "Match ways to help with the kindness they show.",
        type: "match",
        options: [
          {
            ans: "Hold the door",
            matching_answer: {
              answerId: "match_0",
              group: "left"
            }
          },
          {
            ans: "Respect",
            matching_answer: {
              answerId: "match_0",
              group: "right"
            }
          },
          {
            ans: "Share crayons",
            matching_answer: {
              answerId: "match_1",
              group: "left"
            }
          },
          {
            ans: "Sharing",
            matching_answer: {
              answerId: "match_1",
              group: "right"
            }
          },
          {
            ans: "Sit with someone alone",
            matching_answer: {
              answerId: "match_2",
              group: "left"
            }
          },
          {
            ans: "Inclusion",
            matching_answer: {
              answerId: "match_2",
              group: "right"
            }
          }
        ],
        keyTakeaways: "• Helping is kindness in action. • Even small helps make a big difference.",
        feedback: {
          high_score: {
            threshold: 3,
            message: "Great job! You matched ways of helping with the kindness they show."
          },
          medium_score: {
            threshold: 2,
            message: "Nice work! You found some good matches for helping."
          },
          low_score: {
            threshold: 0,
            message: "That's okay—every try helps you learn more about helping."
          }
        }
      }
    ],
    keyTakeaways: "Remember: Small acts of kindness make a big difference!",
    is_active: true
  };

  const assessmentExample = {
    quest: "KindnessCrusaders",
    number: 0,
    name: "Pre-Assessment",
    description: "Check your starting knowledge",
    lessonText: "Let's see what you already know!",
    game_format: "likert",
    game_style: "glass_bridge",
    is_assessment: true,
    assessment_type: "pre",
    xp_reward: 0,
    coins_reward: 0,
    questions: [
      {
        question: "I feel confident helping others",
        options: ["Never", "Rarely", "Sometimes", "Often", "Always"]
      },
      {
        question: "I understand when someone is sad",
        options: ["Never", "Rarely", "Sometimes", "Often", "Always"]
      }
    ],
    score_mapping: {
      "Never": 1,
      "Rarely": 2,
      "Sometimes": 3,
      "Often": 4,
      "Always": 5
    },
    max_score: 10,
    feedback: {
      high_score: { threshold: 8, message: "Excellent! You have strong empathy skills." },
      medium_score: { threshold: 5, message: "Good start! Keep learning about kindness." },
      low_score: { threshold: 0, message: "That's okay! This quest will help you grow." }
    },
    keyTakeaways: "Understanding yourself is the first step!",
    is_active: true
  };

  const handleJsonUpload = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const json = JSON.parse(e.target.result);
        setJsonInput(JSON.stringify(json, null, 2));
        parseJsonToForm(json);
        setJsonError(null);
      } catch (err) {
        setJsonError("Invalid JSON file: " + err.message);
        setParseSuccess(false); // Reset success on error
      }
    };
    reader.readAsText(file);
  };

  const parseJsonToForm = (json) => {
    try {
      let gameFormat = "mcq";
      let transformedQuestions = [];

      // Check for Likert format first
      if (json.is_assessment && json.questions?.[0]?.options && json.score_mapping) {
        gameFormat = "likert";
        transformedQuestions = json.questions.map(q => ({
          question: q.question,
          options: q.options
        }));
      }
      // Check for NEW Matching format (type: "match", options with matching_answer)
      else if (json.questions && json.questions.length > 0 && json.questions[0].type === "match" && json.questions[0].options) {
        gameFormat = "matching";
        transformedQuestions = json.questions; // Keep the exact structure as it already matches the target
      }
      // Check for MCQ format (with answers array, potentially with type: "mcq")
      else if (json.questions && Array.isArray(json.questions) && (json.questions[0]?.type === "mcq" || !json.questions[0]?.type) && json.questions[0]?.answers) {
        gameFormat = "mcq";
        transformedQuestions = json.questions.map(q => ({
          question: q.question,
          type: q.type || "mcq", // Include type. If not present, default to "mcq"
          answers: q.answers.map((opt) => ({
            text: opt.text,
            correct: opt.correct,
            rationale: opt.rationale || ""
          })),
          rationale: q.rationale || ""
        }));
      }
      // Fallback for older MCQ format (options and answer index)
      else if (json.questions && Array.isArray(json.questions) && json.questions[0]?.options && typeof json.questions[0]?.answer === 'number') {
        gameFormat = "mcq";
        transformedQuestions = json.questions.map(q => ({
          question: q.question,
          type: "mcq", // Force type to "mcq" for this legacy format
          answers: q.options.map((opt, idx) => ({
            text: opt,
            correct: (idx + 1) === q.answer, // assuming 1-based indexing for `answer`
            rationale: ""
          })),
          rationale: q.rationale || ""
        }));
      }
      else {
        // If no recognized format, default to MCQ with empty questions
        gameFormat = "mcq";
        transformedQuestions = [];
      }

      setFormData({
        quest: json.quest || "",
        number: json.number || 0,
        name: json.name || json.lesson_title || "",
        description: json.description || "",
        lessonText: json.lessonText || json.lesson_text || "",
        game_format: gameFormat,
        game_style: json.game_style || formData.game_style,
        is_assessment: json.is_assessment || false,
        assessment_type: json.assessment_type || null,
        xp_reward: json.xp_total || json.xp_reward || 50,
        coins_reward: json.coins_total || json.coins_reward || 50,
        coins_per_correct: json.coins_per_correct || 10,
        questions: transformedQuestions,
        score_mapping: json.score_mapping || null,
        max_score: json.max_score || null,
        feedback: json.feedback || null,
        keyTakeaways: json.keyTakeaways || json.universal_message || "",
        is_active: json.is_active !== undefined ? json.is_active : true
      });

      setJsonError(null);
      setParseSuccess(true); // Set success on successful parse
      setTimeout(() => setParseSuccess(false), 3000); // Hide success message after 3 seconds
    } catch (err) {
      setJsonError("Error parsing JSON: " + err.message);
      setParseSuccess(false); // Reset success on error
    }
  };

  const handleTextJsonParse = () => {
    try {
      const json = JSON.parse(jsonInput);
      parseJsonToForm(json);
      setJsonError(null);
    } catch (err) {
      setJsonError("Invalid JSON: " + err.message);
      setParseSuccess(false); // Reset success on error
    }
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      setError(null);

      if (!formData.quest || !formData.name) {
        throw new Error("Missing required fields: Quest ID and Lesson Name are required.");
      }
      if (formData.questions.length === 0) { // Generalized validation for all game formats
        throw new Error("At least one question is required.");
      }

      await base44.entities.GameLesson.create(formData);

      setResult({
        success: true,
        message: `Lesson "${formData.name}" created successfully!`
      });

      // Reset form
      setTimeout(() => {
        setFormData({
          quest: "",
          number: 0,
          name: "",
          description: "",
          lessonText: "",
          game_format: "mcq",
          game_style: "bubble_pop",
          is_assessment: false,
          assessment_type: null,
          xp_reward: 50,
          coins_reward: 50,
          coins_per_correct: 10,
          questions: [],
          score_mapping: null,
          max_score: null,
          feedback: null,
          keyTakeaways: "",
          is_active: true
        });
        setJsonInput("");
        setShowPreview(false);
        setResult(null);
        setJsonError(null); // Clear json error on successful save and reset
        setError(null); // Clear general error on successful save and reset
        setParseSuccess(false); // Clear parse success message
      }, 3000);
    } catch (err) {
      setError("Error saving lesson: " + err.message);
    } finally {
      setSaving(false);
    }
  };

  const addMCQQuestion = () => {
    setFormData({
      ...formData,
      questions: [
        ...formData.questions,
        {
          question: "",
          type: "mcq",
          answers: [
            { text: "", correct: true },
            { text: "", correct: false },
            { text: "", correct: false },
            { text: "", correct: false }
          ],
          rationale: ""
        }
      ]
    });
  };

  const removeMCQQuestion = (index) => {
    setFormData({
      ...formData,
      questions: formData.questions.filter((_, i) => i !== index)
    });
  };

  const updateMCQQuestion = (qIndex, field, value) => {
    const newQuestions = [...formData.questions];
    newQuestions[qIndex] = { ...newQuestions[qIndex], [field]: value };
    setFormData({ ...formData, questions: newQuestions });
  };

  const updateMCQAnswer = (qIndex, aIndex, field, value) => {
    const newQuestions = [...formData.questions];
    newQuestions[qIndex].answers[aIndex] = {
      ...newQuestions[qIndex].answers[aIndex],
      [field]: value
    };
    setFormData({ ...formData, questions: newQuestions });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl("AdminPanel"))}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1165b3]">Create Lesson Format</h1>
          <p className="text-gray-600">Build lessons manually or via JSON import</p>
        </div>
      </div>

      {error && (
        <Alert className="mb-6 bg-red-50 border-red-200">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle className="text-red-800">Error</AlertTitle>
          <AlertDescription className="text-red-800">{error}</AlertDescription>
        </Alert>
      )}

      {result && (
        <Alert className="mb-6 bg-green-50 border-green-200">
          <AlertDescription className="text-green-800 font-semibold">{result.message}</AlertDescription>
        </Alert>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="manual">Manual Entry</TabsTrigger>
          <TabsTrigger value="json">JSON Import</TabsTrigger>
        </TabsList>

        {/* Manual Entry Tab */}
        <TabsContent value="manual" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Form Section */}
            <Card>
              <CardHeader>
                <CardTitle>Lesson Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Quest ID *</label>
                    <Input
                      value={formData.quest}
                      onChange={(e) => setFormData({ ...formData, quest: e.target.value })}
                      placeholder="e.g., KindnessCrusaders"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Lesson Number *</label>
                    <Input
                      type="number"
                      value={formData.number}
                      onChange={(e) => setFormData({ ...formData, number: parseInt(e.target.value) })}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Lesson Name *</label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g., Introduction to Kindness"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Description</label>
                  <Textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Short description"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Lesson Intro Text</label>
                  <Textarea
                    value={formData.lessonText}
                    onChange={(e) => setFormData({ ...formData, lessonText: e.target.value })}
                    placeholder="Text shown before the game starts"
                    className="h-24"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Game Format</label>
                    <Select value={formData.game_format} onValueChange={(val) => setFormData({ ...formData, game_format: val })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mcq">Multiple Choice (MCQ)</SelectItem>
                        <SelectItem value="matching">Matching</SelectItem>
                        <SelectItem value="likert">Likert Scale</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Game Style</label>
                    <Select value={formData.game_style} onValueChange={(val) => setFormData({ ...formData, game_style: val })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="bubble_pop">Bubble Pop</SelectItem>
                        <SelectItem value="pin_mountain">Pin Mountain</SelectItem>
                        <SelectItem value="glass_bridge">Glass Bridge</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">XP Reward</label>
                    <Input
                      type="number"
                      value={formData.xp_reward}
                      onChange={(e) => setFormData({ ...formData, xp_reward: parseInt(e.target.value) })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Coins Reward</label>
                    <Input
                      type="number"
                      value={formData.coins_reward}
                      onChange={(e) => setFormData({ ...formData, coins_reward: parseInt(e.target.value) })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Coins/Correct</label>
                    <Input
                      type="number"
                      value={formData.coins_per_correct}
                      onChange={(e) => setFormData({ ...formData, coins_per_correct: parseInt(e.target.value) })}
                    />
                  </div>
                </div>

                <div>
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={formData.is_assessment}
                      onChange={(e) => setFormData({ ...formData, is_assessment: e.target.checked })}
                      className="w-4 h-4"
                    />
                    <span className="text-sm font-medium">This is an assessment</span>
                  </label>
                </div>

                {formData.is_assessment && (
                  <div>
                    <label className="block text-sm font-medium mb-2">Assessment Type</label>
                    <Select value={formData.assessment_type || ""} onValueChange={(val) => setFormData({ ...formData, assessment_type: val })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pre">Pre-Assessment</SelectItem>
                        <SelectItem value="post">Post-Assessment</SelectItem>
                        <SelectItem value="reflection">Reflection</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium mb-2">Key Takeaways</label>
                  <Textarea
                    value={formData.keyTakeaways}
                    onChange={(e) => setFormData({ ...formData, keyTakeaways: e.target.value })}
                    placeholder="Summary message after completion"
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Questions Section */}
          {formData.game_format === "mcq" && (
            <Card className="mt-6">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Questions ({formData.questions.length})</CardTitle>
                  <Button onClick={addMCQQuestion} size="sm" className="bg-[#66bfad]">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Question
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {formData.questions.map((q, qIndex) => (
                  <Card key={qIndex} className="border-2">
                    <CardHeader className="flex flex-row items-center justify-between">
                      <CardTitle className="text-lg">Question {qIndex + 1}</CardTitle>
                      <Button variant="ghost" size="icon" onClick={() => removeMCQQuestion(qIndex)}>
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </Button>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">Question Text</label>
                        <Input
                          value={q.question}
                          onChange={(e) => updateMCQQuestion(qIndex, 'question', e.target.value)}
                          placeholder="Enter question"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">Answers</label>
                        <div className="space-y-2">
                          {q.answers.map((ans, aIndex) => (
                            <div key={aIndex} className="flex gap-2 items-center">
                              <input
                                type="radio"
                                checked={ans.correct}
                                onChange={() => {
                                  const newQuestions = [...formData.questions];
                                  newQuestions[qIndex].answers = newQuestions[qIndex].answers.map((a, i) => ({
                                    ...a,
                                    correct: i === aIndex
                                  }));
                                  setFormData({ ...formData, questions: newQuestions });
                                }}
                                className="w-4 h-4"
                              />
                              <Input
                                value={ans.text}
                                onChange={(e) => updateMCQAnswer(qIndex, aIndex, 'text', e.target.value)}
                                placeholder={`Answer ${aIndex + 1}${ans.correct ? ' (Correct)' : ''}`}
                                className={ans.correct ? "border-green-500" : ""}
                              />
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">Rationale (shown on wrong answer)</label>
                        <Textarea
                          value={q.rationale}
                          onChange={(e) => updateMCQQuestion(qIndex, 'rationale', e.target.value)}
                          placeholder="Explanation for the correct answer"
                        />
                      </div>
                    </CardContent>
                  </Card>
                ))}

                {formData.questions.length === 0 && (
                  <div className="text-center py-12 text-gray-500">
                    No questions added yet. Click "Add Question" or import JSON.
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* JSON Import Tab */}
        <TabsContent value="json" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Import Lesson via JSON</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Examples Section */}
              <div className="space-y-4">
                <h3 className="font-semibold text-lg text-[#1165b3]">📋 JSON Structure Examples</h3>

                <Alert className="bg-blue-50 border-blue-200">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    <p className="font-semibold mb-2">✨ Important Notes:</p>
                    <ul className="list-disc list-inside space-y-1 text-sm">
                      <li><strong>game_format</strong>: "mcq", "matching", or "likert" (assessments)</li>
                      <li><strong>game_style</strong>: "bubble_pop", "pin_mountain", or "glass_bridge"</li>
                      <li><strong>Matching games work in ALL game styles!</strong></li>
                      <li>For matching: use "type": "match" with "options" array containing "ans" and "matching_answer" (answerId + group)</li>
                      <li>Matching questions can have "feedback" with score thresholds</li>
                    </ul>
                  </AlertDescription>
                </Alert>

                <div className="grid md:grid-cols-3 gap-4">
                  {/* MCQ Example */}
                  <Card className="border-2 border-[#66bfad]">
                    <CardHeader>
                      <CardTitle className="text-sm">MCQ Lesson</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <pre className="text-xs bg-gray-50 p-3 rounded overflow-x-auto max-h-64">
                        {JSON.stringify(mcqExample, null, 2)}
                      </pre>
                      <Button
                        onClick={() => {
                          setJsonInput(JSON.stringify(mcqExample, null, 2));
                          setJsonError(null); // Clear any previous JSON errors
                          setParseSuccess(false); // Clear previous parse success
                        }}
                        variant="outline"
                        size="sm"
                        className="w-full mt-3"
                      >
                        Use This Template
                      </Button>
                    </CardContent>
                  </Card>

                  {/* Matching Example */}
                  <Card className="border-2 border-[#ffa400]">
                    <CardHeader>
                      <CardTitle className="text-sm">Matching Lesson</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <pre className="text-xs bg-gray-50 p-3 rounded overflow-x-auto max-h-64">
                        {JSON.stringify(matchingExample, null, 2)}
                      </pre>
                      <Button
                        onClick={() => {
                          setJsonInput(JSON.stringify(matchingExample, null, 2));
                          setJsonError(null); // Clear any previous JSON errors
                          setParseSuccess(false); // Clear previous parse success
                        }}
                        variant="outline"
                        size="sm"
                        className="w-full mt-3"
                      >
                        Use This Template
                      </Button>
                    </CardContent>
                  </Card>

                  {/* Assessment Example */}
                  <Card className="border-2 border-[#1165b3]">
                    <CardHeader>
                      <CardTitle className="text-sm">Assessment (Likert)</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <pre className="text-xs bg-gray-50 p-3 rounded overflow-x-auto max-h-64">
                        {JSON.stringify(assessmentExample, null, 2)}
                      </pre>
                      <Button
                        onClick={() => {
                          setJsonInput(JSON.stringify(assessmentExample, null, 2));
                          setJsonError(null); // Clear any previous JSON errors
                          setParseSuccess(false); // Clear previous parse success
                        }}
                        variant="outline"
                        size="sm"
                        className="w-full mt-3"
                      >
                        Use This Template
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-white text-gray-500">OR</span>
                </div>
              </div>

              {/* JSON Input */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Paste Your JSON</label>
                <Textarea
                  value={jsonInput}
                  onChange={(e) => setJsonInput(e.target.value)}
                  placeholder="Paste your lesson JSON here..."
                  className="min-h-[400px] font-mono text-sm"
                />
              </div>

              {parseSuccess && (
                <Alert className="bg-green-50 border-green-200">
                  <Check className="h-4 w-4 text-green-600" />
                  <AlertTitle className="text-green-800">Parse Complete!</AlertTitle>
                  <AlertDescription className="text-green-700">
                    JSON parsed successfully. You can now preview or save the lesson.
                  </AlertDescription>
                </Alert>
              )}

              <Button onClick={handleTextJsonParse} className="w-full bg-[#66bfad]">
                <Upload className="w-4 h-4 mr-2" />
                Parse JSON
              </Button>

              {jsonError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>JSON Error</AlertTitle>
                  <AlertDescription>{jsonError}</AlertDescription>
                </Alert>
              )}

              <div>
                <label className="block text-sm font-medium mb-2">Upload JSON File</label>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleJsonUpload}
                  className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-[#66bfad] file:text-white hover:file:bg-[#1165b3]"
                />
              </div>

            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>


      {/* Preview & Save */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Preview & Save</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button
            onClick={() => setShowPreview(!showPreview)}
            variant="outline"
            className="w-full"
          >
            <Eye className="w-4 h-4 mr-2" />
            {showPreview ? "Hide" : "Show"} JSON Preview
          </Button>

          {showPreview && (
            <div className="bg-gray-50 p-4 rounded-lg">
              <pre className="text-xs overflow-x-auto text-gray-800">
                {JSON.stringify(formData, null, 2)}
              </pre>
            </div>
          )}

          <div className="flex gap-3">
            <Button
              onClick={handleSave}
              disabled={saving || !formData.quest || !formData.name || formData.questions.length === 0}
              className="flex-1 bg-[#1165b3]"
            >
              <Save className="w-4 h-4 mr-2" />
              {saving ? "Saving..." : "Save Lesson"}
            </Button>
            <Button
              onClick={() => navigate(createPageUrl("AdminPanel"))}
              variant="outline"
              className="flex-1"
            >
              Back to Admin
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
