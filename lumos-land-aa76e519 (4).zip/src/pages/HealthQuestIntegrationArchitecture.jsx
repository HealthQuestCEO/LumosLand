
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function HealthQuestIntegrationArchitecture() {
  const navigate = useNavigate();

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdminPanel"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1165b3]">HealthQuest Integration Architecture</h1>
          <p className="text-gray-600">Technical documentation for Lumo's Land ↔ HealthQuest integration</p>
        </div>
      </div>

      {/* Executive Summary */}
      <Card className="mb-6 border-2 border-[#66bfad]">
        <CardHeader className="bg-gradient-to-r from-[#66bfad] to-[#1165b3] text-white">
          <CardTitle>📋 Executive Summary</CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <p className="text-lg"><strong>Integration Goal:</strong> Embed Lumo's Land as an iframe inside HealthQuest, replacing the existing "Lumo's Den" module.</p>
          
          <div className="bg-blue-50 p-4 rounded-lg border-2 border-blue-200">
            <h3 className="font-bold text-blue-900 mb-2">🎯 Key Objectives:</h3>
            <ul className="list-disc list-inside space-y-1 text-blue-800">
              <li>Single Sign-On (SSO) authentication between HealthQuest and Lumo's Land</li>
              <li>Bidirectional data sync (user progress, coins, XP, lesson completions)</li>
              <li>Seamless iframe embedding with responsive design</li>
              <li>Real-time progress tracking and rewards system</li>
            </ul>
          </div>

          <div className="bg-green-50 p-4 rounded-lg border-2 border-green-200">
            <h3 className="font-bold text-green-900 mb-2">✅ What's Already Built in Lumo's Land:</h3>
            <ul className="list-disc list-inside space-y-1 text-green-800">
              <li>Firebase SDK integration (connected to HealthQuest Firebase project)</li>
              <li>Backend bridge functions for API communication</li>
              <li>Lesson import system (supports HealthQuest JSON format)</li>
              <li>User progress tracking (coins, XP, badges, level system)</li>
              <li>Game engines (Bubble Pop, Pin Mountain, Glass Bridge) with MCQ + Matching support</li>
              <li>Care loop activities (emotion recognition, journaling, NPC interactions)</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Add Assessment Routing Rules Card */}
      <Card className="mb-6 border-2 border-red-500">
        <CardHeader className="bg-gradient-to-r from-red-500 to-red-600 text-white">
          <CardTitle>⚠️ Assessment Routing Rules (CRITICAL)</CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <div className="bg-red-50 p-4 rounded-lg border-2 border-red-300">
            <h3 className="font-bold text-red-900 mb-3">🎯 Assessment Game Style Override:</h3>
            <div className="space-y-2 text-sm text-red-800">
              <p className="font-bold">ALL assessments MUST use Bubble Pop MCQ format ONLY:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li><strong>Pre-assessments</strong> (number: 0) → Bubble Pop MCQ</li>
                <li><strong>Post-assessments</strong> (number: 101) → Bubble Pop MCQ</li>
                <li><strong>Feedback forms</strong> (number: 102) → Bubble Pop MCQ</li>
              </ul>
              <p className="mt-3 font-semibold">❌ Assessments NEVER use:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Matching games</li>
                <li>Pin Mountain</li>
                <li>Glass Bridge</li>
              </ul>
            </div>
          </div>

          <div className="bg-yellow-50 p-4 rounded-lg border-2 border-yellow-300">
            <h3 className="font-bold text-yellow-900 mb-2">🔧 Implementation Details:</h3>
            <p className="text-sm text-yellow-800 mb-2">
              The <code className="bg-yellow-200 px-2 py-1 rounded">GameSessionRouter</code> component checks:
            </p>
            <pre className="bg-gray-800 text-green-400 p-3 rounded overflow-x-auto text-xs">
{`if (lesson?.is_assessment) {
  // FORCE route to Bubble Pop MCQ
  // Ignores game_style and type fields
  return <BubbleGameSession ... />;
}`}
            </pre>
            <p className="text-sm text-yellow-800 mt-2">
              This ensures assessments are always presented in the same consistent format for data comparison.
            </p>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg border-2 border-blue-300">
            <h3 className="font-bold text-blue-900 mb-2">📊 Why This Matters:</h3>
            <ul className="list-disc list-inside space-y-1 text-sm text-blue-800">
              <li>Ensures consistent pre/post assessment comparison</li>
              <li>Maintains data integrity for progress tracking</li>
              <li>Prevents game style from affecting assessment scores</li>
              <li>Simplifies reporting and analytics</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Source of Truth */}
      <Card className="mb-6 border-2 border-[#ffa400]">
        <CardHeader className="bg-gradient-to-r from-[#ffa400] to-[#ff8c00] text-white">
          <CardTitle>🏛️ Source of Truth</CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-purple-50 p-4 rounded-lg border-2 border-purple-200">
              <h3 className="font-bold text-purple-900 mb-2">HealthQuest (Primary Source)</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-purple-800">
                <li><strong>User Authentication</strong> - Firebase Auth</li>
                <li><strong>User Profiles</strong> - Name, email, subscription</li>
                <li><strong>Lesson Content</strong> - Quests, lessons, questions</li>
                <li><strong>Initial Coins/XP</strong> - Baseline rewards</li>
              </ul>
            </div>

            <div className="bg-cyan-50 p-4 rounded-lg border-2 border-cyan-200">
              <h3 className="font-bold text-cyan-900 mb-2">Lumo's Land (Secondary/Sync)</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-cyan-800">
                <li><strong>Lumo State</strong> - Pet needs, emotion, season</li>
                <li><strong>Activity Logs</strong> - Daily care loop tracking</li>
                <li><strong>Lesson Completions</strong> - Scores, attempts</li>
                <li><strong>Earned Coins/XP</strong> - Synced back to HQ</li>
              </ul>
            </div>
          </div>

          <div className="bg-yellow-50 p-4 rounded-lg border-2 border-yellow-300">
            <h3 className="font-bold text-yellow-900 mb-2">⚠️ Sync Strategy:</h3>
            <p className="text-yellow-800 text-sm">
              <strong>Pull from HealthQuest:</strong> User auth, lessons, initial progress<br />
              <strong>Push to HealthQuest:</strong> Lesson completions, earned coins/XP, care loop activities, badges
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Authentication Flow */}
      <Card className="mb-6 border-2 border-[#1165b3]">
        <CardHeader className="bg-gradient-to-r from-[#1165b3] to-[#66bfad] text-white">
          <CardTitle>🔐 Authentication & Authorization Flow</CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <div className="bg-gray-50 p-4 rounded-lg border-2 border-gray-300">
            <h3 className="font-bold mb-3">Option 1: Firebase Token Passing (Recommended)</h3>
            <ol className="list-decimal list-inside space-y-2 text-sm">
              <li>User logs into HealthQuest (Firebase Auth)</li>
              <li>HealthQuest generates Firebase ID token: <code className="bg-gray-200 px-2 py-1 rounded">await user.getIdToken()</code></li>
              <li>HealthQuest embeds Lumo's Land iframe with token in URL:
                <pre className="bg-gray-800 text-green-400 p-2 rounded mt-2 overflow-x-auto">
{`<iframe src="https://lumosland.base44.com?token=<FIREBASE_TOKEN>" />`}
                </pre>
              </li>
              <li>Lumo's Land validates token on page load:
                <pre className="bg-gray-800 text-green-400 p-2 rounded mt-2 overflow-x-auto text-xs">
{`import { signInWithCustomToken } from 'firebase/auth';
const token = new URLSearchParams(window.location.search).get('token');
await signInWithCustomToken(auth, token);`}
                </pre>
              </li>
              <li>Lumo's Land fetches user data from HealthQuest API</li>
            </ol>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg border-2 border-blue-300">
            <h3 className="font-bold mb-3">Option 2: OAuth / JWT Flow (Alternative)</h3>
            <p className="text-sm text-blue-800 mb-2">If Firebase token passing isn't feasible:</p>
            <ol className="list-decimal list-inside space-y-2 text-sm text-blue-800">
              <li>HealthQuest generates JWT with user data</li>
              <li>Passes JWT to Lumo's Land iframe</li>
              <li>Lumo's Land validates JWT signature</li>
              <li>Creates/updates Lumo user session</li>
            </ol>
          </div>

          <div className="bg-red-50 p-4 rounded-lg border-2 border-red-300">
            <h3 className="font-bold text-red-900 mb-2">🚨 Security Requirements:</h3>
            <ul className="list-disc list-inside space-y-1 text-sm text-red-800">
              <li>Tokens must expire (15-30 min recommended)</li>
              <li>HTTPS only for all communications</li>
              <li>CORS headers configured for iframe domain</li>
              <li>Refresh token mechanism for long sessions</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* API Endpoints Needed */}
      <Card className="mb-6 border-2 border-green-500">
        <CardHeader className="bg-gradient-to-r from-green-500 to-green-600 text-white">
          <CardTitle>📡 API Endpoints HealthQuest Needs to Provide</CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          
          {/* User Endpoints */}
          <div className="border-2 border-green-200 rounded-lg p-4">
            <h3 className="font-bold text-green-900 mb-3">👤 User Management</h3>
            <div className="space-y-3 text-sm">
              <div className="bg-white p-3 rounded border-l-4 border-green-500">
                <code className="text-green-700 font-bold">GET /api/users/:userId/profile</code>
                <p className="text-gray-600 mt-1">Returns: user_id, email, full_name, subscription_tier, subscription_status, total_coins, total_xp, level, badges[]</p>
              </div>
              
              <div className="bg-white p-3 rounded border-l-4 border-green-500">
                <code className="text-green-700 font-bold">POST /api/users/:userId/sync-progress</code>
                <p className="text-gray-600 mt-1">Body: {`{total_coins, total_xp, level, badges, last_synced}`}</p>
                <p className="text-gray-600">Purpose: Lumo's Land pushes earned coins/XP back to HealthQuest</p>
              </div>
            </div>
          </div>

          {/* Lesson Endpoints */}
          <div className="border-2 border-blue-200 rounded-lg p-4">
            <h3 className="font-bold text-blue-900 mb-3">📚 Lesson Content</h3>
            <div className="space-y-3 text-sm">
              <div className="bg-white p-3 rounded border-l-4 border-blue-500">
                <code className="text-blue-700 font-bold">GET /api/quests</code>
                <p className="text-gray-600 mt-1">Returns: List of available quests (quest_id, name, description, is_active)</p>
              </div>
              
              <div className="bg-white p-3 rounded border-l-4 border-blue-500">
                <code className="text-blue-700 font-bold">GET /api/quests/:questId/lessons</code>
                <p className="text-gray-600 mt-1">Returns: All lessons for a quest (including pre/post assessments)</p>
                <p className="text-gray-600 mt-1">Format: HealthQuest JSON (Lumo's Land will normalize it)</p>
              </div>

              <div className="bg-white p-3 rounded border-l-4 border-blue-500">
                <code className="text-blue-700 font-bold">GET /api/lessons/:lessonId</code>
                <p className="text-gray-600 mt-1">Returns: Single lesson with questions[], type, game_style, rewards</p>
              </div>
            </div>
          </div>

          {/* Progress Endpoints */}
          <div className="border-2 border-purple-200 rounded-lg p-4">
            <h3 className="font-bold text-purple-900 mb-3">📊 Progress Tracking</h3>
            <div className="space-y-3 text-sm">
              <div className="bg-white p-3 rounded border-l-4 border-purple-500">
                <code className="text-purple-700 font-bold">POST /api/lessons/:lessonId/complete</code>
                <p className="text-gray-600 mt-1">Body: {`{user_id, score, total_questions, coins_earned, xp_earned, completed_date}`}</p>
                <p className="text-gray-600">Called when user completes a lesson in Lumo's Land</p>
              </div>

              <div className="bg-white p-3 rounded border-l-4 border-purple-500">
                <code className="text-purple-700 font-bold">POST /api/assessments/score</code>
                <p className="text-gray-600 mt-1">Body: {`{user_id, assessment_type, total_score, max_score, feedback_tier, answers[]}`}</p>
                <p className="text-gray-600">Stores pre/post assessment results</p>
              </div>

              <div className="bg-white p-3 rounded border-l-4 border-purple-500">
                <code className="text-purple-700 font-bold">GET /api/users/:userId/progress</code>
                <p className="text-gray-600 mt-1">Returns: completed_lessons[], current_quest, progress_percentage</p>
              </div>
            </div>
          </div>

          {/* Care Loop Endpoints */}
          <div className="border-2 border-orange-200 rounded-lg p-4">
            <h3 className="font-bold text-orange-900 mb-3">💖 Care Loop Activities</h3>
            <div className="space-y-3 text-sm">
              <div className="bg-white p-3 rounded border-l-4 border-orange-500">
                <code className="text-orange-700 font-bold">POST /api/care-loop/log</code>
                <p className="text-gray-600 mt-1">Body: {`{user_id, activity_date, emotion_recognitions, journal_entries, npc_interactions, naps_taken, care_loop_xp, care_loop_coins}`}</p>
                <p className="text-gray-600">Daily sync of non-lesson activities</p>
              </div>

              <div className="bg-white p-3 rounded border-l-4 border-orange-500">
                <code className="text-orange-700 font-bold">POST /api/journals</code>
                <p className="text-gray-600 mt-1">Body: {`{user_id, entry_date, content, mood, journal_type: 'regular'|'reflection'|'meal', xp_earned, coins_earned}`}</p>
              </div>
            </div>
          </div>

          {/* Shop/Purchases */}
          <div className="border-2 border-pink-200 rounded-lg p-4">
            <h3 className="font-bold text-pink-900 mb-3">🛍️ Shop & Purchases</h3>
            <div className="space-y-3 text-sm">
              <div className="bg-white p-3 rounded border-l-4 border-pink-500">
                <code className="text-pink-700 font-bold">POST /api/purchases</code>
                <p className="text-gray-600 mt-1">Body: {`{user_id, item_id, coins_spent, purchase_date}`}</p>
                <p className="text-gray-600">Track when user buys items from Lumo's Nook</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Data Lumo's Land Needs */}
      <Card className="mb-6 border-2 border-purple-500">
        <CardHeader className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
          <CardTitle>📥 Data Lumo's Land Needs from HealthQuest</CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <div className="bg-purple-50 p-4 rounded-lg border-2 border-purple-200">
            <h3 className="font-bold text-purple-900 mb-2">On Initial Load (User Login):</h3>
            <ul className="list-disc list-inside space-y-1 text-sm text-purple-800">
              <li>Firebase authentication token</li>
              <li>User profile (email, name, subscription tier)</li>
              <li>Current coins/XP balance</li>
              <li>Completed lessons list</li>
              <li>Earned badges</li>
            </ul>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg border-2 border-blue-200">
            <h3 className="font-bold text-blue-900 mb-2">For Lesson Gameplay:</h3>
            <ul className="list-disc list-inside space-y-1 text-sm text-blue-800">
              <li>Lesson content (questions, answers, rationales)</li>
              <li>Game style assignment (bubble_pop, pin_mountain, glass_bridge)</li>
              <li>Reward amounts (coins_per_correct, xp_reward, coins_reward)</li>
              <li>Assessment scoring rules (for pre/post tests)</li>
            </ul>
          </div>

          <div className="bg-green-50 p-4 rounded-lg border-2 border-green-200">
            <h3 className="font-bold text-green-900 mb-2">For Care Loop Features:</h3>
            <ul className="list-disc list-inside space-y-1 text-sm text-green-800">
              <li>Daily XP/coin caps (to prevent farming)</li>
              <li>NPC conversation content (if managed in HQ)</li>
              <li>Journal prompt questions</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Iframe Embedding Guide */}
      <Card className="mb-6 border-2 border-cyan-500">
        <CardHeader className="bg-gradient-to-r from-cyan-500 to-cyan-600 text-white">
          <CardTitle>🖼️ Iframe Embedding Guide</CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <div className="bg-gray-50 p-4 rounded-lg border-2 border-gray-300">
            <h3 className="font-bold mb-3">Basic Iframe Code (HealthQuest side):</h3>
            <pre className="bg-gray-800 text-green-400 p-4 rounded overflow-x-auto text-xs">
{`// In HealthQuest React component
import { useEffect, useState } from 'react';
import { auth } from './firebase';

export function LumosLand() {
  const [iframeUrl, setIframeUrl] = useState('');

  useEffect(() => {
    async function loadLumo() {
      const user = auth.currentUser;
      if (!user) return;
      
      // Get Firebase ID token
      const token = await user.getIdToken();
      
      // Build Lumo's Land URL with auth token
      const url = \`https://lumosland.base44.com?token=\${token}&user_id=\${user.uid}\`;
      setIframeUrl(url);
    }
    loadLumo();
  }, []);

  return (
    <iframe
      src={iframeUrl}
      style={{
        width: '100%',
        height: '100vh',
        border: 'none',
        borderRadius: '12px'
      }}
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
      allowFullScreen
    />
  );
}`}
            </pre>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg border-2 border-blue-200">
            <h3 className="font-bold text-blue-900 mb-2">🔧 CORS Configuration Needed:</h3>
            <pre className="bg-gray-800 text-green-400 p-3 rounded overflow-x-auto text-xs">
{`// HealthQuest API server needs these headers:
Access-Control-Allow-Origin: https://lumosland.base44.com
Access-Control-Allow-Credentials: true
Access-Control-Allow-Methods: GET, POST, PUT, DELETE
Access-Control-Allow-Headers: Content-Type, Authorization`}
            </pre>
          </div>

          <div className="bg-yellow-50 p-4 rounded-lg border-2 border-yellow-300">
            <h3 className="font-bold text-yellow-900 mb-2">📱 Responsive Design:</h3>
            <p className="text-sm text-yellow-800">Lumo's Land is fully responsive. Recommended iframe sizes:</p>
            <ul className="list-disc list-inside space-y-1 text-sm text-yellow-800 mt-2">
              <li><strong>Desktop:</strong> 100% width, 100vh height</li>
              <li><strong>Tablet:</strong> 100% width, 90vh height</li>
              <li><strong>Mobile:</strong> 100% width, 100vh height (full screen recommended)</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Data Already in Lumo's Land */}
      <Card className="mb-6 border-2 border-teal-500">
        <CardHeader className="bg-gradient-to-r from-teal-500 to-teal-600 text-white">
          <CardTitle>✅ What's Already Built in Lumo's Land</CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-teal-50 p-4 rounded-lg border-2 border-teal-200">
              <h3 className="font-bold text-teal-900 mb-2">🎮 Game Engines:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-teal-800">
                <li>Bubble Pop (MCQ + Matching)</li>
                <li>Pin Mountain (MCQ + Matching)</li>
                <li>Glass Bridge (MCQ + Matching)</li>
                <li>Assessment mode (Bubble Pop MCQ only)</li>
              </ul>
            </div>

            <div className="bg-cyan-50 p-4 rounded-lg border-2 border-cyan-200">
              <h3 className="font-bold text-cyan-900 mb-2">📊 Progress Tracking:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-cyan-800">
                <li>LumoState (pet needs, emotions)</li>
                <li>ActivityLog (daily tracking)</li>
                <li>LessonCompletion records</li>
                <li>AssessmentScore tracking</li>
              </ul>
            </div>

            <div className="bg-purple-50 p-4 rounded-lg border-2 border-purple-200">
              <h3 className="font-bold text-purple-900 mb-2">💖 Care Loop:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-purple-800">
                <li>Emotion identification game</li>
                <li>Journal reflection system</li>
                <li>Glow Ridge NPCs</li>
                <li>Nap/rest tracking</li>
              </ul>
            </div>

            <div className="bg-orange-50 p-4 rounded-lg border-2 border-orange-200">
              <h3 className="font-bold text-orange-900 mb-2">🛍️ Economy System:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-orange-800">
                <li>Coins & XP tracking</li>
                <li>Lumo's Nook (shop)</li>
                <li>Inventory system</li>
                <li>Daily spinner rewards</li>
              </ul>
            </div>
          </div>

          <div className="bg-green-50 p-4 rounded-lg border-2 border-green-200">
            <h3 className="font-bold text-green-900 mb-2">🔧 Backend Functions:</h3>
            <ul className="list-disc list-inside space-y-1 text-sm text-green-800">
              <li><code>healthQuestBridge</code> - Sync data with HealthQuest API</li>
              <li><code>importLessons</code> - Import lessons from HQ JSON format</li>
              <li><code>glowRidgeConversations</code> - NPC interaction logic</li>
              <li><code>dopamineCheckin</code> - Dopamine awareness module</li>
              <li><code>mindfulMunchies</code> - Mindful eating game</li>
              <li><code>stripeWebhook</code> - Payment processing</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Environment Variables */}
      <Card className="mb-6 border-2 border-red-500">
        <CardHeader className="bg-gradient-to-r from-red-500 to-red-600 text-white">
          <CardTitle>🔐 Environment Variables Configured</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <pre className="bg-gray-800 text-green-400 p-4 rounded overflow-x-auto text-xs">
{`VITE_API_SERVER_URL = "https://api-dev.discoverhealthquest.com"
VITE_STRIPE_PUBLISHABLE_KEY = "pk_test_..."
VITE_FIREBASE_API_KEY = "AIzaSyD3bQBANozGzirsNJsOpHYn0dED2kmNbss"
VITE_FIREBASE_AUTH_DOMAIN = "healthquest-8e631.firebaseapp.com"
VITE_FIREBASE_PROJECT_ID = "healthquest-8e631"
VITE_FIREBASE_APP_ID = "1:441238628799:web:477a4da266b34f678c590a"
VITE_FIREBASE_STORAGE_BUCKET = "healthquest-8e631.firebasestorage.app"
VITE_FIREBASE_MESSAGING_SENDER_ID = "441238628799"`}
          </pre>
        </CardContent>
      </Card>

      {/* Next Steps */}
      <Card className="border-2 border-[#1165b3]">
        <CardHeader className="bg-gradient-to-r from-[#1165b3] to-[#66bfad] text-white">
          <CardTitle>🚀 Next Steps for Integration</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-500">
              <h3 className="font-bold text-blue-900 mb-2">1️⃣ HealthQuest Team Actions:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-blue-800">
                <li>Review API endpoints list above</li>
                <li>Implement required endpoints with JSON responses</li>
                <li>Configure CORS for lumosland.base44.com domain</li>
                <li>Set up Firebase token generation for iframe auth</li>
                <li>Test API endpoints with Postman/curl</li>
              </ul>
            </div>

            <div className="bg-green-50 p-4 rounded-lg border-l-4 border-green-500">
              <h3 className="font-bold text-green-900 mb-2">2️⃣ Lumo's Land Team Actions:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-green-800">
                <li>Complete token validation on page load</li>
                <li>Test API integration with HQ endpoints</li>
                <li>Implement bidirectional sync functions</li>
                <li>Add error handling & fallbacks</li>
                <li>Prepare demo/test environment</li>
              </ul>
            </div>

            <div className="bg-purple-50 p-4 rounded-lg border-l-4 border-purple-500">
              <h3 className="font-bold text-purple-900 mb-2">3️⃣ Joint Testing:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-purple-800">
                <li>Test iframe embedding in dev environment</li>
                <li>Verify SSO authentication flow</li>
                <li>Test lesson loading & completion sync</li>
                <li>Verify coins/XP sync both directions</li>
                <li>Load testing with multiple concurrent users</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
