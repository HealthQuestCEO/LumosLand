
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, ShoppingCart, AlertCircle, Plus } from "lucide-react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { add } from "date-fns";

export default function LumosNook() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const needParam = searchParams.get("need");

  const [user, setUser] = useState(null);
  const [lumoState, setLumoState] = useState(null);
  const [shopItems, setShopItems] = useState([]);
  const [filter, setFilter] = useState("all");
  const [isPurchasing, setIsPurchasing] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // showPurchaseSuccess and purchaseMessage states are no longer needed, replaced by showLumoAlert
  // const [showPurchaseSuccess, setShowPurchaseSuccess] = useState(false);
  // const [purchaseMessage, setPurchaseMessage] = useState("");

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (needParam) {
      if (["hungry", "thirsty", "dirty"].includes(needParam)) {
        setFilter("physical");
      } else if (["sad", "anxious", "angry", "sleepy", "playful", "brave", "confident"].includes(needParam)) {
        setFilter("emotional");
      }
    }
  }, [needParam]);

  const loadData = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      let states = await base44.entities.LumoState.filter({ user_email: currentUser.email });
      
      let state;
      if (states.length > 0) {
        state = states[0];
      } else {
        const now = new Date().toISOString();
        state = await base44.entities.LumoState.create({
          user_email: currentUser.email,
          lumo_name: "Lumo",
          hunger: 100,
          thirst: 100,
          cleanliness: 100,
          emotional_need: 100,
          current_emotion_state: "happy",
          last_fed_time: now,
          last_watered_time: now,
          last_cleaned_time: now,
          last_emotion_change_time: now,
          fly_away_check_time: add(new Date(), { days: 3 }).toISOString(),
          total_coins: 100,
          total_xp: 0
        });
      }
      setLumoState(state);

      const allItems = await base44.entities.ShopItem.list();
      const activeItems = allItems.filter(item => item.is_active !== false);
      
      const today = new Date().toISOString().split('T')[0];
      const availableItems = activeItems.filter(item => {
        if (item.available_from && today < item.available_from) return false;
        if (item.available_until && today > item.available_until) return false;
        return true;
      });
      
      setShopItems(availableItems);
    } catch (error) {
      console.error("Error loading data:", error);
      setError("Error loading shop: " + error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const showLumoAlert = (title, message, type = "success") => {
    const alertDiv = document.createElement('div');
    alertDiv.className = 'lumo-alert-overlay';
    
    const bgGradient = type === "success" 
      ? "from-[#66bfad] to-[#1165b3]" 
      : type === "error"
      ? "from-[#ffa400] to-[#ff8c00]"
      : "from-[#00d1ff] to-[#66bfad]";
    
    const emoji = type === "success" ? "✨" : type === "error" ? "💡" : "🌟";
    const borderColor = type === "success" ? "#66bfad" : type === "error" ? "#ffa400" : "#00d1ff";
    
    alertDiv.innerHTML = `
      <div style="position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 9999; padding: 1rem;">
        <div style="background: linear-gradient(135deg, #e0f8f5 0%, #ffffff 100%); border-radius: 24px; padding: 2rem; max-width: 400px; width: 100%; box-shadow: 0 20px 60px rgba(0,0,0,0.3); border: 4px solid ${borderColor}; animation: slideIn 0.3s ease-out;">
          <div style="text-align: center;">
            <div style="font-size: 4rem; margin-bottom: 1rem; animation: bounce 0.6s ease-in-out;">${emoji}</div>
            <div style="background: linear-gradient(135deg, ${bgGradient.replace('from-', '').replace('to-', ', ')}); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; font-size: 1.75rem; font-weight: bold; margin-bottom: 0.75rem;">${title}</div>
            <div style="color: #1165b3; font-size: 1.25rem; font-weight: 600; margin-bottom: 1.5rem;">${message}</div>
            <button onclick="this.closest('.lumo-alert-overlay').remove()" style="background: linear-gradient(135deg, ${bgGradient.replace('from-', '').replace('to-', ', ')}); color: white; border: none; padding: 0.875rem 2.5rem; border-radius: 16px; font-size: 1.125rem; font-weight: bold; cursor: pointer; box-shadow: 0 4px 12px rgba(102, 191, 173, 0.4); transition: transform 0.2s;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">Got it! 🎉</button>
          </div>
        </div>
      </div>
      <style>
        @keyframes slideIn {
          from { transform: translateY(-50px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        @keyframes bounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-20px); }
        }
      </style>
    `;
    
    document.body.appendChild(alertDiv);
    
    setTimeout(() => {
      if (alertDiv.parentNode) {
        alertDiv.remove();
      }
    }, 4000);
  };

  const handlePurchase = async (item) => {
    if (!lumoState || lumoState.total_coins < item.price) {
      showLumoAlert("Let's earn more coins first! 💰", `You need ${item.price} coins. You have ${lumoState.total_coins} coins.`, "info");
      return;
    }

    // Only check purchase history for non-consumable items (decor, outfit, seasonal)
    const isConsumable = item.item_type === "physical" || item.item_type === "emotional";
    
    if (!isConsumable) {
      const previousPurchases = await base44.entities.PurchaseHistory.filter({
        user_email: user.email,
        item_id: item.item_id
      });

      if (previousPurchases.length > 0) {
        showLumoAlert("You already have this! 🎁", "Each item can only be purchased once. Check your Attic!", "info");
        return;
      }
    }

    setIsPurchasing(item.item_id);

    try {
      let updates = { 
        total_coins: lumoState.total_coins - item.price 
      };
      let alertMessage = `Purchased ${item.item_name}! 🎉`;

      if (item.item_type === "physical") {
        const fillPercent = (item.price / 20) * 100;

        if (item.treats === "hunger") {
          updates.hunger = Math.min(100, lumoState.hunger + fillPercent);
          updates.last_fed_time = new Date().toISOString();
          alertMessage = `${item.item_name} restored ${Math.round(fillPercent)}% hunger!`;
        } else if (item.treats === "thirst") {
          updates.thirst = Math.min(100, lumoState.thirst + fillPercent);
          updates.last_watered_time = new Date().toISOString();
          alertMessage = `${item.item_name} restored ${Math.round(fillPercent)}% thirst!`;
        } else if (item.treats === "cleanliness") {
          updates.cleanliness = Math.min(100, lumoState.cleanliness + fillPercent);
          updates.last_cleaned_time = new Date().toISOString();
          alertMessage = `${item.item_name} restored ${Math.round(fillPercent)}% hygiene!`;
        }

        updates.fly_away_check_time = add(new Date(), { days: 3 }).toISOString();

        const newHunger = updates.hunger !== undefined ? updates.hunger : lumoState.hunger;
        const newThirst = updates.thirst !== undefined ? updates.thirst : lumoState.thirst;
        const newCleanliness = updates.cleanliness !== undefined ? updates.cleanliness : lumoState.cleanliness;

        if (newHunger > 70 && newThirst > 70 && newCleanliness > 70) {
          updates.current_emotion_state = "happy";
          updates.emotional_need = 100;
          updates.last_emotion_change_time = new Date().toISOString();
          alertMessage += " Lumo is now happy! 😊";
        }

      } else if (item.item_type === "emotional") {
        updates.emotional_need = 100;
        updates.last_emotion_change_time = new Date().toISOString();
        
        if (item.treats === lumoState.current_emotion_state) {
          const resultEmotion = item.emotion_result || "happy";
          updates.current_emotion_state = resultEmotion;
          updates.total_coins = lumoState.total_coins - item.price + 10;
          updates.total_xp = (lumoState.total_xp || 0) + 50;
          alertMessage = `Perfect match! ${item.item_name} made Lumo ${resultEmotion}! +50 XP, +10 coins back!`;
        } else {
          const resultEmotion = item.emotion_result || "content";
          updates.current_emotion_state = resultEmotion;
          alertMessage = `${item.item_name} helped! Lumo is now ${resultEmotion}.`;
        }
        
      } else if (item.item_type === 'seasonal' || item.item_type === 'decor' || item.item_type === 'outfit' || item.item_type === 'journal') {
        const itemType = item.sub_type || item.item_type;
        let roomLocation = "attic";

        if (itemType === "outfit" || itemType === "accessory") {
          roomLocation = "style_chamber";
        } else if (itemType === "journal") {
          roomLocation = "bedroom";
        }

        await base44.entities.InventoryItem.create({
          user_email: user.email,
          item_type: itemType,
          item_name: item.item_name,
          item_emoji: item.emoji || "",
          item_image: item.image_url || "",
          room_location: roomLocation
        });

        alertMessage = `${item.item_name} added to your ${
          roomLocation === "attic" ? "Attic" : 
          roomLocation === "style_chamber" ? "Style Chamber" :
          roomLocation === "bedroom" ? "Bedroom" : "Inventory"
        }!`;
      }

      await base44.entities.LumoState.update(lumoState.id, updates);
      
      // Record purchase (even for consumables, for analytics)
      await base44.entities.PurchaseHistory.create({
        user_email: user.email,
        item_id: item.item_id,
        purchase_date: new Date().toISOString(),
        coins_spent: item.price
      });

      showLumoAlert("Yay! Lumo got a treat! 🎉", alertMessage, "success");
      
      await loadData();
    } catch (error) {
      console.error("Error purchasing item:", error);
      showLumoAlert("Oops! Let's try that again 🔄", "Something went wrong with the purchase. Please try again!", "error");
    } finally {
      setIsPurchasing(null);
    }
  };

  const getRecommendationMessage = () => {
    if (!needParam) return null;

    const messages = {
      "hungry": "Lumo is hungry! Look for items that restore hunger 🍎",
      "thirsty": "Lumo is thirsty! Look for items that restore thirst 💧",
      "dirty": "Lumo needs a bath! Look for items that restore hygiene 🧼",
      "sad": "Lumo is feeling sad. Look for items that help with sadness 💙",
      "anxious": "Lumo is feeling anxious. Look for items that help with anxiety 🌸",
      "angry": "Lumo is feeling angry. Look for items that help with anger 🧘",
      "sleepy": "Lumo is feeling sleepy. Look for items that help with rest 😴",
      "playful": "Lumo is feeling playful! Look for items that match this energy 🎾",
      "brave": "Lumo is feeling brave! Look for items that match this courage 🦸",
      "confident": "Lumo is feeling confident! Look for items that match this strength 💪"
    };

    return messages[needParam];
  };

  const recommendationMessage = getRecommendationMessage();

  const getFilteredItems = () => {
    let items = filter === "all" ? shopItems : shopItems.filter((item) => {
      // Handle journal as a sub_type or item_type
      if (filter === "journal") {
        return item.item_type === "journal" || item.sub_type === "journal";
      }
      return item.item_type === filter;
    });

    if (needParam) {
      items = items.sort((a, b) => {
        const physicalMapping = {
          "hungry": "hunger",
          "thirsty": "thirst",
          "dirty": "cleanliness"
        };

        const targetPhysicalNeed = physicalMapping[needParam];

        const aIsRecommendedPhysical = a.item_type === "physical" && a.treats === targetPhysicalNeed;
        const bIsRecommendedPhysical = b.item_type === "physical" && b.treats === targetPhysicalNeed;

        const aIsRecommendedEmotional = a.item_type === "emotional" && a.treats === needParam;
        const bIsRecommendedEmotional = b.item_type === "emotional" && b.treats === needParam;

        const aIsRecommended = aIsRecommendedPhysical || aIsRecommendedEmotional;
        const bIsRecommended = bIsRecommendedPhysical || bIsRecommendedEmotional;

        if (aIsRecommended && !bIsRecommended) return -1;
        if (!aIsRecommended && bIsRecommended) return 1;

        return 0;
      });
    }

    return items;
  };

  const filteredItems = getFilteredItems();

  const isItemRecommended = (item) => {
    if (!needParam) return false;

    const physicalMapping = {
      "hungry": "hunger",
      "thirsty": "thirst",
      "dirty": "cleanliness"
    };

    if (physicalMapping[needParam]) {
      return item.item_type === "physical" && item.treats === physicalMapping[needParam];
    }

    return item.item_type === "emotional" && item.treats === needParam;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="text-6xl mb-4 animate-bounce">🛍️</div>
          <p className="text-[#1165b3] font-semibold">Loading shop...</p>
        </div>
      </div>
    );
  }

  if (error || (shopItems.length === 0 && !isLoading)) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex items-center gap-4 mb-8">
          <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl("Home"))} className="rounded-full">
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex-1">
            <h1 className="text-sky-700 text-3xl font-bold">Lumo's Nook</h1>
            <p className="text-gray-600">Shop for supplies, treats, and more!</p>
          </div>
          {lumoState && (
            <div className="bg-gradient-to-r from-[#ffa400] to-[#ff8c00] text-white px-6 py-3 rounded-full font-bold shadow-lg">
              🪙 {lumoState.total_coins}
            </div>
          )}
        </div>

        <Card className="border-2 border-orange-300 bg-orange-50">
          <CardHeader>
            <CardTitle className="text-orange-700">No Items Available</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert className="bg-yellow-50 border-yellow-300">
              <AlertCircle className="h-4 w-4 text-yellow-700" />
              <AlertDescription className="text-yellow-800">
                {error || "The shop is empty! Please add items through the Admin Panel."}
              </AlertDescription>
            </Alert>
            
            <div className="bg-white p-4 rounded-lg space-y-2">
              <p className="font-semibold text-gray-700">To add shop items:</p>
              <ol className="list-decimal list-inside space-y-1 text-sm text-gray-600 ml-2">
                <li>Go to Admin Panel</li>
                <li>Click "Manage Shop Items"</li>
                <li>Add your items with prices, descriptions, etc.</li>
                <li>Come back here to shop!</li>
              </ol>
            </div>

            <div className="flex gap-3">
              <Button 
                onClick={() => navigate(createPageUrl("AdminPanel"))}
                className="flex-1 bg-[#1165b3]"
              >
                <Plus className="w-4 h-4 mr-2" />
                Go to Admin Panel
              </Button>
              <Button 
                onClick={() => navigate(createPageUrl("Home"))}
                variant="outline"
                className="flex-1"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Purchase Success Modal is removed, replaced by showLumoAlert */}

      <div className="flex items-center gap-4 mb-8">
        <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl("Home"))} className="rounded-full">
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1">
          <h1 className="text-sky-700 text-3xl font-bold">Lumo's Nook</h1>
          <p className="text-gray-600">Shop for supplies, treats, and more!</p>
        </div>
        <div className="bg-gradient-to-r from-[#ffa400] to-[#ff8c00] text-white px-6 py-3 rounded-full font-bold shadow-lg">
          🪙 {lumoState.total_coins}
        </div>
      </div>

      {recommendationMessage && (
        <Alert className="mb-6 bg-blue-100 border-blue-300">
          <AlertCircle className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-800 font-semibold">
            {recommendationMessage}
          </AlertDescription>
        </Alert>
      )}

      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {["all", "physical", "emotional", "decor", "outfit", "seasonal", "journal"].map((cat) => (
          <Button
            key={cat}
            onClick={() => setFilter(cat)}
            className={`rounded-full whitespace-nowrap ${
              filter === cat
                ? "bg-gradient-to-r from-[#1165b3] to-[#66bfad] text-white"
                : "bg-white text-gray-600 border-2 border-gray-200"
            }`}
          >
            {cat === "all" ? "All Items" : cat.charAt(0).toUpperCase() + cat.slice(1)}
          </Button>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {filteredItems.length === 0 ? (
          <div className="col-span-full text-center py-12">
            <div className="text-6xl mb-4">📦</div>
            <p className="text-gray-600 text-lg font-semibold">No {filter === "all" ? "" : filter} items available yet</p>
            <p className="text-gray-500 text-sm mt-2">Check back later or try a different filter!</p>
          </div>
        ) : (
          filteredItems.map((item) => {
            const isRecommended = isItemRecommended(item);

            return (
              <motion.div
                key={item.item_id}
                whileHover={{ scale: 1.03, y: -5 }}
                whileTap={{ scale: 0.98 }}
              >
                <Card className={`border-2 hover:shadow-xl transition-all duration-300 h-full flex flex-col relative ${
                  isRecommended
                    ? "border-[#ffa400] bg-gradient-to-br from-yellow-50 to-orange-50 shadow-lg ring-4 ring-[#ffa400]/30"
                    : "border-[#66bfad]/20"
                }`}>
                  {isRecommended && (
                    <div className="absolute top-2 right-2 text-2xl animate-pulse">
                      ✨
                    </div>
                  )}

                  <CardHeader className="text-center">
                    {isRecommended && (
                      <Badge className="bg-[#ffa400] text-white mb-2 shadow-lg">
                        ⭐ Perfect Match for Lumo!
                      </Badge>
                    )}
                    {item.image_url ? (
                      <div className="w-full h-32 mb-2 flex items-center justify-center">
                        <img src={item.image_url} alt={item.item_name} className="max-w-full max-h-full object-contain" />
                      </div>
                    ) : (
                      <div className="text-6xl mb-2">{item.emoji}</div>
                    )}
                    <CardTitle className="text-lg text-green-700" style={{ fontFamily: 'Poppins' }}>
                      {item.item_name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 flex-grow flex flex-col justify-between">
                    <div className="space-y-2">
                      <p className="text-sm text-center text-gray-600">{item.description}</p>

                      {item.item_type === "physical" && (
                        <p className="text-xs text-center font-semibold text-[#66bfad]">
                          Restores {Math.round((item.price / 20) * 100)}% {item.treats}
                        </p>
                      )}
                      {item.item_type === "emotional" && item.emotion_result && (
                        <p className="text-xs text-center font-semibold text-purple-600">
                          Makes Lumo {item.emotion_result} 😊
                        </p>
                      )}

                      {isRecommended && item.item_type === "emotional" && (
                        <p className="text-xs text-center font-bold text-orange-600 bg-orange-100 px-2 py-1 rounded-full">
                          🎁 Perfect match bonus: +50 XP + 10 coins back!
                        </p>
                      )}
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-4">
                        <Badge className="bg-[#ffa400] text-white hover:bg-[#ffa400]/90">{item.price} 🪙</Badge>
                        <Badge variant="outline" className="capitalize">{item.item_type}</Badge>
                      </div>
                      <Button
                        onClick={() => handlePurchase(item)}
                        disabled={!!isPurchasing || lumoState.total_coins < item.price}
                        className={`w-full text-white rounded-2xl hover:shadow-lg transition-all duration-300 ${
                          isRecommended
                            ? "bg-gradient-to-r from-[#ffa400] to-[#ff8c00] hover:from-[#ff8c00] hover:to-[#ffa400]"
                            : "bg-gradient-to-r from-[#66bfad] to-[#66bfad]/80"
                        }`}
                      >
                        {isPurchasing === item.item_id ? '...' : (
                          <>
                            <ShoppingCart className="w-4 h-4 mr-2" />
                            Purchase
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })
        )}
      </div>
    </div>
  );
}
