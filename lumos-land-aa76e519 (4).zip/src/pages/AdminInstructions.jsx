import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Upload, Package, Image, Trophy, Gift, Palette } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function AdminInstructions() {
  const navigate = useNavigate();

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdminPanel"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1165b3]">Admin Panel Instructions</h1>
          <p className="text-gray-600">How to add content to Lumo's Land</p>
        </div>
      </div>

      <div className="space-y-6">
        {/* Shop Items */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="w-6 h-6 text-[#66bfad]" />
              Shop Items (Lumo's Nook)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Required Fields:</h3>
              <ul className="space-y-2 text-sm">
                <li><strong>item_id:</strong> Unique identifier (e.g., "golden_apple_01")</li>
                <li><strong>item_name:</strong> Display name (e.g., "Golden Apple")</li>
                <li><strong>item_type:</strong> physical, emotional, decor, outfit, or seasonal</li>
                <li><strong>price:</strong> Cost in coins (number)</li>
                <li><strong>description:</strong> What the item does</li>
              </ul>
            </div>

            <div className="bg-green-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Optional Fields:</h3>
              <ul className="space-y-2 text-sm">
                <li><strong>emoji:</strong> Emoji to display (e.g., "🍎")</li>
                <li><strong>image_url:</strong> Link to item image (uploaded via Upload Assets)</li>
                <li><strong>sub_type:</strong> outfit, accessory, or decor (for placement)</li>
                <li><strong>treats:</strong> For physical items: hunger, thirst, cleanliness. For emotional: sad, anxious, angry, sleepy, playful, brave, confident</li>
                <li><strong>effect_amount:</strong> 1-100 (how much to restore)</li>
                <li><strong>emotion_result:</strong> happy, content, playful, confident, brave, calm</li>
                <li><strong>is_active:</strong> true/false (defaults to true)</li>
                <li><strong>available_from:</strong> Start date (YYYY-MM-DD)</li>
                <li><strong>available_until:</strong> End date (YYYY-MM-DD)</li>
              </ul>
            </div>

            <div className="bg-yellow-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Examples:</h3>
              <div className="space-y-3 text-sm font-mono bg-white p-3 rounded">
                <div>
                  <p className="font-bold text-gray-700 mb-1">Physical Item:</p>
                  <pre className="text-xs">{`{
  "item_id": "golden_apple_01",
  "item_name": "Golden Apple",
  "emoji": "🍎",
  "item_type": "physical",
  "price": 15,
  "description": "A juicy apple that fills Lumo up!",
  "treats": "hunger",
  "is_active": true
}`}</pre>
                </div>
                <div>
                  <p className="font-bold text-gray-700 mb-1">Emotional Item:</p>
                  <pre className="text-xs">{`{
  "item_id": "comfort_blanket_01",
  "item_name": "Comfort Blanket",
  "emoji": "🛌",
  "item_type": "emotional",
  "price": 20,
  "description": "A cozy blanket for when Lumo feels anxious",
  "treats": "anxious",
  "emotion_result": "calm",
  "is_active": true
}`}</pre>
                </div>
                <div>
                  <p className="font-bold text-gray-700 mb-1">Seasonal Item:</p>
                  <pre className="text-xs">{`{
  "item_id": "halloween_pumpkin_01",
  "item_name": "Spooky Pumpkin",
  "emoji": "🎃",
  "item_type": "seasonal",
  "sub_type": "decor",
  "price": 50,
  "description": "Halloween decoration for Lumo's room",
  "available_from": "2025-10-01",
  "available_until": "2025-10-31",
  "is_active": true
}`}</pre>
                </div>
              </div>
            </div>

            <Button onClick={() => navigate(createPageUrl("ManageShopItems"))} className="w-full">
              Go to Shop Items Manager
            </Button>
          </CardContent>
        </Card>

        {/* Asset Images */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Image className="w-6 h-6 text-[#ffa400]" />
              Asset Images (Lumo States, Backgrounds, NPCs)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">What You Can Upload:</h3>
              <ul className="space-y-2 text-sm">
                <li><strong>Lumo States:</strong> Images for happy, sad, hungry, thirsty, dirty, angry, anxious, sleepy, playful, brave, confident, content, missing</li>
                <li><strong>Backgrounds:</strong> Seasonal backgrounds (spring, summer, fall, winter)</li>
                <li><strong>Shop Items:</strong> Images for items in the Nook</li>
                <li><strong>NPCs:</strong> Character images for Glow Ridge</li>
              </ul>
            </div>

            <div className="bg-green-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Required Fields:</h3>
              <ul className="space-y-2 text-sm">
                <li><strong>asset_type:</strong> lumo_state, background, shop_item, or npc</li>
                <li><strong>asset_key:</strong> Identifier (e.g., "happy", "winter", "golden_apple_01")</li>
                <li><strong>image_url:</strong> URL after uploading image</li>
              </ul>
            </div>

            <div className="bg-purple-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Optional Fields:</h3>
              <ul className="space-y-2 text-sm">
                <li><strong>display_name:</strong> Human-readable name</li>
                <li><strong>description:</strong> What this asset is for</li>
                <li><strong>scale:</strong> For Lumo images, how big to display (default: 2)</li>
              </ul>
            </div>

            <div className="bg-yellow-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Process:</h3>
              <ol className="space-y-2 text-sm list-decimal list-inside">
                <li>Go to "Upload Asset Images"</li>
                <li>Select your image file (PNG recommended)</li>
                <li>Choose asset type</li>
                <li>Enter asset key (must match existing states/items)</li>
                <li>Upload - the URL will be saved automatically</li>
              </ol>
            </div>

            <Button onClick={() => navigate(createPageUrl("UploadAssetImages"))} className="w-full">
              Go to Upload Assets
            </Button>
          </CardContent>
        </Card>

        {/* Badges */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="w-6 h-6 text-[#ffa400]" />
              Badges & Achievements
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Required Fields:</h3>
              <ul className="space-y-2 text-sm">
                <li><strong>badge_id:</strong> Unique identifier (e.g., "first_lesson_complete")</li>
                <li><strong>badge_name:</strong> Display name (e.g., "First Steps")</li>
                <li><strong>condition_type:</strong> lessons_completed, total_xp, total_coins, days_streak, npc_interactions, journal_entries, or custom</li>
              </ul>
            </div>

            <div className="bg-green-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Optional Fields:</h3>
              <ul className="space-y-2 text-sm">
                <li><strong>badge_emoji:</strong> Emoji for badge (e.g., "🏆")</li>
                <li><strong>description:</strong> What this badge is for</li>
                <li><strong>condition_value:</strong> Target value (e.g., 10 for "complete 10 lessons")</li>
                <li><strong>is_active:</strong> true/false (defaults to true)</li>
              </ul>
            </div>

            <div className="bg-yellow-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Example:</h3>
              <pre className="text-xs font-mono bg-white p-3 rounded">{`{
  "badge_id": "lesson_master",
  "badge_name": "Lesson Master",
  "badge_emoji": "🎓",
  "description": "Complete 50 lessons",
  "condition_type": "lessons_completed",
  "condition_value": 50,
  "is_active": true
}`}</pre>
            </div>

            <Button onClick={() => navigate(createPageUrl("ManageBadges"))} className="w-full">
              Go to Badges Manager
            </Button>
          </CardContent>
        </Card>

        {/* Reward Rules */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Gift className="w-6 h-6 text-[#66bfad]" />
              Reward Rules
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">What Are Reward Rules?</h3>
              <p className="text-sm">Define how many coins and XP users earn for different activities.</p>
            </div>

            <div className="bg-green-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Required Fields:</h3>
              <ul className="space-y-2 text-sm">
                <li><strong>rule_id:</strong> Unique identifier (e.g., "journal_entry_reward")</li>
                <li><strong>rule_name:</strong> Display name (e.g., "Journal Entry")</li>
                <li><strong>rule_category:</strong> games, journal, care_loop, npc_interactions, daily_limits, or special</li>
              </ul>
            </div>

            <div className="bg-purple-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Optional Fields:</h3>
              <ul className="space-y-2 text-sm">
                <li><strong>coins_reward:</strong> Number of coins (default: 0)</li>
                <li><strong>xp_reward:</strong> Number of XP (default: 0)</li>
                <li><strong>description:</strong> What this rule does</li>
                <li><strong>is_active:</strong> true/false (defaults to true)</li>
              </ul>
            </div>

            <div className="bg-yellow-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Example:</h3>
              <pre className="text-xs font-mono bg-white p-3 rounded">{`{
  "rule_id": "daily_journal",
  "rule_name": "Daily Journal Entry",
  "rule_category": "journal",
  "coins_reward": 10,
  "xp_reward": 25,
  "description": "Reward for completing a journal entry",
  "is_active": true
}`}</pre>
            </div>

            <Button onClick={() => navigate(createPageUrl("ManageRewardRules"))} className="w-full">
              Go to Reward Rules Manager
            </Button>
          </CardContent>
        </Card>

        {/* Glow Ridge Content */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Palette className="w-6 h-6 text-green-600" />
              Glow Ridge Content (NPCs, Conversations, Lessons)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">What Is Glow Ridge?</h3>
              <p className="text-sm">An area where users interact with NPC characters, have conversations, and learn lessons.</p>
            </div>

            <div className="bg-yellow-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">How to Import:</h3>
              <ol className="space-y-2 text-sm list-decimal list-inside">
                <li>Prepare a JSON file with NPCs, conversations, and lessons</li>
                <li>Go to "Import Glow Ridge Content"</li>
                <li>Upload the JSON file</li>
                <li>Content will be imported into the database</li>
              </ol>
            </div>

            <div className="bg-green-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">JSON Structure:</h3>
              <p className="text-sm mb-2">Your JSON should have three main sections:</p>
              <ul className="space-y-1 text-sm list-disc list-inside">
                <li><strong>npcs:</strong> Array of NPC characters</li>
                <li><strong>conversations:</strong> Object mapping NPC IDs to conversation arrays</li>
                <li><strong>lessons:</strong> Object mapping NPC IDs to lesson arrays</li>
              </ul>
            </div>

            <Button onClick={() => navigate(createPageUrl("ImportGlowRidgeContent"))} className="w-full">
              Go to Import Glow Ridge Content
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}