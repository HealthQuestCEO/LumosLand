
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, Trash2, AlertTriangle, CheckCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ClearLessonData() {
  const navigate = useNavigate();
  const [isClearing, setIsClearing] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [confirmText, setConfirmText] = useState("");

  const handleClear = async () => {
    if (confirmText !== "DELETE ALL") {
      alert("Please type 'DELETE ALL' to confirm");
      return;
    }

    setIsClearing(true);
    setError(null);
    setResult(null);

    try {
      const { data } = await base44.functions.invoke('importLessons', {
        action: 'clearAll'
      });

      if (!data.success) {
        throw new Error(data.error || 'Clear failed');
      }

      setResult(data);
      setConfirmText(""); // Reset confirmation
    } catch (err) {
      console.error("Clear error:", err);
      setError(err.message);
    } finally {
      setIsClearing(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdminPanel"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-red-600">🗑️ Clear All Lesson Data</h1>
          <p className="text-gray-600">Remove all Adventure Academy & Glow Ridge content</p>
        </div>
      </div>

      <Alert className="mb-6 bg-red-50 border-red-300">
        <AlertTriangle className="h-5 w-5 text-red-600" />
        <AlertDescription className="text-red-800">
          <strong>⚠️ WARNING: This action will mark ALL lessons as inactive!</strong>
          <br />
          This includes:
          <ul className="list-disc list-inside mt-2 ml-2">
            <li>All Adventure Academy lessons (pre-assessments, lessons, post-assessments, feedback)</li>
            <li>All game styles (Bubble Pop, Pin Mountain, Glass Bridge, Sliding Match, Connect Dots)</li>
            <li>All quests</li>
          </ul>
          <br />
          <strong>Note:</strong> This does NOT delete user progress or lesson completions.
        </AlertDescription>
      </Alert>

      <Card className="border-2 border-red-300">
        <CardHeader>
          <CardTitle className="text-red-700">Confirm Deletion</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Type <code className="bg-red-100 px-2 py-1 rounded text-red-700">DELETE ALL</code> to confirm:
            </label>
            <input
              type="text"
              value={confirmText}
              onChange={(e) => setConfirmText(e.target.value)}
              className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-red-500 focus:outline-none"
              placeholder="Type DELETE ALL here"
              disabled={isClearing}
            />
          </div>

          <Button
            onClick={handleClear}
            disabled={confirmText !== "DELETE ALL" || isClearing}
            className="w-full bg-red-600 hover:bg-red-700 text-white py-6 text-lg"
          >
            <Trash2 className="w-5 h-5 mr-2" />
            {isClearing ? "Clearing..." : "Clear All Lessons"}
          </Button>
        </CardContent>
      </Card>

      {error && (
        <Alert className="mt-6 bg-red-50 border-red-300">
          <AlertTriangle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            <strong>Error:</strong> {error}
          </AlertDescription>
        </Alert>
      )}

      {result && (
        <Card className="mt-6 border-2 border-green-300 bg-green-50">
          <CardHeader>
            <CardTitle className="text-green-800 flex items-center gap-2">
              <CheckCircle className="w-5 h-5" />
              Clear Complete!
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-green-900">
            <p className="text-lg font-bold">✅ Deactivated {result.deactivated} lessons</p>
            
            {result.errors && result.errors.length > 0 && (
              <div className="mt-4 p-4 bg-yellow-100 rounded">
                <p className="font-bold text-yellow-800 mb-2">⚠️ Some errors occurred:</p>
                <ul className="list-disc list-inside text-sm text-yellow-900">
                  {result.errors.map((err, idx) => (
                    <li key={idx}>{err}</li>
                  ))}
                </ul>
              </div>
            )}

            <div className="mt-6 flex gap-3">
              <Button
                onClick={() => navigate(createPageUrl("DebugLessons"))}
                variant="outline"
                className="flex-1"
              >
                🔍 View Debug Page
              </Button>
              <Button
                onClick={() => navigate(createPageUrl("ImportLessonsJSON"))}
                className="flex-1 bg-green-600"
              >
                📥 Import New Lessons
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
