
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, Upload, Play, Bug, CheckCircle, AlertCircle, FileJson, ChevronDown, ChevronUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence } from "framer-motion";

import GameSessionRouter from "../components/games/GameSessionRouter";

export default function GameTester() {
  const navigate = useNavigate();
  const [jsonInput, setJsonInput] = useState("");
  const [parsedData, setParsedData] = useState(null); // Stores the full parsed lesson JSON that is *currently selected for preview*
  const [availableLessons, setAvailableLessons] = useState(null); // For HealthQuest format (array of lessons)
  const [selectedLesson, setSelectedLesson] = useState(null); // The specific lesson object selected from availableLessons
  const [validationErrors, setValidationErrors] = useState([]);
  const [selectedGameStyle, setSelectedGameStyle] = useState(null);
  const [showPreview, setShowPreview] = useState(false);
  const [showDebug, setShowDebug] = useState(false);

  // Samples now explicitly formatted to have a "questions" array, for consistency with new validation logic.
  const samples = {
    mcq: {
      name: "Sample MCQ (HealthQuest Format)",
      data: {
        "number": 6,
        "name": "Sample MCQ Lesson",
        "description": "Test multiple choice questions",
        "lessonText": "This is a sample lesson to test MCQ format.",
        "quest": "TestQuest",
        "language": "en",
        "forRole": "child",
        "minAge": 6,
        "maxAge": 12,
        "xp_total": 50,
        "coins_total": 50,
        "questions": [
          {
            "question": "What makes your body like a superpower?",
            "type": "mcq",
            "options": [
              "It lets you run and play",
              "It has to look perfect",
              "It should match others"
            ],
            "answer": 1, // 0-indexed answer
            "rationale": "Your body is amazing because of what it can do!"
          }
        ],
        "keyTakeaways": "• Your body is amazing because of what it can do!",
        "feedback": {
          "high_score": { "threshold": 1, "message": "Great job!" },
          "medium_score": { "threshold": 0, "message": "Nice try!" },
          "low_score": { "threshold": 0, "message": "Keep learning!" }
        }
      }
    },
    match: {
      name: "Sample Match (HealthQuest Format - 5 pairs)",
      data: {
        "number": 99,
        "name": "Sample Matching Lesson",
        "description": "Match the sleep stages to what happens.",
        "lessonText": "Match the sleep stages to what happens.",
        "quest": "TestQuest",
        "language": "en",
        "forRole": "child",
        "minAge": 6,
        "maxAge": 12,
        "xp_total": 50,
        "coins_total": 50,
        // Question is now inside the 'questions' array
        "questions": [
          {
            "question": "Match each sleep stage to what happens.",
            "type": "match",
            "options": [
              { "ans": "Waking Up", "matching_answer": { "answerId": "match_0", "group": "left" } },
              { "ans": "Eyes open, brain alert", "matching_answer": { "answerId": "match_0", "group": "right" } },
              { "ans": "Light Sleep", "matching_answer": { "answerId": "match_1", "group": "left" } },
              { "ans": "Drifting off, easy to wake", "matching_answer": { "answerId": "match_1", "group": "right" } },
              { "ans": "Dream Sleep", "matching_answer": { "answerId": "match_2", "group": "left" } },
              { "ans": "Having vivid dreams", "matching_answer": { "answerId": "match_2", "group": "right" } },
              { "ans": "Deep Sleep", "matching_answer": { "answerId": "match_3", "group": "left" } },
              { "ans": "Very hard to wake up", "matching_answer": { "answerId": "match_3", "group": "right" } },
              { "ans": "REM Sleep", "matching_answer": { "answerId": "match_4", "group": "left" } },
              { "ans": "Eyes moving rapidly", "matching_answer": { "answerId": "match_4", "group": "right" } }
            ]
          }
        ],
        "keyTakeaways": "• Sleep has different stages that help your body rest and grow.",
        "feedback": {
          "high_score": { "threshold": 5, "message": "Perfect matching!" },
          "medium_score": { "threshold": 3, "message": "Good job!" },
          "low_score": { "threshold": 0, "message": "Keep practicing!" }
        }
      }
    },
    assessment: {
      name: "Sample Assessment (HealthQuest Format)",
      data: {
        "number": 0,
        "name": "Sample Assessment",
        "description": "Pre-assessment baseline",
        "lessonText": "Let's see what you think about your body and eating habits.",
        "quest": "TestQuest",
        "language": "en",
        "forRole": "child",
        "minAge": 6,
        "maxAge": 12,
        "xp_total": 50,
        "coins_total": 50,
        "is_assessment": true,
        "assessment_type": "pre",
        "track_score": true,
        "scoring_scale": "4_point_likert",
        "max_score": 12,
        "shuffle_answers": false,
        "questions": [
          {
            "question": "I notice how food tastes, smells, or feels when I eat.",
            "options": [
              "Really agree",
              "A little agree",
              "Not sure",
              "Disagree"
            ]
          },
          {
            "question": "I can tell when I'm starting to get hungry.",
            "options": [
              "Really agree",
              "A little agree",
              "Not sure",
              "Disagree"
            ]
          },
          {
            "question": "I can tell when I'm starting to feel full.",
            "options": [
              "Really agree",
              "A little agree",
              "Not sure",
              "Disagree"
            ]
          }
        ],
        "score_mapping": {
          "Really agree": 3,
          "A little agree": 2,
          "Not sure": 1,
          "Disagree": 0
        },
        "keyTakeaways": "• Everyone eats in their own way.",
        "feedback": {
          "high_score": { "threshold": 9, "message": "You're very aware of your eating!" },
          "medium_score": { "threshold": 5, "message": "You're learning about mindful eating!" },
          "low_score": { "threshold": 0, "message": "There's always room to grow!" }
        }
      }
    }
  };

  const handleLoadSample = (sample) => {
    const sampleJsonString = JSON.stringify(sample.data, null, 2);
    setJsonInput(sampleJsonString);
    setParsedData(null); // Clear previous parsed data
    setAvailableLessons(null); // Clear available lessons from previous full export
    setSelectedLesson(null); // Clear selected lesson
    setValidationErrors([]); // Clear previous errors
    setSelectedGameStyle(null); // Clear selected game style
    setShowPreview(false); // Hide preview
    // Automatically trigger validation after loading sample
    handleValidate(sampleJsonString);
  };

  const validateLesson = (data) => {
    const errors = [];

    if (!data || typeof data !== 'object') {
      errors.push("❌ Invalid JSON: Expected an object.");
      return { errors, detectedType: null };
    }

    // Basic lesson metadata validation
    if (!data.name) errors.push("❌ Missing 'name' (lesson title).");
    if (!data.description) errors.push("❌ Missing 'description' (lesson description).");
    if (!data.quest) errors.push("❌ Missing 'quest' for the lesson.");
    if (data.number === undefined) errors.push("❌ Missing 'number' field.");
    if (!data.language) errors.push("❌ Missing 'language' for the lesson.");
    if (typeof data.minAge !== 'number') errors.push("❌ Missing or invalid 'minAge' for the lesson.");
    if (typeof data.maxAge !== 'number') errors.push("❌ Missing or invalid 'maxAge' for the lesson.");
    if (typeof data.xp_total !== 'number') errors.push("❌ Missing or invalid 'xp_total' for the lesson.");
    if (typeof data.coins_total !== 'number') errors.push("❌ Missing or invalid 'coins_total' for the lesson.");

    const isAssessmentLesson = data.is_assessment === true;

    if (!data.questions || !Array.isArray(data.questions) || data.questions.length === 0) {
      errors.push("❌ Missing or empty 'questions' array. A lesson must contain at least one question.");
      // Even if no questions, try to determine type if assessment
      if (isAssessmentLesson) return { errors, detectedType: 'assessment' };
      return { errors, detectedType: null };
    }

    let allQuestions = data.questions;
    let detectedType = 'mcq'; // Default to mcq

    if (isAssessmentLesson) {
      detectedType = 'assessment';
    } else {
      // Determine lesson type from the first question if not an assessment
      const firstQ = allQuestions[0];
      if (firstQ) {
        if (firstQ.type === 'match' || firstQ.type === 'matching' || (firstQ.options && firstQ.options[0]?.matching_answer !== undefined)) {
          detectedType = 'match';
        } else if (firstQ.type === 'mcq' || (firstQ.options && typeof firstQ.answer === 'number')) {
          detectedType = 'mcq';
        }
      }
    }


    // Validate each individual question found within the lesson
    allQuestions.forEach((q, index) => {
      // All questions should have some text
      if (!q.question && !q.questionText) {
        errors.push(`❌ Question ${index + 1}: Missing question text (field 'question' or 'questionText').`);
      }

      // Each question must have options
      if (!Array.isArray(q.options) || q.options.length === 0) {
        errors.push(`❌ Question ${index + 1}: Missing or empty 'options' array.`);
        return; // Skip further validation for this question if options are missing
      }

      // Assessment questions are more lenient on 'type' and 'answer' as they are subjective
      if (isAssessmentLesson) {
        if (q.answer !== undefined) {
          errors.push(`⚠️ Assessment question ${index + 1}: Should not have 'answer' field (assessments are subjective).`);
        }
        // 'type' is often omitted for assessment questions, assumed 'mcq-like' but no explicit type enforcement here.
      } else { // Regular lesson questions
        const questionType = q.type;
        if (!questionType) {
          errors.push(`❌ Question ${index + 1}: Missing 'type'. Must be: mcq, match, or matching.`);
        } else if (!['mcq', 'match', 'matching'].includes(questionType)) {
          errors.push(`❌ Question ${index + 1}: Invalid type "${questionType}". Must be: mcq, match, or matching.`);
        }

        if (questionType === 'mcq') {
          if (typeof q.answer !== 'number' || q.answer < 0 || q.answer >= q.options.length) {
            errors.push(`❌ Question ${index + 1} (MCQ): Missing or invalid numeric 'answer' index (must be 0-indexed and within options bounds).`);
          }
        } else if (questionType === 'match' || questionType === 'matching') {
          if (q.options.length % 2 !== 0) {
            errors.push(`❌ Question ${index + 1} (Match): Must have an even number of options (pairs).`);
          }
          q.options.forEach((opt, optIdx) => {
            if (!opt.ans) errors.push(`❌ Question ${index + 1}, Match option ${optIdx + 1}: Missing 'ans' field.`);
            if (!opt.matching_answer) {
              errors.push(`❌ Question ${index + 1}, Match option ${optIdx + 1}: Missing 'matching_answer' field.`);
            } else if (!opt.matching_answer.answerId || !opt.matching_answer.group) {
              errors.push(`❌ Question ${index + 1}, Match option ${optIdx + 1}: Incomplete 'matching_answer' (needs answerId and group).`);
            }
          });
        }
      }
    });

    // Validate consistency of question types within the lesson (if not assessment)
    if (!isAssessmentLesson && allQuestions.length > 1) {
      const types = new Set(allQuestions.map(q => {
        if (q.type === 'match' || q.type === 'matching' || (q.options && q.options[0]?.matching_answer !== undefined)) return 'match';
        return 'mcq';
      }));

      if (types.size > 1) {
        errors.push("⚠️ Mixed question types detected (some MCQ, some matching). All questions in a non-assessment lesson should be of the same game type.");
      }
      // Ensure detectedType is consistent with the first question type.
      // If there are mixed types, the detectedType is effectively ambiguous for game selection.
      // We rely on the game types being consistent, so `detectedType` from first question is fine.
    }

    // Assessment-specific lesson-level validations
    if (isAssessmentLesson) {
      if (!data.assessment_type) errors.push("❌ Assessment lesson missing 'assessment_type'.");
      if (!data.scoring_scale) errors.push("❌ Assessment lesson missing 'scoring_scale'.");
      if (!data.score_mapping) errors.push("❌ Assessment lesson missing 'score_mapping'.");
    }

    return { errors, detectedType };
  };

  const handleValidate = (jsonString = jsonInput) => {
    try {
      const data = JSON.parse(jsonString);

      // ✅ NEW: Check if this is a full HealthQuest export
      if (data.lessons || data.pre_assessment || data.post_assessment || data.feedbackform) {
        console.log('📦 Detected full HealthQuest export format');

        const lessons = [];

        // Helper to add lessons from a category
        const addLessons = (category, type) => {
          if (data[category] && Array.isArray(data[category])) {
            data[category].forEach(lesson => {
              lessons.push({ ...lesson, _type: type });
            });
          }
        };

        addLessons('pre_assessment', 'pre_assessment');
        addLessons('lessons', 'lesson');
        addLessons('post_assessment', 'post_assessment');
        addLessons('feedbackform', 'feedbackform');

        setAvailableLessons(lessons);
        setValidationErrors([]); // Clear any previous validation errors
        setParsedData(null); // Clear single lesson parsed data
        setSelectedLesson(null); // Clear selected lesson from an export
        setSelectedGameStyle(null); // Clear game style

        if (lessons.length === 0) {
          setValidationErrors(["⚠️ Full HealthQuest export detected, but no lessons, pre-assessments, post-assessments, or feedback forms were found within it."]);
        } else {
          setValidationErrors(["✅ Full HealthQuest export detected. Please select a lesson from the list below to test it."]);
        }
        return; // Exit early as we're handling a full export
      }

      // Existing single lesson format handling
      const { errors, detectedType } = validateLesson(data);
      setValidationErrors(errors);

      if (errors.length === 0) {
        const finalParsedData = { ...data, type: detectedType };
        setParsedData(finalParsedData);
        setAvailableLessons(null); // Clear if previously loaded a full export
        setSelectedLesson(null); // Clear if previously selected a lesson from an export

        // Auto-select game style logic (existing)
        if (finalParsedData.is_assessment) {
          setSelectedGameStyle('bubble_pop');
        } else {
          if (detectedType === 'mcq') {
            setSelectedGameStyle('bubble_pop');
          } else if (detectedType === 'match') {
            setSelectedGameStyle('bubble_pop');
          } else {
            setSelectedGameStyle(null);
          }
        }
      } else {
        setParsedData(null);
        setAvailableLessons(null); // Clear if previously loaded a full export
        setSelectedLesson(null); // Clear if previously selected a lesson from an export
        setSelectedGameStyle(null);
      }
    } catch (e) {
      setValidationErrors([`❌ Invalid JSON: ${e.message}`]);
      setParsedData(null);
      setAvailableLessons(null); // Clear on error
      setSelectedLesson(null); // Clear on error
      setSelectedGameStyle(null);
    }
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target.result;
        setJsonInput(content);
        handleValidate(content); // Validate immediately after file upload
      };
      reader.readAsText(file);
    }
  };

  const handleSelectLesson = (lesson) => {
    // Perform validation on the selected lesson
    const { errors, detectedType } = validateLesson(lesson);
    setValidationErrors(errors); // Show validation errors specifically for this lesson

    if (errors.length === 0) {
      const finalParsedData = { ...lesson, type: detectedType };
      setParsedData(finalParsedData); // Set this as the active lesson for testing
      setSelectedLesson(lesson); // Keep track of the actual selected lesson object from `availableLessons`

      // Auto-select game style based on the selected lesson
      if (finalParsedData.is_assessment) {
        setSelectedGameStyle('bubble_pop');
      } else {
        if (detectedType === 'mcq') {
          setSelectedGameStyle('bubble_pop');
        } else if (detectedType === 'match') {
          setSelectedGameStyle('bubble_pop');
        } else {
          setSelectedGameStyle(null);
        }
      }
    } else {
      // If validation fails for the selected lesson, clear parsedData and selection
      setParsedData(null);
      setSelectedLesson(null);
      setSelectedGameStyle(null);
    }
  };


  const handleGameStyleSelect = (gameStyle) => {
    if (!parsedData) return;

    const lessonType = parsedData.is_assessment ? 'assessment' : (parsedData.type || 'mcq'); // Use parsedData.type as determined by validateLesson

    // Games compatible with MCQ type lessons
    const validMCQStyles = ['bubble_pop', 'pin_mountain', 'glass_bridge'];
    // Games compatible with Matching type lessons
    const validMatchingStyles = ['bubble_pop', 'sliding_match', 'connect_dots'];

    if (lessonType === 'assessment') {
      if (gameStyle !== 'bubble_pop') {
        alert(`❌ Assessments MUST use "Bubble Pop". Other styles are not compatible.`);
        return;
      }
    } else if (lessonType === 'match') {
      if (!validMatchingStyles.includes(gameStyle)) {
        alert(`❌ "${getAvailableGameStyles().find(g => g.id === gameStyle)?.name}" is not valid for matching lessons. Compatible styles: ${validMatchingStyles.map(id => getAvailableGameStyles().find(g => g.id === id)?.name).join(', ')}.`);
        return;
      }
    } else if (lessonType === 'mcq') { // Covers 'mcq' and any other non-match/non-assessment types
      if (!validMCQStyles.includes(gameStyle)) {
        alert(`❌ "${getAvailableGameStyles().find(g => g.id === gameStyle)?.name}" is not valid for MCQ lessons. Compatible styles: ${validMCQStyles.map(id => getAvailableGameStyles().find(g => g.id === id)?.name).join(', ')}.`);
        return;
      }
    }

    setSelectedGameStyle(gameStyle);
  };

  const handleStartGame = () => {
    if (!parsedData || !selectedGameStyle) return;

    // Ensure lessonData passed to GameSessionRouter is correctly structured and has game_style
    const lessonWithGameStyle = {
      ...parsedData,
      game_style: selectedGameStyle,
      // Ensure `id` is present, GameSessionRouter might expect it
      id: parsedData.number ? `lesson-${parsedData.number}` : `test-lesson-${parsedData.name?.replace(/\s/g, '-') || Math.random().toString(36).substring(7)}`,
      xp_reward: parsedData.xp_total || 50,
      coins_reward: parsedData.coins_total || 50,
      coins_per_correct: parsedData.coins_per_correct || 10,
    };

    // Ensure `questionText` is present on individual questions within the questions array
    if (Array.isArray(lessonWithGameStyle.questions)) {
      lessonWithGameStyle.questions = lessonWithGameStyle.questions.map(q => ({
        ...q,
        questionText: q.question || q.questionText // Ensure questionText prop for game components
      }));
    }

    console.log('🎮 Starting game with data:', lessonWithGameStyle);
    setShowPreview(true);
  };

  const handleGameComplete = (results) => {
    console.log('✅ Game completed:', results);
    setShowPreview(false);
    alert(`Game Complete!\nScore: ${results.correctAnswers}/${results.totalQuestions}\nCoins Earned: ${results.coinsEarned}\nXP Earned: ${results.xpEarned}`);
  };

  const handleGameExit = () => {
    setShowPreview(false);
  };

  // Determine available game styles based on parsedData's type or is_assessment flag
  const getAvailableGameStyles = () => {
    if (!parsedData) return [];

    const isAssessment = parsedData.is_assessment;
    const lessonType = parsedData.type; // This `type` is set by `validateLesson`

    const allGames = [
      { id: 'bubble_pop', name: 'Bubble Pop', emoji: '🫧', description: 'Pop matching bubbles or correct answers' },
      { id: 'sliding_match', name: 'Sliding Match', emoji: '🎴', description: 'Slide cards to match pairs' },
      { id: 'connect_dots', name: 'Connect Dots', emoji: '🔗', description: 'Draw lines to connect pairs' },
      { id: 'pin_mountain', name: 'Pin Mountain', emoji: '⛰️', description: 'Climb the mountain with correct answers' },
      { id: 'glass_bridge', name: 'Glass Bridge', emoji: '🌉', description: 'Cross the bridge by selecting correct answers' }
    ];

    if (isAssessment) {
      return allGames.map(game => ({
        ...game,
        compatible: game.id === 'bubble_pop',
        reason: game.id === 'bubble_pop' ? '' : 'Assessments use Bubble Pop only'
      }));
    } else if (lessonType === 'match') {
      return allGames.map(game => ({
        ...game,
        compatible: ['bubble_pop', 'sliding_match', 'connect_dots'].includes(game.id),
        reason: ['bubble_pop', 'sliding_match', 'connect_dots'].includes(game.id) ? '' : 'Only for MCQ lessons'
      }));
    } else { // Default to MCQ (lessonType 'mcq' or if type couldn't be definitively determined but has questions)
      return allGames.map(game => ({
        ...game,
        compatible: ['bubble_pop', 'pin_mountain', 'glass_bridge'].includes(game.id),
        reason: ['bubble_pop', 'pin_mountain', 'glass_bridge'].includes(game.id) ? '' : 'Only for Matching lessons'
      }));
    }
  };

  const availableGameStyles = getAvailableGameStyles();

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {showPreview ? (
        // Fixed preview mode when a game is launched
        <div className="fixed inset-0 z-50 bg-white">
          <GameSessionRouter
            lessonData={{
              ...parsedData,
              game_style: selectedGameStyle,
              id: parsedData.number ? `lesson-${parsedData.number}` : `test-lesson-${parsedData.name?.replace(/\s/g, '-') || Math.random().toString(36).substring(7)}`, // Ensure ID is always present
              xp_reward: parsedData.xp_total || 50,
              coins_reward: parsedData.coins_total || 50,
              coins_per_correct: parsedData.coins_per_correct || 10,
              questions: parsedData.questions.map(q => ({
                ...q,
                questionText: q.question || q.questionText // Ensure questionText prop for game components
              }))
            }}
            gameConfig={{}} // Empty config for now
            onComplete={handleGameComplete}
            onExit={handleGameExit}
          />
        </div>
      ) : (
        <>
          {/* Header */}
          <div className="flex items-center gap-4 mb-8">
            <Button
              variant="outline"
              size="icon"
              onClick={() => navigate(createPageUrl("AdminPanel"))}
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-[#1165b3]">🎮 Game Tester</h1>
              <p className="text-gray-600">Test game styles with HealthQuest JSON</p>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Left Column - JSON Input */}
            <div className="space-y-6">
              {/* Sample Buttons */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">📋 Load Sample Data</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {Object.entries(samples).map(([key, sample]) => (
                    <Button
                      key={key}
                      onClick={() => handleLoadSample(sample)}
                      variant="outline"
                      className="w-full justify-start text-left"
                    >
                      {sample.name}
                    </Button>
                  ))}
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left"
                    onClick={() => document.getElementById('file-upload').click()}
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Upload JSON File
                  </Button>
                  <input
                    id="file-upload"
                    type="file"
                    accept=".json"
                    className="hidden"
                    onChange={handleFileUpload}
                  />
                </CardContent>
              </Card>

              {/* JSON Input */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">📝 JSON Input</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Textarea
                    value={jsonInput}
                    onChange={(e) => setJsonInput(e.target.value)}
                    placeholder='Paste HealthQuest JSON here...\n\n✅ Supports single lesson JSON OR full HealthQuest export JSON containing multiple lessons (pre_assessment, lessons, post_assessment, feedbackform arrays).'
                    className="font-mono text-sm h-96"
                  />
                  <Button
                    onClick={() => handleValidate()} // No argument, uses current jsonInput state
                    className="w-full bg-[#1165b3] hover:bg-[#1165b3]/90"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Validate & Prepare Lesson
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Right Column - Results */}
            <div className="space-y-6">
              {/* Validation Results */}
              {jsonInput && validationErrors.length > 0 && (
                <Alert className={`${validationErrors[0]?.startsWith('✅') ? 'bg-green-50 border-green-300' : validationErrors[0]?.startsWith('⚠️') ? 'bg-yellow-50 border-yellow-300' : 'bg-red-50 border-red-300'}`}>
                  {validationErrors[0]?.startsWith('✅') ? <CheckCircle className="h-4 w-4 text-green-600" /> : validationErrors[0]?.startsWith('⚠️') ? <AlertCircle className="h-4 w-4 text-yellow-600" /> : <AlertCircle className="h-4 w-4 text-red-600" />}
                  <AlertDescription>
                    <div className={`font-bold ${validationErrors[0]?.startsWith('✅') ? 'text-green-800' : validationErrors[0]?.startsWith('⚠️') ? 'text-yellow-800' : 'text-red-800'} mb-2`}>
                      {validationErrors[0]?.startsWith('❌') ? "❌ Validation Errors:" : ""}
                      {validationErrors[0]?.startsWith('✅') ? "✅ Validation Success:" : ""}
                      {validationErrors[0]?.startsWith('⚠️') ? "⚠️ Warning:" : ""}
                    </div>
                    <ul className={`list-disc list-inside space-y-1 ${validationErrors[0]?.startsWith('✅') ? 'text-green-700' : validationErrors[0]?.startsWith('⚠️') ? 'text-yellow-700' : 'text-red-700'}`}>
                      {validationErrors.map((error, idx) => (
                        <li key={idx}>{error.replace(/^(❌|✅|⚠️)\s/, '')}</li>
                      ))}
                    </ul>
                  </AlertDescription>
                </Alert>
              )}

              {/* ✅ NEW: Lesson Selector for full exports */}
              {availableLessons && availableLessons.length > 0 && (
                <Card className="border-2 border-green-300 bg-green-50">
                  <CardHeader>
                    <CardTitle className="text-green-800">
                      <FileJson className="inline-block mr-2 h-5 w-5" />
                      Found {availableLessons.length} Lessons - Select One to Test
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 max-h-96 overflow-y-auto">
                    {availableLessons.map((lesson, index) => (
                      <button
                        key={`${lesson.number || 'no-num'}-${lesson.name || 'no-name'}-${index}`}
                        onClick={() => handleSelectLesson(lesson)}
                        className={`w-full text-left p-3 rounded-lg border-2 transition-all ${
                          selectedLesson === lesson
                            ? 'border-[#1165b3] bg-blue-50'
                            : 'border-gray-200 hover:border-[#66bfad]'
                        }`}
                      >
                        <div className="font-bold text-[#1165b3]">
                          {lesson._type === 'pre_assessment' && '📋 Pre-Assessment: '}
                          {lesson._type === 'post_assessment' && '📊 Post-Assessment: '}
                          {lesson._type === 'feedbackform' && '📝 Feedback: '}
                          {lesson._type === 'lesson' && `📚 Lesson ${lesson.number}: `}
                          {lesson.name}
                        </div>
                        <div className="text-sm text-gray-600 mt-1">
                          {lesson.questions?.length || 0} questions
                        </div>
                      </button>
                    ))}
                  </CardContent>
                </Card>
              )}


              {parsedData && validationErrors.length === 0 && ( // Only show if a single lesson is valid OR a lesson from export is selected AND valid
                <>
                  <Alert className="bg-green-50 border-green-300">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <AlertDescription>
                      <div className="font-bold text-green-800 mb-2">✅ Valid HealthQuest Lesson Data Ready!</div>
                      <div className="text-green-700 space-y-1">
                        <div>• Lesson Name: <strong>{parsedData.name}</strong></div>
                        <div>• Quest: {parsedData.quest}</div>
                        <div>• Number: {parsedData.number}</div>
                        <div>• Detected Type: <strong>{parsedData.is_assessment ? 'Assessment' : parsedData.type?.toUpperCase()}</strong></div>
                        <div>• Questions: {parsedData.questions?.length || 0}</div>
                      </div>
                    </AlertDescription>
                  </Alert>

                  {/* Game Style Selection */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">🎨 Select Game Style</CardTitle>
                      {parsedData.is_assessment ? (
                        <p className="text-sm text-purple-600 font-medium">
                          Assessments must use "Bubble Pop" style.
                        </p>
                      ) : (
                        <p className="text-sm text-gray-600">
                          Compatible styles for <strong>{parsedData.type === 'match' ? 'Matching' : 'MCQ'}</strong> lessons:
                        </p>
                      )}
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {availableGameStyles.map((style) => (
                        <motion.button
                          key={style.id}
                          whileHover={style.compatible ? { scale: 1.02 } : {}}
                          whileTap={style.compatible ? { scale: 0.98 } : {}}
                          onClick={() => style.compatible && handleGameStyleSelect(style.id)}
                          disabled={!style.compatible}
                          className={`w-full p-4 rounded-xl border-2 transition-all text-left flex items-center gap-3 ${
                            style.compatible
                              ? selectedGameStyle === style.id
                                ? 'border-[#1165b3] bg-blue-50'
                                : 'border-gray-200 hover:border-[#66bfad]'
                              : 'border-gray-100 bg-gray-50 opacity-60 cursor-not-allowed'
                          }`}
                        >
                          <div className="text-3xl">{style.emoji}</div>
                          <div>
                            <div className="font-bold text-[#1165b3]">{style.name}</div>
                            <div className={`text-sm ${style.compatible ? 'text-gray-600' : 'text-red-500'}`}>
                              {style.compatible ? style.description : style.reason}
                            </div>
                          </div>
                        </motion.button>
                      ))}

                      {selectedGameStyle && (
                        <Button
                          onClick={handleStartGame}
                          className="w-full bg-gradient-to-r from-[#66bfad] to-[#1165b3] text-white hover:from-[#57a99a] hover:to-[#0e59a0]"
                        >
                          <Play className="w-4 h-4 mr-2" />
                          Launch Game Preview
                        </Button>
                      )}
                    </CardContent>
                  </Card>

                  {/* Debug Toggle */}
                  <Button
                    onClick={() => setShowDebug(!showDebug)}
                    variant="outline"
                    className="w-full justify-start text-left flex items-center gap-2"
                  >
                    <Bug className="w-4 h-4" />
                    <span className="flex-1">{showDebug ? 'Hide' : 'Show'} Debug Info</span>
                    {showDebug ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </Button>

                  {showDebug && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">🐛 Debug Info (Parsed Lesson Data)</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <pre className="bg-gray-100 p-4 rounded-lg text-xs overflow-auto max-h-96">
                          {JSON.stringify(parsedData, null, 2)}
                        </pre>
                      </CardContent>
                    </Card>
                  )}
                </>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
