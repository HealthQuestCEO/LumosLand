import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, Upload, CheckCircle, AlertCircle, FileJson } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ImportGlowRidgeContent() {
  const navigate = useNavigate();
  const [jsonInput, setJsonInput] = useState("");
  const [isImporting, setIsImporting] = useState(false);
  const [importResult, setImportResult] = useState(null);

  const exampleJSON = `{
  "meta": {
    "npc_id": "owl_ollie",
    "npc": "Ollie the Owl",
    "species": "Owl",
    "emoji": "🦉",
    "topic": "Sleep & Rest",
    "xp_per_interaction": 50,
    "daily_cap": 450,
    "unlock_level": 1,
    "language": "en"
  },
  "conversations": [
    {
      "id": "owl_01",
      "language": "en",
      "question": "Did you turn off screens a little before bed?",
      "yes_response": "Nice and steady. That helps you grow.",
      "no_response": "You can try a small step tonight. Your effort matters.",
      "key_takeaway": "Calm routines help your body and brain."
    },
    {
      "id": "owl_02",
      "language": "en",
      "question": "Would you like to try a short story at bedtime tonight?",
      "yes_response": "Nice and steady. That helps you grow.",
      "no_response": "You can try a small step tonight. Your effort matters.",
      "key_takeaway": "Calm routines help your body and brain."
    }
  ]
}`;

  const handleImport = async () => {
    setIsImporting(true);
    setImportResult(null);

    try {
      const data = JSON.parse(jsonInput);

      if (!data.meta || !data.conversations) {
        throw new Error("Invalid format: missing 'meta' or 'conversations'");
      }

      // Create or update NPC
      const existingNPCs = await base44.entities.GlowRidgeNPC.filter({ npc_id: data.meta.npc_id });
      
      const npcData = {
        npc_id: data.meta.npc_id,
        npc_name: data.meta.npc,
        species: data.meta.species,
        emoji: data.meta.emoji || "🦉",
        topic: data.meta.topic,
        xp_per_interaction: data.meta.xp_per_interaction || 50,
        daily_cap: data.meta.daily_cap || 450,
        unlock_level: data.meta.unlock_level || 1,
        is_active: true
      };

      if (existingNPCs.length > 0) {
        await base44.entities.GlowRidgeNPC.update(existingNPCs[0].id, npcData);
      } else {
        await base44.entities.GlowRidgeNPC.create(npcData);
      }

      // Import conversations
      let imported = 0;
      for (const [index, conv] of data.conversations.entries()) {
        const convData = {
          conversation_id: conv.id,
          npc_id: data.meta.npc_id,
          language: conv.language || "en",
          question: conv.question,
          yes_response: conv.yes_response,
          no_response: conv.no_response,
          key_takeaway: conv.key_takeaway || "",
          sort_order: index,
          is_active: true
        };

        const existing = await base44.entities.GlowRidgeConversation.filter({
          conversation_id: conv.id,
          npc_id: data.meta.npc_id
        });

        if (existing.length > 0) {
          await base44.entities.GlowRidgeConversation.update(existing[0].id, convData);
        } else {
          await base44.entities.GlowRidgeConversation.create(convData);
        }
        imported++;
      }

      setImportResult({
        success: true,
        npc: data.meta.npc,
        conversations: imported
      });

    } catch (error) {
      setImportResult({
        success: false,
        error: error.message
      });
    } finally {
      setIsImporting(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdminPanel"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1165b3]">🌲 Import Glow Ridge Content</h1>
          <p className="text-gray-600">Upload NPC conversations from JSON</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Left: Input */}
        <Card className="border-2 border-[#00d1ff]/30">
          <CardHeader>
            <CardTitle className="text-[#00d1ff]">Paste NPC JSON</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              value={jsonInput}
              onChange={(e) => setJsonInput(e.target.value)}
              placeholder="Paste your Glow Ridge NPC JSON here..."
              className="h-96 font-mono text-sm"
            />

            <Button
              onClick={() => setJsonInput(exampleJSON)}
              variant="outline"
              className="w-full"
            >
              Load Example
            </Button>

            <Button
              onClick={handleImport}
              disabled={!jsonInput.trim() || isImporting}
              className="w-full bg-gradient-to-r from-[#00d1ff] to-[#66bfad] text-white text-lg py-6"
            >
              {isImporting ? "Importing..." : "Import NPC & Conversations"}
            </Button>
          </CardContent>
        </Card>

        {/* Right: Results */}
        <Card className="border-2 border-[#66bfad]/30">
          <CardHeader>
            <CardTitle className="text-[#66bfad]">Import Results</CardTitle>
          </CardHeader>
          <CardContent>
            {!importResult ? (
              <div className="text-center py-12 text-gray-500">
                <FileJson className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Results will appear here after importing</p>
              </div>
            ) : importResult.success ? (
              <Alert className="bg-green-50 border-green-300">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800">
                  <p className="font-semibold mb-2">✅ Import Successful!</p>
                  <ul className="list-disc list-inside space-y-1">
                    <li>NPC: {importResult.npc}</li>
                    <li>Conversations: {importResult.conversations}</li>
                  </ul>
                </AlertDescription>
              </Alert>
            ) : (
              <Alert className="bg-red-50 border-red-300">
                <AlertCircle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800">
                  <p className="font-semibold">❌ Import Failed</p>
                  <p className="text-sm mt-1">{importResult.error}</p>
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Format Guide */}
      <Card className="mt-8 border-2 border-[#ffa400]/30 bg-gradient-to-br from-orange-50 to-white">
        <CardHeader>
          <CardTitle className="text-[#ffa400]">📋 JSON Format Guide</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <p><strong>Required Structure:</strong></p>
          <ul className="list-disc list-inside pl-4 space-y-1">
            <li><code>"meta"</code> - NPC information</li>
            <li><code>"conversations"</code> - Array of yes/no questions</li>
          </ul>

          <p className="mt-4"><strong>Conversation Format:</strong></p>
          <ul className="list-disc list-inside pl-4 space-y-1">
            <li><code>"id"</code> - Unique ID (e.g., owl_01)</li>
            <li><code>"question"</code> - The yes/no question</li>
            <li><code>"yes_response"</code> - What to say if yes</li>
            <li><code>"no_response"</code> - What to say if no</li>
            <li><code>"key_takeaway"</code> - Learning point</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}