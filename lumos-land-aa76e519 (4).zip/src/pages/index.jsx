import Layout from "./Layout.jsx";

import Home from "./Home";

import LumosNook from "./LumosNook";

import TreasureRoom from "./TreasureRoom";

import Hub from "./Hub";

import LumosCastle from "./LumosCastle";

import AdventureAcademy from "./AdventureAcademy";

import MatchingGames from "./MatchingGames";

import DopamineCheckIn from "./DopamineCheckIn";

import MindfulMunchies from "./MindfulMunchies";

import MindfulKitchen from "./MindfulKitchen";

import AssessmentComparison from "./AssessmentComparison";

import ManageLessons from "./ManageLessons";

import ManageShopItems from "./ManageShopItems";

import ManageBadges from "./ManageBadges";

import ManageRewards from "./ManageRewards";

import ManageRewardRules from "./ManageRewardRules";

import AdminPanel from "./AdminPanel";

import UploadAssetImages from "./UploadAssetImages";

import DebugLessons from "./DebugLessons";

import ManageAssets from "./ManageAssets";

import AdminInstructions from "./AdminInstructions";

import ManageReflectionQuestions from "./ManageReflectionQuestions";

import ManageSpinner from "./ManageSpinner";

import ManageAnnouncements from "./ManageAnnouncements";

import ClearLessonData from "./ClearLessonData";

import ManageXPLevels from "./ManageXPLevels";

import ImportLessons from "./ImportLessons";

import BubblePopGames from "./BubblePopGames";

import PinMountainGames from "./PinMountainGames";

import GlassBridgeGames from "./GlassBridgeGames";

import BubblePopGame from "./BubblePopGame";

import PinMountainGame from "./PinMountainGame";

import GlassBridgeGame from "./GlassBridgeGame";

import CreateLessonFormat from "./CreateLessonFormat";

import ImportLessonsJSON from "./ImportLessonsJSON";

import HealthQuestBridge from "./HealthQuestBridge";

import JSONFormatExamples from "./JSONFormatExamples";

import BackendRebuildGuide from "./BackendRebuildGuide";

import ImportGlowRidgeContent from "./ImportGlowRidgeContent";

import GlowRidgePath from "./GlowRidgePath";

import HealthQuestIntegrationArchitecture from "./HealthQuestIntegrationArchitecture";

import AdminPanelArchitecture from "./AdminPanelArchitecture";

import ExportData from "./ExportData";

import ScheduledExports from "./ScheduledExports";

import GameTester from "./GameTester";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Home: Home,
    
    LumosNook: LumosNook,
    
    TreasureRoom: TreasureRoom,
    
    Hub: Hub,
    
    LumosCastle: LumosCastle,
    
    AdventureAcademy: AdventureAcademy,
    
    MatchingGames: MatchingGames,
    
    DopamineCheckIn: DopamineCheckIn,
    
    MindfulMunchies: MindfulMunchies,
    
    MindfulKitchen: MindfulKitchen,
    
    AssessmentComparison: AssessmentComparison,
    
    ManageLessons: ManageLessons,
    
    ManageShopItems: ManageShopItems,
    
    ManageBadges: ManageBadges,
    
    ManageRewards: ManageRewards,
    
    ManageRewardRules: ManageRewardRules,
    
    AdminPanel: AdminPanel,
    
    UploadAssetImages: UploadAssetImages,
    
    DebugLessons: DebugLessons,
    
    ManageAssets: ManageAssets,
    
    AdminInstructions: AdminInstructions,
    
    ManageReflectionQuestions: ManageReflectionQuestions,
    
    ManageSpinner: ManageSpinner,
    
    ManageAnnouncements: ManageAnnouncements,
    
    ClearLessonData: ClearLessonData,
    
    ManageXPLevels: ManageXPLevels,
    
    ImportLessons: ImportLessons,
    
    BubblePopGames: BubblePopGames,
    
    PinMountainGames: PinMountainGames,
    
    GlassBridgeGames: GlassBridgeGames,
    
    BubblePopGame: BubblePopGame,
    
    PinMountainGame: PinMountainGame,
    
    GlassBridgeGame: GlassBridgeGame,
    
    CreateLessonFormat: CreateLessonFormat,
    
    ImportLessonsJSON: ImportLessonsJSON,
    
    HealthQuestBridge: HealthQuestBridge,
    
    JSONFormatExamples: JSONFormatExamples,
    
    BackendRebuildGuide: BackendRebuildGuide,
    
    ImportGlowRidgeContent: ImportGlowRidgeContent,
    
    GlowRidgePath: GlowRidgePath,
    
    HealthQuestIntegrationArchitecture: HealthQuestIntegrationArchitecture,
    
    AdminPanelArchitecture: AdminPanelArchitecture,
    
    ExportData: ExportData,
    
    ScheduledExports: ScheduledExports,
    
    GameTester: GameTester,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Home />} />
                
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/LumosNook" element={<LumosNook />} />
                
                <Route path="/TreasureRoom" element={<TreasureRoom />} />
                
                <Route path="/Hub" element={<Hub />} />
                
                <Route path="/LumosCastle" element={<LumosCastle />} />
                
                <Route path="/AdventureAcademy" element={<AdventureAcademy />} />
                
                <Route path="/MatchingGames" element={<MatchingGames />} />
                
                <Route path="/DopamineCheckIn" element={<DopamineCheckIn />} />
                
                <Route path="/MindfulMunchies" element={<MindfulMunchies />} />
                
                <Route path="/MindfulKitchen" element={<MindfulKitchen />} />
                
                <Route path="/AssessmentComparison" element={<AssessmentComparison />} />
                
                <Route path="/ManageLessons" element={<ManageLessons />} />
                
                <Route path="/ManageShopItems" element={<ManageShopItems />} />
                
                <Route path="/ManageBadges" element={<ManageBadges />} />
                
                <Route path="/ManageRewards" element={<ManageRewards />} />
                
                <Route path="/ManageRewardRules" element={<ManageRewardRules />} />
                
                <Route path="/AdminPanel" element={<AdminPanel />} />
                
                <Route path="/UploadAssetImages" element={<UploadAssetImages />} />
                
                <Route path="/DebugLessons" element={<DebugLessons />} />
                
                <Route path="/ManageAssets" element={<ManageAssets />} />
                
                <Route path="/AdminInstructions" element={<AdminInstructions />} />
                
                <Route path="/ManageReflectionQuestions" element={<ManageReflectionQuestions />} />
                
                <Route path="/ManageSpinner" element={<ManageSpinner />} />
                
                <Route path="/ManageAnnouncements" element={<ManageAnnouncements />} />
                
                <Route path="/ClearLessonData" element={<ClearLessonData />} />
                
                <Route path="/ManageXPLevels" element={<ManageXPLevels />} />
                
                <Route path="/ImportLessons" element={<ImportLessons />} />
                
                <Route path="/BubblePopGames" element={<BubblePopGames />} />
                
                <Route path="/PinMountainGames" element={<PinMountainGames />} />
                
                <Route path="/GlassBridgeGames" element={<GlassBridgeGames />} />
                
                <Route path="/BubblePopGame" element={<BubblePopGame />} />
                
                <Route path="/PinMountainGame" element={<PinMountainGame />} />
                
                <Route path="/GlassBridgeGame" element={<GlassBridgeGame />} />
                
                <Route path="/CreateLessonFormat" element={<CreateLessonFormat />} />
                
                <Route path="/ImportLessonsJSON" element={<ImportLessonsJSON />} />
                
                <Route path="/HealthQuestBridge" element={<HealthQuestBridge />} />
                
                <Route path="/JSONFormatExamples" element={<JSONFormatExamples />} />
                
                <Route path="/BackendRebuildGuide" element={<BackendRebuildGuide />} />
                
                <Route path="/ImportGlowRidgeContent" element={<ImportGlowRidgeContent />} />
                
                <Route path="/GlowRidgePath" element={<GlowRidgePath />} />
                
                <Route path="/HealthQuestIntegrationArchitecture" element={<HealthQuestIntegrationArchitecture />} />
                
                <Route path="/AdminPanelArchitecture" element={<AdminPanelArchitecture />} />
                
                <Route path="/ExportData" element={<ExportData />} />
                
                <Route path="/ScheduledExports" element={<ScheduledExports />} />
                
                <Route path="/GameTester" element={<GameTester />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}