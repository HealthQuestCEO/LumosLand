import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Sparkles } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence } from "framer-motion";

export default function GlowRidgePath() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [npcs, setNPCs] = useState([]);
  const [selectedNPC, setSelectedNPC] = useState(null);
  const [conversations, setConversations] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showResponse, setShowResponse] = useState(false);
  const [response, setResponse] = useState("");
  const [xpEarned, setXpEarned] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadNPCs();
  }, []);

  const loadNPCs = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      const { data } = await base44.functions.invoke('glowRidgeConversations', { action: 'getNPCs' });
      setNPCs(data.npcs || []);
    } catch (error) {
      console.error("Error loading NPCs:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectNPC = async (npc) => {
    setSelectedNPC(npc);
    setCurrentIndex(0);
    setShowResponse(false);

    try {
      const { data } = await base44.functions.invoke('glowRidgeConversations', {
        action: 'getConversations',
        npcId: npc.npc_id
      });
      setConversations(data.conversations || []);
    } catch (error) {
      console.error("Error loading conversations:", error);
    }
  };

  const handleAnswer = async (answer) => {
    const currentConv = conversations[currentIndex];
    const responseText = answer === 'yes' ? currentConv.yes_response : currentConv.no_response;
    setResponse(responseText);
    setShowResponse(true);

    try {
      const { data } = await base44.functions.invoke('glowRidgeConversations', {
        action: 'answer',
        npcId: selectedNPC.npc_id,
        conversationId: currentConv.conversation_id,
        answer
      });

      setXpEarned(data.xp_awarded || 0);
    } catch (error) {
      console.error("Error recording answer:", error);
    }
  };

  const handleNext = () => {
    if (currentIndex < conversations.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setShowResponse(false);
      setXpEarned(0);
    } else {
      setSelectedNPC(null);
      setConversations([]);
      setCurrentIndex(0);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="text-6xl mb-4 animate-bounce">🌲</div>
          <p className="text-[#00d1ff] font-semibold">Loading Glow Ridge...</p>
        </div>
      </div>
    );
  }

  // NPC Selection Screen
  if (!selectedNPC) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("Home"))}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-[#00d1ff]">🌲 Glow Ridge Path</h1>
            <p className="text-gray-600">Meet friendly NPCs and learn healthy habits</p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {npcs.map((npc) => (
            <motion.div
              key={npc.npc_id}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Card
                className={`cursor-pointer border-2 ${
                  npc.isUnlocked
                    ? "border-[#00d1ff] hover:shadow-xl"
                    : "border-gray-300 opacity-50 cursor-not-allowed"
                }`}
                onClick={() => npc.isUnlocked && handleSelectNPC(npc)}
              >
                <CardHeader>
                  <div className="text-6xl mb-2 text-center">{npc.emoji}</div>
                  <CardTitle className="text-center text-[#00d1ff]">
                    {npc.npc_name}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 text-center">{npc.topic}</p>
                  {!npc.isUnlocked && (
                    <p className="text-xs text-red-600 text-center mt-2">
                      🔒 Unlock at Level {npc.unlock_level}
                    </p>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    );
  }

  // Conversation Screen
  const currentConv = conversations[currentIndex];

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => setSelectedNPC(null)}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-[#00d1ff]">
            {selectedNPC.emoji} {selectedNPC.npc_name}
          </h1>
          <p className="text-gray-600">
            Question {currentIndex + 1} of {conversations.length}
          </p>
        </div>
      </div>

      <Card className="border-2 border-[#00d1ff]">
        <CardContent className="p-8">
          <AnimatePresence mode="wait">
            {!showResponse ? (
              <motion.div
                key="question"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                <p className="text-xl text-gray-800 text-center">
                  {currentConv.question}
                </p>

                <div className="flex gap-4 justify-center">
                  <Button
                    onClick={() => handleAnswer('yes')}
                    className="bg-green-500 hover:bg-green-600 text-white px-8 py-4 text-lg"
                  >
                    👍 Yes
                  </Button>
                  <Button
                    onClick={() => handleAnswer('no')}
                    className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 text-lg"
                  >
                    👎 Not Yet
                  </Button>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="response"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                <div className="text-center">
                  <div className="text-6xl mb-4">{selectedNPC.emoji}</div>
                  <p className="text-xl text-gray-800 mb-4">{response}</p>
                  
                  {currentConv.key_takeaway && (
                    <div className="bg-[#e0f8f5] p-4 rounded-lg mt-4">
                      <p className="text-sm text-[#1165b3]">
                        💡 {currentConv.key_takeaway}
                      </p>
                    </div>
                  )}

                  {xpEarned > 0 && (
                    <div className="flex items-center justify-center gap-2 mt-4 text-[#00d1ff] font-bold">
                      <Sparkles className="w-5 h-5" />
                      <span>+{xpEarned} XP</span>
                    </div>
                  )}
                </div>

                <Button
                  onClick={handleNext}
                  className="w-full bg-[#00d1ff] hover:bg-[#66bfad] text-white py-4 text-lg"
                >
                  {currentIndex < conversations.length - 1 ? "Next Question" : "Finish"}
                </Button>
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>
    </div>
  );
}