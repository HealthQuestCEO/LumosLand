import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Search, Heart, Clock, ChefHat } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function MindfulKitchen() {
  const navigate = useNavigate();
  const [recipes, setRecipes] = useState([]);
  const [favorites, setFavorites] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedRecipe, setSelectedRecipe] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [timeFilter, setTimeFilter] = useState("all");
  const [dietaryFilter, setDietaryFilter] = useState("all");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const user = await base44.auth.me();
      
      const allRecipes = await base44.entities.Recipe.list();
      setRecipes(allRecipes);

      const userFavorites = await base44.entities.FavoriteRecipe.filter({ user_email: user.email });
      setFavorites(userFavorites.map(f => f.recipe_id));
    } catch (error) {
      console.error("Error loading recipes:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleFavorite = async (recipe) => {
    try {
      const user = await base44.auth.me();
      
      if (favorites.includes(recipe.recipe_id)) {
        // Remove from favorites
        const existingFavorites = await base44.entities.FavoriteRecipe.filter({
          user_email: user.email,
          recipe_id: recipe.recipe_id
        });
        if (existingFavorites.length > 0) {
          await base44.entities.FavoriteRecipe.delete(existingFavorites[0].id);
        }
        setFavorites(favorites.filter(id => id !== recipe.recipe_id));
      } else {
        // Add to favorites and award coins
        await base44.entities.FavoriteRecipe.create({
          user_email: user.email,
          recipe_id: recipe.recipe_id,
          coins_earned: 20
        });

        // Award coins
        const lumoStates = await base44.entities.LumoState.filter({ user_email: user.email });
        if (lumoStates.length > 0) {
          await base44.entities.LumoState.update(lumoStates[0].id, {
            total_coins: lumoStates[0].total_coins + 20
          });
        }

        setFavorites([...favorites, recipe.recipe_id]);
        alert("Recipe saved! +20 Coins 🪙");
      }
    } catch (error) {
      console.error("Error favoriting recipe:", error);
    }
  };

  const filteredRecipes = recipes.filter(recipe => {
    const matchesSearch = recipe.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === "all" || recipe.primary_category === categoryFilter;
    const matchesTime = timeFilter === "all" || (recipe.filter_time && recipe.filter_time.includes(timeFilter));
    const matchesDietary = dietaryFilter === "all" || (recipe.filter_dietary && recipe.filter_dietary.includes(dietaryFilter));
    
    return matchesSearch && matchesCategory && matchesTime && matchesDietary;
  });

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">Loading kitchen...</div>;
  }

  if (selectedRecipe) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#e0f8f5] to-[#66bfad]/20 p-4 sm:p-8">
        <div className="max-w-4xl mx-auto">
          <Button
            variant="outline"
            onClick={() => setSelectedRecipe(null)}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Recipes
          </Button>

          <Card className="border-2 border-[#66bfad]/30 shadow-xl">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-3xl text-[#1165b3] mb-2" style={{ fontFamily: 'Poppins' }}>
                    {selectedRecipe.title}
                  </CardTitle>
                  <div className="flex flex-wrap gap-2 mb-4">
                    <Badge className="bg-[#66bfad] text-white">{selectedRecipe.primary_category}</Badge>
                    <Badge variant="outline" className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {selectedRecipe.total_time_min} min
                    </Badge>
                  </div>
                </div>
                <Button
                  onClick={() => handleFavorite(selectedRecipe)}
                  variant={favorites.includes(selectedRecipe.recipe_id) ? "default" : "outline"}
                  className="ml-4"
                >
                  <Heart className={`w-5 h-5 ${favorites.includes(selectedRecipe.recipe_id) ? 'fill-current' : ''}`} />
                </Button>
              </div>
            </CardHeader>

            <CardContent className="space-y-6">
              {selectedRecipe.image_url && (
                <img 
                  src={selectedRecipe.image_url} 
                  alt={selectedRecipe.title}
                  className="w-full h-64 object-cover rounded-2xl"
                />
              )}

              {selectedRecipe.mindful_notes && (
                <div className="bg-gradient-to-r from-[#e0f8f5] to-white rounded-2xl p-6 border-2 border-[#66bfad]/30">
                  <h3 className="font-bold text-[#1165b3] mb-2 flex items-center gap-2">
                    <span className="text-2xl">🧘</span>
                    Mindful Moment
                  </h3>
                  <p className="text-gray-800" style={{ fontFamily: 'Poppins' }}>
                    {selectedRecipe.mindful_notes}
                  </p>
                </div>
              )}

              <div>
                <h3 className="text-xl font-bold text-[#1165b3] mb-3">Ingredients</h3>
                <div className="bg-white rounded-lg p-4 whitespace-pre-line">
                  {selectedRecipe.ingredients}
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-[#1165b3] mb-3">Instructions</h3>
                <div className="bg-white rounded-lg p-4 whitespace-pre-line">
                  {selectedRecipe.instructions}
                </div>
              </div>

              {(selectedRecipe.filter_texture || selectedRecipe.filter_dietary || selectedRecipe.filter_nutrients) && (
                <div>
                  <h3 className="text-xl font-bold text-[#1165b3] mb-3">Recipe Tags</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedRecipe.filter_texture?.split(',').map(tag => (
                      <Badge key={tag} variant="outline">{tag.trim()}</Badge>
                    ))}
                    {selectedRecipe.filter_dietary?.split(',').map(tag => (
                      <Badge key={tag} className="bg-green-100 text-green-800">{tag.trim()}</Badge>
                    ))}
                    {selectedRecipe.filter_nutrients?.split(',').map(tag => (
                      <Badge key={tag} className="bg-blue-100 text-blue-800">{tag.trim()}</Badge>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#e0f8f5] to-[#66bfad]/20 p-4 sm:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("Hub"))}
            className="rounded-full"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-[#1165b3]" style={{ fontFamily: 'Poppins' }}>
              🍳 Lumo's Mindful Kitchen
            </h1>
            <p className="text-gray-600">Discover nourishing recipes and mindful cooking</p>
          </div>
        </div>

        {/* Filters */}
        <Card className="mb-6 border-2 border-[#66bfad]/30">
          <CardContent className="p-6">
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search recipes..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>

              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="FUEL-UPS">Fuel-Ups</SelectItem>
                  <SelectItem value="ONE-POT">One-Pot</SelectItem>
                  <SelectItem value="RAINBOW">Rainbow</SelectItem>
                  <SelectItem value="KID-POWERED">Kid-Powered</SelectItem>
                  <SelectItem value="MIXER">Mixer</SelectItem>
                </SelectContent>
              </Select>

              <Select value={timeFilter} onValueChange={setTimeFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Time" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any Time</SelectItem>
                  <SelectItem value="LOW-PREP">Low-Prep</SelectItem>
                  <SelectItem value="30-MIN-MEAL">30-Min Meal</SelectItem>
                  <SelectItem value="WEEKEND-PROJECT">Weekend Project</SelectItem>
                </SelectContent>
              </Select>

              <Select value={dietaryFilter} onValueChange={setDietaryFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Dietary" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Dietary</SelectItem>
                  <SelectItem value="GF">Gluten-Free</SelectItem>
                  <SelectItem value="DF">Dairy-Free</SelectItem>
                  <SelectItem value="VEG">Vegetarian</SelectItem>
                  <SelectItem value="P-BASE">Plant-Based</SelectItem>
                  <SelectItem value="NUT-FREE">Nut-Free</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Recipe Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredRecipes.map((recipe, index) => (
            <motion.div
              key={recipe.recipe_id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.03 }}
            >
              <Card className="border-2 border-[#66bfad]/20 hover:shadow-xl transition-all duration-300 h-full cursor-pointer">
                <div onClick={() => setSelectedRecipe(recipe)}>
                  {recipe.image_url && (
                    <div className="h-48 overflow-hidden rounded-t-lg">
                      <img 
                        src={recipe.image_url} 
                        alt={recipe.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between gap-2">
                      <CardTitle className="text-lg text-[#1165b3] line-clamp-2">
                        {recipe.title}
                      </CardTitle>
                      <Badge className="bg-[#66bfad] text-white text-xs whitespace-nowrap">
                        {recipe.primary_category}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {recipe.total_time_min} min
                      </span>
                      {recipe.filter_difficulty && (
                        <Badge variant="outline" className="text-xs">
                          {recipe.filter_difficulty}
                        </Badge>
                      )}
                    </div>
                    {recipe.mindful_notes && (
                      <p className="text-xs text-gray-600 line-clamp-2 italic mb-3">
                        💡 {recipe.mindful_notes}
                      </p>
                    )}
                  </CardContent>
                </div>
                <div className="px-6 pb-4">
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleFavorite(recipe);
                    }}
                    variant={favorites.includes(recipe.recipe_id) ? "default" : "outline"}
                    className="w-full"
                    size="sm"
                  >
                    <Heart className={`w-4 h-4 mr-2 ${favorites.includes(recipe.recipe_id) ? 'fill-current' : ''}`} />
                    {favorites.includes(recipe.recipe_id) ? 'Saved' : 'Save Recipe (+20 🪙)'}
                  </Button>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        {filteredRecipes.length === 0 && (
          <div className="text-center py-12">
            <ChefHat className="w-16 h-16 mx-auto text-gray-300 mb-4" />
            <p className="text-gray-600 text-lg">No recipes found. Try different filters!</p>
          </div>
        )}
      </div>
    </div>
  );
}