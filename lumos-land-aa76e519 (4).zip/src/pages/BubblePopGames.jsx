
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Play, Trophy, RotateCcw, ChevronUp, ChevronDown } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence } from "framer-motion";

export default function BubblePopGames() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [availableLessons, setAvailableLessons] = useState([]);
  const [completedLessons, setCompletedLessons] = useState([]);
  const [completionData, setCompletionData] = useState({});
  const [showCompleted, setShowCompleted] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [lessonsByQuest, setLessonsByQuest] = useState({}); // New state to hold lessons grouped by quest

  useEffect(() => {
    loadLessons();
  }, []);

  const loadLessons = async () => {
    try {
      setIsLoading(true);
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      // Fetch ALL active lessons
      const allActiveLessons = await base44.entities.GameLesson.filter({
        is_active: true
      });

      // ✅ Bubble Pop shows EVERYTHING but DEDUPLICATED:
      // 1. ALL assessments (pre/post/feedback) - regardless of game_style
      // 2. ALL regular lessons (but only ONE version per quest+number)
      
      // First, separate assessments from regular lessons
      const assessments = allActiveLessons.filter(lesson => lesson.is_assessment);
      const regularLessons = allActiveLessons.filter(lesson => !lesson.is_assessment);
      
      // Deduplicate regular lessons by quest+number, prefer bubble_pop version
      const lessonMap = new Map();
      
      regularLessons.forEach(lesson => {
        const key = `${lesson.quest}_${lesson.number}`;
        const existing = lessonMap.get(key);
        
        if (!existing) {
          // First lesson with this quest+number, add it
          lessonMap.set(key, lesson);
        } else {
          // Already have this quest+number, prefer bubble_pop version if available
          if (lesson.game_style === 'bubble_pop' && existing.game_style !== 'bubble_pop') {
            lessonMap.set(key, lesson); // Replace with bubble_pop version
          }
          // If both are bubble_pop or neither, keep the first one found (existing)
        }
      });
      
      // Deduplicate assessments by quest+number (prefer bubble_pop if multiple)
      const assessmentMap = new Map();
      
      assessments.forEach(lesson => {
        const key = `${lesson.quest}_${lesson.number}`;
        const existing = assessmentMap.get(key);
        
        if (!existing) {
          assessmentMap.set(key, lesson);
        } else {
          // Prefer bubble_pop version for assessments too
          if (lesson.game_style === 'bubble_pop' && existing.game_style !== 'bubble_pop') {
            assessmentMap.set(key, lesson);
          }
        }
      });
      
      // Combine deduplicated lessons
      const deduplicatedLessons = [...assessmentMap.values(), ...lessonMap.values()];
      
      // Sort by quest and number
      const finalSortedLessons = deduplicatedLessons.sort((a, b) => {
        if (a.quest !== b.quest) return (a.quest || "").localeCompare(b.quest || "");
        return (a.number || 0) - (b.number || 0);
      });

      // Group the sorted lessons by quest
      const grouped = finalSortedLessons.reduce((acc, lesson) => {
        if (!acc[lesson.quest]) {
          acc[lesson.quest] = [];
        }
        acc[lesson.quest].push(lesson);
        return acc;
      }, {});

      setLessonsByQuest(grouped);

      // Fetch ALL completions for this user (globally)
      const allCompletions = await base44.entities.LessonCompletion.list();
      const userCompletions = allCompletions.filter(c => c.user_email === currentUser.email);

      // Create a map of completed quest+number combinations
      const completedQuestNumbers = new Set();
      userCompletions.forEach(completion => {
        if (completion.quest_id && completion.lesson_number !== undefined) {
          completedQuestNumbers.add(`${completion.quest_id}_${completion.lesson_number}`);
        }
      });

      const newCompletionData = {};
      const filteredCompletedLessons = [];
      const filteredAvailableLessons = [];

      // Iterate through the final sorted lessons to determine completion status
      for (const lesson of finalSortedLessons) {
        const questNumberKey = `${lesson.quest}_${lesson.number}`;
        
        if (completedQuestNumbers.has(questNumberKey)) {
          // Lesson is completed (by quest+number match)
          const completion = userCompletions.find(c => 
            c.quest_id === lesson.quest && c.lesson_number === lesson.number
          );
          if (completion) {
            newCompletionData[lesson.id] = {
              score: completion.score,
              total_questions: completion.total_questions,
            };
          }
          filteredCompletedLessons.push(lesson);
        } else {
          // Lesson is not completed yet
          filteredAvailableLessons.push(lesson);
        }
      }

      setCompletionData(newCompletionData);
      setCompletedLessons(filteredCompletedLessons);
      
      // Show only next 3 available lessons (or all if less than 3)
      setAvailableLessons(filteredAvailableLessons.slice(0, 3));
    } catch (error) {
      console.error("Error loading lessons:", error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="text-6xl mb-4 animate-bounce">🫧</div>
          <p className="text-[#1165b3] font-semibold">Loading lessons...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdventureAcademy"))}
          className="rounded-full"
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#66bfad]">🫧 Bubble Pop Games</h1>
          <p className="text-gray-600">Pop the right bubble to answer!</p>
        </div>
      </div>

      <div className="space-y-8">
        <div>
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Available Lessons</h2>
          {availableLessons.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <p className="text-gray-600">No more lessons available. Great work!</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-3 gap-6">
              {availableLessons.map((lesson) => (
                <motion.div
                  key={lesson.id}
                  whileHover={{ scale: 1.02, y: -5 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Card className="border-2 border-[#66bfad]/30 hover:border-[#66bfad] hover:shadow-xl transition-all">
                    <CardHeader>
                      <div className="flex justify-between items-start mb-2">
                        <Badge className="bg-[#66bfad] text-white">Lesson {lesson.number}</Badge>
                        <div className="flex gap-2">
                          <Badge variant="outline" className="border-[#66bfad] text-[#66bfad]">🪙 {lesson.coins_reward || 50}</Badge>
                          <Badge variant="outline" className="border-[#1165b3] text-[#1165b3]">✨ {lesson.xp_reward || 50}</Badge>
                        </div>
                      </div>
                      <CardTitle className="text-lg text-[#1165b3]">{lesson.name}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 text-sm mb-4">{lesson.description}</p>
                      <Button
                        onClick={() => navigate(createPageUrl("BubblePopGame") + `?lessonId=${lesson.id}`)}
                        className="w-full bg-[#66bfad] hover:bg-[#4a9b8e] text-white"
                      >
                        <Play className="w-4 h-4 mr-2" />
                        Start Lesson
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        {completedLessons.length > 0 && (
          <div>
            <button
              onClick={() => setShowCompleted(!showCompleted)}
              className="flex items-center justify-between w-full p-4 bg-white rounded-xl shadow-md hover:shadow-lg transition-all border-2 border-[#66bfad]/30"
            >
              <div className="flex items-center gap-3">
                <Trophy className="w-6 h-6 text-[#ffa400]" />
                <h2 className="text-2xl font-bold text-gray-800">Completed Lessons ({completedLessons.length})</h2>
              </div>
              {showCompleted ? <ChevronUp className="w-6 h-6" /> : <ChevronDown className="w-6 h-6" />}
            </button>

            <AnimatePresence>
              {showCompleted && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-4 grid md:grid-cols-2 lg:grid-cols-3 gap-6"
                >
                  {completedLessons.map((lesson) => {
                    const completion = completionData[lesson.id];
                    return (
                      <Card key={lesson.id} className="border-2 border-green-200 bg-green-50/50">
                        <CardHeader>
                          <div className="flex justify-between items-start mb-2">
                            <Badge className="bg-green-500">✓ Complete</Badge>
                            {completion && (
                              <Badge variant="outline">
                                Score: {completion.score}/{completion.total_questions}
                              </Badge>
                            )}
                          </div>
                          <CardTitle className="text-lg text-[#1165b3]">{lesson.name}</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div>
                            <p className="text-sm font-semibold text-gray-700 mb-1">Lesson:</p>
                            <p className="text-sm text-gray-600">{lesson.description}</p>
                          </div>
                          
                          {lesson.keyTakeaways && (
                            <div>
                              <p className="text-sm font-semibold text-gray-700 mb-1">Key Takeaways:</p>
                              <p className="text-sm text-gray-600">{lesson.keyTakeaways}</p>
                            </div>
                          )}

                          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                            <p className="text-xs text-amber-800 font-semibold mb-1">📖 Review Mode</p>
                            <p className="text-xs text-amber-700">No rewards earned when reviewing</p>
                          </div>

                          <Button
                            onClick={() => navigate(createPageUrl("BubblePopGame") + `?lessonId=${lesson.id}&review=true`)}
                            variant="outline"
                            className="w-full border-[#66bfad] text-[#66bfad] hover:bg-[#66bfad] hover:text-white"
                          >
                            <RotateCcw className="w-4 h-4 mr-2" />
                            Review Lesson
                          </Button>
                        </CardContent>
                      </Card>
                    );
                  })}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}
