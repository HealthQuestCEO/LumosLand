
import React, { useState, useEffect } from "react";
import { LessonCompletion, LumoState, GameLesson } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Play, CheckCircle, Upload } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

const QUEST_ID = "KindnessCrusaders";

export default function MatchingGames() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [lessons, setLessons] = useState([]);
  const [completedLessons, setCompletedLessons] = useState([]);
  const [lumoState, setLumoState] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadLessons();
  }, []);

  const loadLessons = async () => {
    setIsLoading(true);
    try {
      const currentUser = await User.me();
      setUser(currentUser);

      const states = await LumoState.filter({ user_email: currentUser.email });
      if (states.length > 0) {
        setLumoState(states[0]);
      }

      // Fetch lessons directly with filters for active and game_format 'match'
      const allLessons = await GameLesson.filter({ 
        is_active: true,
        game_format: 'match'
      });
      
      // Sort by quest name, then by lesson number
      const sortedLessons = allLessons.sort((a, b) => {
        // Ensure quest property exists for comparison, or treat missing as a specific order
        const questA = a.quest || ''; 
        const questB = b.quest || '';

        if (questA !== questB) {
          return questA.localeCompare(questB);
        }
        return a.number - b.number;
      });

      setLessons(sortedLessons);

      const completionRecords = await LessonCompletion.filter({ user_email: currentUser.email });
      const completedIds = completionRecords.map(c => c.lesson_id);
      setCompletedLessons(completedIds);
      
    } catch (error) {
      console.error("Error loading lessons:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLessonClick = (lesson) => {
    console.log("Navigating to lesson:", lesson.id);
    // Use PathOfWisdom page which has matching game logic
    navigate(createPageUrl("PathOfWisdom") + `?lesson=${lesson.id}`);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="text-6xl mb-4 animate-bounce">🧩</div>
          <p className="text-[#1165b3] font-semibold">Loading lessons...</p>
        </div>
      </div>
    );
  }

  if (lessons.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-[#e0f8f5] to-[#66bfad]/20 p-4">
        <Card className="max-w-lg">
          <CardHeader>
            <CardTitle className="text-red-600 text-2xl">No Matching Game Lessons Found</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-6xl text-center mb-4">🧩</div>
            <p className="text-gray-700">
              No active matching game lessons are available in the database yet.
            </p>
            <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-4 space-y-2">
              <p className="font-semibold text-blue-900">To add lessons:</p>
              <ol className="list-decimal list-inside space-y-1 text-sm text-blue-800 ml-2">
                <li>Go to the Import Lessons page</li>
                <li>Upload your Kindness Crusaders JSON file</li>
                <li>Wait for the import to complete</li>
                <li>Make sure lessons have `game_format: "match"` and `is_active: true`</li>
                <li>Come back here to play!</li>
              </ol>
            </div>
            <div className="flex gap-3">
              <Button 
                onClick={() => navigate(createPageUrl("ImportLessons"))} 
                className="flex-1 bg-[#1165b3] hover:bg-[#1165b3]/90"
              >
                <Upload className="w-4 h-4 mr-2" />
                Import Lessons
              </Button>
              <Button 
                onClick={() => navigate(createPageUrl("AdventureAcademy"))} 
                variant="outline"
                className="flex-1"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Go Back
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdventureAcademy"))}
          className="rounded-full"
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1165b3]">🧩 Path of Wisdom</h1>
          <p className="text-gray-600">Select a lesson to begin your adventure! ({lessons.length} lessons)</p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {lessons.map((lesson, index) => {
          const isCompleted = completedLessons.includes(lesson.id);

          return (
            <motion.div
              key={lesson.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.03, y: -5 }}
            >
              <Card className={`border-2 hover:shadow-xl transition-all duration-300 h-full flex flex-col ${
                isCompleted ? "border-green-400 bg-green-50/50" : "border-[#66bfad]/30 hover:border-[#66bfad]"
              }`}>
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <Badge className="bg-[#66bfad] text-white">
                      {lesson.quest ? `${lesson.quest} - ` : ''}Lesson {lesson.number}
                    </Badge>
                    {isCompleted && (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    )}
                  </div>
                  <CardTitle className="text-lg text-[#1165b3] line-clamp-2">
                    {lesson.name}
                  </CardTitle>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col justify-between">
                  <p className="text-sm text-gray-600 mb-4 line-clamp-3">
                    {lesson.description}
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Reward:</span>
                      <div className="flex gap-2">
                        <Badge variant="outline" className="bg-amber-50">
                          {lesson.coins_total || 50} 🪙
                        </Badge>
                        <Badge variant="outline" className="bg-blue-50">
                          {lesson.xp_total || 50} ⚡
                        </Badge>
                      </div>
                    </div>
                    <Button
                      onClick={() => handleLessonClick(lesson)}
                      className="w-full bg-gradient-to-r from-[#66bfad] to-[#1165b3] text-white hover:shadow-lg transition-all"
                    >
                      <Play className="w-4 h-4 mr-2" />
                      {isCompleted ? "Play Again" : "Start Lesson"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
