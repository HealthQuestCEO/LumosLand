
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Search } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function DebugLessons() {
  const navigate = useNavigate();
  const [lessons, setLessons] = useState([]);
  const [filter, setFilter] = useState("active"); // Changed default to "active"
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadLessons();
  }, []);

  const loadLessons = async () => {
    try {
      const allLessons = await base44.entities.GameLesson.list();
      console.log("All lessons from DB:", allLessons);
      
      // Log first lesson details
      if (allLessons.length > 0) {
        console.log("First lesson full details:", JSON.stringify(allLessons[0], null, 2));
      }
      
      setLessons(allLessons);
    } catch (error) {
      console.error("Error loading lessons:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredLessons = lessons.filter(lesson => {
    if (filter === "all") return true;
    if (filter === "active") return lesson.is_active === true;
    if (filter === "inactive") return lesson.is_active === false;
    if (filter === "no_questions") return !lesson.questions || lesson.questions.length === 0;
    if (filter === "has_questions") return lesson.questions && lesson.questions.length > 0;
    if (filter === "matching") return lesson.type === "match"; // ✅ Changed from game_format to type
    if (filter === "mcq") return lesson.type === "mcq"; // ✅ Changed from game_format to type
    return true;
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="text-6xl mb-4 animate-bounce">🔍</div>
          <p className="text-[#1165b3] font-semibold">Loading lessons...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdminPanel"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1165b3]">🔍 Debug Lessons</h1>
          <p className="text-gray-600">Check which lessons have questions stored</p>
        </div>
      </div>

      <Card className="mb-6 bg-yellow-50 border-yellow-300">
        <CardContent className="p-4">
          <p className="text-sm text-yellow-800">
            <strong>📊 Summary:</strong> Total lessons: {lessons.length} | 
            Active: {lessons.filter(l => l.is_active === true).length} | 
            Inactive: {lessons.filter(l => l.is_active === false).length} | 
            With questions: {lessons.filter(l => l.questions && l.questions.length > 0).length} | 
            Without questions: {lessons.filter(l => !l.questions || l.questions.length === 0).length}
          </p>
        </CardContent>
      </Card>

      <div className="mb-6 flex gap-2 flex-wrap">
        <Button
          onClick={() => setFilter("active")}
          variant={filter === "active" ? "default" : "outline"}
          className="bg-green-600 text-white"
        >
          ✅ Active Only ({lessons.filter(l => l.is_active === true).length})
        </Button>
        <Button
          onClick={() => setFilter("inactive")}
          variant={filter === "inactive" ? "default" : "outline"}
          className="bg-red-100 text-red-700"
        >
          ❌ Inactive Only ({lessons.filter(l => l.is_active === false).length})
        </Button>
        <Button
          onClick={() => setFilter("all")}
          variant={filter === "all" ? "default" : "outline"}
        >
          All ({lessons.length})
        </Button>
        <Button
          onClick={() => setFilter("has_questions")}
          variant={filter === "has_questions" ? "default" : "outline"}
        >
          Has Questions ({lessons.filter(l => l.questions && l.questions.length > 0).length})
        </Button>
        <Button
          onClick={() => setFilter("no_questions")}
          variant={filter === "no_questions" ? "default" : "outline"}
        >
          No Questions ({lessons.filter(l => !l.questions || l.questions.length === 0).length})
        </Button>
        <Button
          onClick={() => setFilter("matching")}
          variant={filter === "matching" ? "default" : "outline"}
        >
          Matching ({lessons.filter(l => l.type === "match").length})
        </Button>
        <Button
          onClick={() => setFilter("mcq")}
          variant={filter === "mcq" ? "default" : "outline"}
        >
          MCQ ({lessons.filter(l => l.type === "mcq").length})
        </Button>
      </div>

      <div className="grid gap-4">
        {filteredLessons.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">No lessons found matching this filter</p>
            </CardContent>
          </Card>
        ) : (
          filteredLessons.map((lesson) => {
            const hasQuestions = lesson.questions && lesson.questions.length > 0;
            
            return (
              <Card key={lesson.id} className={`border-2 ${hasQuestions ? 'border-green-300 bg-green-50' : 'border-red-300 bg-red-50'}`}>
                <CardHeader>
                  <CardTitle className="flex justify-between items-start">
                    <div>
                      <div className="text-lg">
                        {lesson.quest} - Lesson {lesson.number}
                      </div>
                      <div className="text-sm font-normal text-gray-600">
                        {lesson.name} ({lesson.game_style})
                      </div>
                    </div>
                    <span className={`text-sm px-3 py-1 rounded-full ${
                      hasQuestions ? 'bg-green-200 text-green-800' : 'bg-red-200 text-red-800'
                    }`}>
                      {hasQuestions ? `✅ ${lesson.questions.length} questions` : '❌ No questions'}
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <p><strong>Type:</strong> {lesson.type || 'not set'}</p>
                    <p><strong>Game Style:</strong> {lesson.game_style || 'not set'}</p>
                    <p><strong>Active:</strong> {lesson.is_active ? '✅ Yes' : '❌ No'}</p>
                    <p><strong>Lesson ID:</strong> <code className="text-xs bg-gray-100 px-2 py-1 rounded">{lesson.id}</code></p>
                    
                    {hasQuestions && (
                      <details className="mt-4">
                        <summary className="cursor-pointer font-semibold text-blue-600 hover:text-blue-800">
                          👁️ View Questions ({lesson.questions.length})
                        </summary>
                        <div className="mt-2 p-3 bg-white rounded border">
                          <pre className="text-xs overflow-auto max-h-96">
                            {JSON.stringify(lesson.questions, null, 2)}
                          </pre>
                        </div>
                      </details>
                    )}
                    
                    {!hasQuestions && (
                      <div className="mt-4 p-3 bg-red-100 rounded border border-red-300">
                        <p className="text-red-800 font-semibold">⚠️ This lesson has no questions!</p>
                        <p className="text-red-700 text-xs mt-1">It won't appear in any game selection screens.</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}
