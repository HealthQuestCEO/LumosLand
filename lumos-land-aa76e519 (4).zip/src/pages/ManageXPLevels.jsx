
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Upload, Plus, Trash2, Edit, Check, X } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function ManageXPLevels() {
  const navigate = useNavigate();
  const [levels, setLevels] = useState([]);
  const [shopItems, setShopItems] = useState([]);
  const [bulkJSON, setBulkJSON] = useState("");
  const [showBulkImport, setShowBulkImport] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [message, setMessage] = useState("");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const allLevels = await base44.entities.LevelReward.list();
      allLevels.sort((a, b) => a.level - b.level);
      setLevels(allLevels);

      const items = await base44.entities.ShopItem.list();
      setShopItems(items);
    } catch (error) {
      console.error("Error loading levels:", error);
    }
  };

  const handleBulkImport = async () => {
    try {
      const levelsData = JSON.parse(bulkJSON);
      
      if (!Array.isArray(levelsData)) {
        alert("JSON must be an array of level objects");
        return;
      }

      for (const level of levelsData) {
        // Check if level already exists
        const existing = levels.find(l => l.level === level.level);
        if (existing) {
          await base44.entities.LevelReward.update(existing.id, level);
        } else {
          await base44.entities.LevelReward.create(level);
        }
      }

      setMessage(`Successfully imported ${levelsData.length} levels!`);
      setBulkJSON("");
      setShowBulkImport(false);
      await loadData();
      
      setTimeout(() => setMessage(""), 3000);
    } catch (error) {
      alert("Error importing levels: " + error.message);
    }
  };

  const handleEdit = (level) => {
    setEditingId(level.id);
    setEditForm(level);
  };

  const handleSave = async () => {
    try {
      await base44.entities.LevelReward.update(editingId, editForm);
      setEditingId(null);
      setEditForm({});
      setMessage("Level updated successfully!");
      await loadData();
      setTimeout(() => setMessage(""), 3000);
    } catch (error) {
      alert("Error updating level: " + error.message);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm("Are you sure you want to delete this level?")) return;
    
    try {
      await base44.entities.LevelReward.delete(id);
      setMessage("Level deleted successfully!");
      await loadData();
      setTimeout(() => setMessage(""), 3000);
    } catch (error) {
      alert("Error deleting level: " + error.message);
    }
  };

  const handleAddNew = () => {
    const nextLevel = levels.length > 0 ? Math.max(...levels.map(l => l.level)) + 1 : 1;
    const nextXP = levels.length > 0 ? Math.max(...levels.map(l => l.xp_required)) + 500 : 500;
    
    setEditingId("new");
    setEditForm({
      level: nextLevel,
      xp_required: nextXP,
      coins_reward: 100,
      xp_bonus: 0,
      badge_emoji: "⭐",
      badge_name: `Level ${nextLevel}`,
      celebration_message: `Congratulations! You reached Level ${nextLevel}!`,
      is_active: true,
      item_reward_id: "", // Initialize new fields
      unlock_npc_id: "", // Initialize new fields
      unlock_background: "" // Initialize new fields
    });
  };

  const handleCreateNew = async () => {
    try {
      await base44.entities.LevelReward.create(editForm);
      setEditingId(null);
      setEditForm({});
      setMessage("Level created successfully!");
      await loadData();
      setTimeout(() => setMessage(""), 3000);
    } catch (error) {
      alert("Error creating level: " + error.message);
    }
  };

  const exampleJSON = `[
  {
    "level": 1,
    "xp_required": 500,
    "coins_reward": 100,
    "xp_bonus": 0,
    "badge_emoji": "⭐",
    "badge_name": "Beginner Star",
    "celebration_message": "Welcome to Level 1! Keep learning!",
    "is_active": true
  },
  {
    "level": 2,
    "xp_required": 1000,
    "coins_reward": 150,
    "xp_bonus": 50,
    "badge_emoji": "🌟",
    "badge_name": "Rising Star",
    "celebration_message": "Amazing! You've reached Level 2!",
    "item_reward_id": "special_hat_001",
    "unlock_npc_id": "luna_owl",
    "unlock_background": "winter",
    "is_active": true
  },
  {
    "level": 5,
    "xp_required": 3000,
    "coins_reward": 300,
    "xp_bonus": 100,
    "badge_emoji": "🏆",
    "badge_name": "Champion",
    "celebration_message": "Incredible! You're now a Champion!",
    "unlock_npc_id": "benny_bear",
    "is_active": true
  }
]`;

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdminPanel"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold text-[#1165b3]">Manage XP Levels</h1>
          <p className="text-gray-600">Set XP requirements and rewards for each level</p>
        </div>
        <Button
          onClick={() => setShowBulkImport(!showBulkImport)}
          className="bg-[#66bfad]"
        >
          <Upload className="w-4 h-4 mr-2" />
          Bulk Import
        </Button>
        <Button
          onClick={handleAddNew}
          className="bg-[#ffa400]"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Level
        </Button>
      </div>

      {message && (
        <Alert className="mb-6 bg-green-100 border-green-300">
          <AlertDescription className="text-green-800">{message}</AlertDescription>
        </Alert>
      )}

      {showBulkImport && (
        <Card className="mb-6 border-2 border-[#66bfad]">
          <CardHeader>
            <CardTitle>Bulk Import Levels (JSON)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Paste JSON Array:</label>
              <Textarea
                value={bulkJSON}
                onChange={(e) => setBulkJSON(e.target.value)}
                placeholder={exampleJSON}
                className="h-64 font-mono text-sm"
              />
            </div>
            <div className="flex gap-3">
              <Button onClick={handleBulkImport} className="bg-[#66bfad]">
                <Upload className="w-4 h-4 mr-2" />
                Import Levels
              </Button>
              <Button variant="outline" onClick={() => setShowBulkImport(false)}>
                Cancel
              </Button>
            </div>
            <details className="mt-4">
              <summary className="cursor-pointer text-sm font-semibold text-gray-700 mb-2">
                📝 Example JSON Format
              </summary>
              <pre className="bg-gray-100 p-4 rounded-lg text-xs overflow-x-auto">
                {exampleJSON}
              </pre>
            </details>
          </CardContent>
        </Card>
      )}

      {/* Levels List */}
      <div className="space-y-4">
        {levels.map((level) => (
          <Card key={level.id} className="border-2 border-gray-200">
            {editingId === level.id ? (
              <CardContent className="p-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Level</label>
                    <Input
                      type="number"
                      value={editForm.level}
                      onChange={(e) => setEditForm({...editForm, level: parseInt(e.target.value)})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">XP Required</label>
                    <Input
                      type="number"
                      value={editForm.xp_required}
                      onChange={(e) => setEditForm({...editForm, xp_required: parseInt(e.target.value)})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Coins Reward</label>
                    <Input
                      type="number"
                      value={editForm.coins_reward}
                      onChange={(e) => setEditForm({...editForm, coins_reward: parseInt(e.target.value)})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">XP Bonus</label>
                    <Input
                      type="number"
                      value={editForm.xp_bonus || 0}
                      onChange={(e) => setEditForm({...editForm, xp_bonus: parseInt(e.target.value)})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Badge Emoji</label>
                    <Input
                      value={editForm.badge_emoji}
                      onChange={(e) => setEditForm({...editForm, badge_emoji: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Badge Name</label>
                    <Input
                      value={editForm.badge_name}
                      onChange={(e) => setEditForm({...editForm, badge_name: e.target.value})}
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium mb-1">Celebration Message</label>
                    <Input
                      value={editForm.celebration_message}
                      onChange={(e) => setEditForm({...editForm, celebration_message: e.target.value})}
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium mb-1">Item Reward (optional)</label>
                    <select
                      value={editForm.item_reward_id || ""}
                      onChange={(e) => setEditForm({...editForm, item_reward_id: e.target.value})}
                      className="w-full p-2 border rounded"
                    >
                      <option value="">No item reward</option>
                      {shopItems.map(item => (
                        <option key={item.item_id} value={item.item_id}>
                          {item.emoji} {item.item_name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium mb-1">Unlock NPC in Glow Ridge (optional)</label>
                    <Input
                      value={editForm.unlock_npc_id || ""}
                      onChange={(e) => setEditForm({...editForm, unlock_npc_id: e.target.value})}
                      placeholder="e.g., luna_owl, benny_bear"
                    />
                    <p className="text-xs text-gray-500 mt-1">Enter the NPC ID to unlock at this level</p>
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium mb-1">Unlock Background/Season (optional)</label>
                    <select
                      value={editForm.unlock_background || ""}
                      onChange={(e) => setEditForm({...editForm, unlock_background: e.target.value})}
                      className="w-full p-2 border rounded"
                    >
                      <option value="">No background unlock</option>
                      <option value="spring">🌸 Spring</option>
                      <option value="summer">☀️ Summer</option>
                      <option value="fall">🍂 Fall</option>
                      <option value="winter">❄️ Winter</option>
                    </select>
                  </div>
                </div>
                <div className="flex gap-3 mt-4">
                  <Button onClick={handleSave} className="bg-green-600">
                    <Check className="w-4 h-4 mr-2" />
                    Save
                  </Button>
                  <Button variant="outline" onClick={() => setEditingId(null)}>
                    <X className="w-4 h-4 mr-2" />
                    Cancel
                  </Button>
                </div>
              </CardContent>
            ) : (
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="text-4xl">{level.badge_emoji}</div>
                      <div>
                        <h3 className="text-2xl font-bold text-[#1165b3]">
                          Level {level.level} - {level.badge_name}
                        </h3>
                        <p className="text-sm text-gray-600">{level.xp_required} XP required</p>
                      </div>
                    </div>
                    <p className="text-gray-700 mb-3">{level.celebration_message}</p>
                    <div className="flex gap-2 flex-wrap">
                      <Badge className="bg-yellow-500 text-white">
                        🪙 {level.coins_reward} coins
                      </Badge>
                      {level.xp_bonus > 0 && (
                        <Badge className="bg-blue-500 text-white">
                          ⚡ +{level.xp_bonus} XP bonus
                        </Badge>
                      )}
                      {level.item_reward_id && (
                        <Badge className="bg-purple-500 text-white">
                          🎁 Item reward
                        </Badge>
                      )}
                      {level.unlock_npc_id && (
                        <Badge className="bg-teal-500 text-white">
                          🌲 Unlock: {level.unlock_npc_id}
                        </Badge>
                      )}
                      {level.unlock_background && (
                        <Badge className="bg-indigo-500 text-white">
                          🖼️ Unlock: {level.unlock_background}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => handleEdit(level)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => handleDelete(level.id)}
                      className="text-red-600 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            )}
          </Card>
        ))}

        {/* New Level Form */}
        {editingId === "new" && (
          <Card className="border-2 border-[#ffa400]">
            <CardHeader>
              <CardTitle>Create New Level</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Level</label>
                  <Input
                    type="number"
                    value={editForm.level}
                    onChange={(e) => setEditForm({...editForm, level: parseInt(e.target.value)})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">XP Required</label>
                  <Input
                    type="number"
                    value={editForm.xp_required}
                    onChange={(e) => setEditForm({...editForm, xp_required: parseInt(e.target.value)})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Coins Reward</label>
                  <Input
                    type="number"
                    value={editForm.coins_reward}
                    onChange={(e) => setEditForm({...editForm, coins_reward: parseInt(e.target.value)})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">XP Bonus</label>
                  <Input
                    type="number"
                    value={editForm.xp_bonus || 0}
                    onChange={(e) => setEditForm({...editForm, xp_bonus: parseInt(e.target.value)})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Badge Emoji</label>
                  <Input
                    value={editForm.badge_emoji}
                    onChange={(e) => setEditForm({...editForm, badge_emoji: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Badge Name</label>
                  <Input
                    value={editForm.badge_name}
                    onChange={(e) => setEditForm({...editForm, badge_name: e.target.value})}
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium mb-1">Celebration Message</label>
                  <Input
                    value={editForm.celebration_message}
                    onChange={(e) => setEditForm({...editForm, celebration_message: e.target.value})}
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium mb-1">Item Reward (optional)</label>
                  <select
                    value={editForm.item_reward_id || ""}
                    onChange={(e) => setEditForm({...editForm, item_reward_id: e.target.value})}
                    className="w-full p-2 border rounded"
                  >
                    <option value="">No item reward</option>
                    {shopItems.map(item => (
                      <option key={item.item_id} value={item.item_id}>
                        {item.emoji} {item.item_name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium mb-1">Unlock NPC in Glow Ridge (optional)</label>
                  <Input
                    value={editForm.unlock_npc_id || ""}
                    onChange={(e) => setEditForm({...editForm, unlock_npc_id: e.target.value})}
                    placeholder="e.g., luna_owl, benny_bear"
                  />
                  <p className="text-xs text-gray-500 mt-1">Enter the NPC ID to unlock at this level</p>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium mb-1">Unlock Background/Season (optional)</label>
                  <select
                    value={editForm.unlock_background || ""}
                    onChange={(e) => setEditForm({...editForm, unlock_background: e.target.value})}
                    className="w-full p-2 border rounded"
                  >
                    <option value="">No background unlock</option>
                    <option value="spring">🌸 Spring</option>
                    <option value="summer">☀️ Summer</option>
                    <option value="fall">🍂 Fall</option>
                    <option value="winter">❄️ Winter</option>
                  </select>
                </div>
              </div>
              <div className="flex gap-3 mt-4">
                <Button onClick={handleCreateNew} className="bg-green-600">
                  <Check className="w-4 h-4 mr-2" />
                  Create Level
                </Button>
                <Button variant="outline" onClick={() => setEditingId(null)}>
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {levels.length === 0 && !editingId && (
        <Card className="p-12 text-center">
          <p className="text-gray-500 mb-4">No levels created yet</p>
          <Button onClick={handleAddNew} className="bg-[#ffa400]">
            <Plus className="w-4 h-4 mr-2" />
            Create First Level
          </Button>
        </Card>
      )}
    </div>
  );
}
