import React, { useState, useEffect } from "react";
import { RewardRules } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle2, AlertCircle, ArrowLeft, Save, Info } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ManageRewardRules() {
  const navigate = useNavigate();
  const [rules, setRules] = useState([]);
  const [status, setStatus] = useState({ type: "", message: "" });
  const [loading, setLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [editedRules, setEditedRules] = useState({});

  const DEFAULT_RULES = [
    {
      rule_id: "game_correct_answer",
      rule_name: "Correct Answer in Game",
      rule_category: "games",
      coins_reward: 10,
      xp_reward: 0,
      description: "Coins awarded per correct answer in MCQ/Matching games"
    },
    {
      rule_id: "game_lesson_complete",
      rule_name: "Complete a Lesson/Game",
      rule_category: "games",
      coins_reward: 50,
      xp_reward: 50,
      description: "Rewards for finishing a complete lesson"
    },
    {
      rule_id: "journal_entry",
      rule_name: "Complete Journal Entry",
      rule_category: "journal",
      coins_reward: 50,
      xp_reward: 50,
      description: "Rewards for completing daily journal"
    },
    {
      rule_id: "care_loop_emotion_guess",
      rule_name: "Correct Emotion Guess",
      rule_category: "care_loop",
      coins_reward: 10,
      xp_reward: 10,
      description: "Rewards for correctly guessing Lumo's emotion"
    },
    {
      rule_id: "care_loop_daily_cap_xp",
      rule_name: "Daily XP Cap (Care Loop)",
      rule_category: "daily_limits",
      coins_reward: 0,
      xp_reward: 100,
      description: "Maximum XP from care loop per day"
    },
    {
      rule_id: "care_loop_daily_cap_coins",
      rule_name: "Daily Coins Cap (Care Loop)",
      rule_category: "daily_limits",
      coins_reward: 30,
      xp_reward: 0,
      description: "Maximum coins from care loop per day"
    },
    {
      rule_id: "bedroom_nap",
      rule_name: "Take a Nap",
      rule_category: "special",
      coins_reward: 20,
      xp_reward: 20,
      description: "Rewards for taking a nap in bedroom"
    },
    {
      rule_id: "npc_conversation",
      rule_name: "NPC Conversation Complete",
      rule_category: "npc_interactions",
      coins_reward: 0,
      xp_reward: 30,
      description: "Rewards for completing Glow Ridge conversation"
    },
    {
      rule_id: "npc_lesson",
      rule_name: "NPC Lesson Complete",
      rule_category: "npc_interactions",
      coins_reward: 0,
      xp_reward: 30,
      description: "Rewards for completing Glow Ridge lesson"
    },
    {
      rule_id: "npc_daily_cap",
      rule_name: "Daily XP Cap (Glow Ridge)",
      rule_category: "daily_limits",
      coins_reward: 0,
      xp_reward: 300,
      description: "Maximum XP from Glow Ridge per day (10 interactions)"
    },
    {
      rule_id: "dopamine_activity_complete",
      rule_name: "Dopamine Activity Complete",
      rule_category: "special",
      coins_reward: 6,
      xp_reward: 0,
      description: "Coins for completing dopamine boost activity"
    },
    {
      rule_id: "dopamine_reassess",
      rule_name: "Dopamine Reassessment",
      rule_category: "special",
      coins_reward: 0,
      xp_reward: 30,
      description: "XP for completing dopamine check-in reassessment"
    },
    {
      rule_id: "mindful_munchies_timer",
      rule_name: "Mindful Munchies Timer",
      rule_category: "special",
      coins_reward: 0,
      xp_reward: 15,
      description: "XP per minute of mindful eating (max 75 XP)"
    },
    {
      rule_id: "mindful_munchies_journal",
      rule_name: "Mindful Munchies Journal",
      rule_category: "special",
      coins_reward: 10,
      xp_reward: 50,
      description: "Rewards for completing meal journal"
    },
    {
      rule_id: "recipe_save",
      rule_name: "Save a Recipe",
      rule_category: "special",
      coins_reward: 20,
      xp_reward: 0,
      description: "Coins for saving a recipe in Mindful Kitchen"
    }
  ];

  useEffect(() => {
    loadRules();
  }, []);

  const loadRules = async () => {
    try {
      setLoading(true);
      const allRules = await RewardRules.list();
      
      // If no rules exist, create defaults
      if (allRules.length === 0) {
        const createdRules = [];
        for (const defaultRule of DEFAULT_RULES) {
          const created = await RewardRules.create(defaultRule);
          createdRules.push(created);
        }
        setRules(createdRules);
      } else {
        setRules(allRules);
      }
    } catch (error) {
      console.error("Error loading rules:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (ruleId, field, value) => {
    setEditedRules(prev => ({
      ...prev,
      [ruleId]: {
        ...prev[ruleId],
        [field]: value
      }
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    setStatus({ type: "", message: "" });

    try {
      let successCount = 0;
      const errors = [];

      for (const [ruleId, changes] of Object.entries(editedRules)) {
        try {
          const rule = rules.find(r => r.rule_id === ruleId);
          if (!rule) continue;

          const updates = {};
          if (changes.coins_reward !== undefined) {
            const coins = parseInt(changes.coins_reward);
            if (isNaN(coins) || coins < 0) {
              errors.push(`Invalid coins for ${rule.rule_name}`);
              continue;
            }
            updates.coins_reward = coins;
          }
          if (changes.xp_reward !== undefined) {
            const xp = parseInt(changes.xp_reward);
            if (isNaN(xp) || xp < 0) {
              errors.push(`Invalid XP for ${rule.rule_name}`);
              continue;
            }
            updates.xp_reward = xp;
          }

          if (Object.keys(updates).length > 0) {
            await RewardRules.update(rule.id, updates);
            successCount++;
          }
        } catch (err) {
          errors.push(`Error updating ${ruleId}: ${err.message}`);
        }
      }

      await loadRules();
      setEditedRules({});
      
      if (successCount > 0) {
        setStatus({ 
          type: "success", 
          message: `✅ Updated ${successCount} rule(s)! ${errors.length > 0 ? `${errors.length} failed.` : ''}` 
        });
      }
      
      if (errors.length > 0 && successCount === 0) {
        setStatus({ type: "error", message: `Failed: ${errors[0]}` });
      }
    } catch (error) {
      setStatus({ type: "error", message: `Save failed: ${error.message}` });
    } finally {
      setIsSaving(false);
    }
  };

  const hasChanges = Object.keys(editedRules).length > 0;

  const groupedRules = rules.reduce((acc, rule) => {
    if (!acc[rule.rule_category]) {
      acc[rule.rule_category] = [];
    }
    acc[rule.rule_category].push(rule);
    return acc;
  }, {});

  const categoryNames = {
    games: "🎮 Game Rewards",
    journal: "📖 Journal Rewards",
    care_loop: "❤️ Care Loop Rewards",
    npc_interactions: "🐾 Glow Ridge Rewards",
    special: "✨ Special Activities",
    daily_limits: "🚦 Daily Limits"
  };

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("ManageLessons"))}
          className="rounded-full"
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold text-[#1165b3]">⚙️ Reward Rules Configuration</h1>
          <p className="text-gray-600">Manage coins and XP rewards across the entire app</p>
        </div>
        {hasChanges && (
          <Button
            onClick={handleSave}
            disabled={isSaving}
            className="bg-gradient-to-r from-[#66bfad] to-[#1165b3] text-white"
          >
            <Save className="w-4 h-4 mr-2" />
            {isSaving ? "Saving..." : "Save Changes"}
          </Button>
        )}
      </div>

      {status.message && (
        <Alert className={`mb-6 ${
          status.type === "success" ? "bg-green-50 border-green-200" :
          "bg-red-50 border-red-200"
        }`}>
          {status.type === "success" ? <CheckCircle2 className="h-4 w-4 text-green-600" /> : <AlertCircle className="h-4 w-4 text-red-600" />}
          <AlertDescription className={
            status.type === "success" ? "text-green-800" : "text-red-800"
          }>
            {status.message}
          </AlertDescription>
        </Alert>
      )}

      <Alert className="mb-6 bg-blue-50 border-blue-200">
        <Info className="h-4 w-4 text-blue-600" />
        <AlertDescription className="text-blue-800">
          <strong>Note:</strong> Changes here affect ALL users immediately. These are the base reward values used throughout the app.
        </AlertDescription>
      </Alert>

      <div className="space-y-6">
        {Object.entries(groupedRules).map(([category, categoryRules]) => (
          <Card key={category} className="border-2 border-[#66bfad]/30">
            <CardHeader>
              <CardTitle className="text-xl text-[#1165b3]">
                {categoryNames[category] || category}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {categoryRules.map((rule) => {
                  const currentCoins = editedRules[rule.rule_id]?.coins_reward !== undefined 
                    ? editedRules[rule.rule_id].coins_reward 
                    : rule.coins_reward;
                  const currentXP = editedRules[rule.rule_id]?.xp_reward !== undefined 
                    ? editedRules[rule.rule_id].xp_reward 
                    : rule.xp_reward;

                  return (
                    <div key={rule.rule_id} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-900">{rule.rule_name}</h4>
                        <p className="text-sm text-gray-600">{rule.description}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-600">🪙 Coins:</span>
                          <Input
                            type="number"
                            min="0"
                            value={currentCoins}
                            onChange={(e) => handleEdit(rule.rule_id, 'coins_reward', e.target.value)}
                            className="w-20 text-center"
                          />
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-600">⚡ XP:</span>
                          <Input
                            type="number"
                            min="0"
                            value={currentXP}
                            onChange={(e) => handleEdit(rule.rule_id, 'xp_reward', e.target.value)}
                            className="w-20 text-center"
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {hasChanges && (
        <div className="fixed bottom-8 right-8">
          <Button
            onClick={handleSave}
            disabled={isSaving}
            size="lg"
            className="bg-gradient-to-r from-[#66bfad] to-[#1165b3] text-white shadow-2xl"
          >
            <Save className="w-5 h-5 mr-2" />
            {isSaving ? "Saving..." : `Save ${Object.keys(editedRules).length} Change(s)`}
          </Button>
        </div>
      )}
    </div>
  );
}