import React, { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import LessonIntro from "../components/games/LessonIntro";
import BubbleGameSession from "../components/games/BubbleGameSession";
import MatchingBubbleGame from "../components/games/MatchingBubbleGame";
import TakeawaysScreen from "../components/games/TakeawaysScreen";
import RewardsScreen from "../components/games/RewardsScreen";
import ReadOnlyLesson from "../components/games/ReadOnlyLesson";

export default function BubblePopGame() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const lessonId = searchParams.get("lessonId");
  const isReviewMode = searchParams.get("review") === "true";

  const [lesson, setLesson] = useState(null);
  const [currentScreen, setCurrentScreen] = useState("loading");
  const [results, setResults] = useState(null);
  const [error, setError] = useState(null);
  const [user, setUser] = useState(null);
  const [lumoState, setLumoState] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [completionData, setCompletionData] = useState(null);

  useEffect(() => {
    if (!lessonId) {
      console.warn("No lessonId provided, navigating to BubblePopGames.");
      navigate(createPageUrl("BubblePopGames"));
      return;
    }
    loadData();
  }, [lessonId, navigate]);

  const loadData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const currentUser = await base44.auth.me();
      if (!currentUser) {
        base44.auth.redirectToLogin();
        return;
      }
      setUser(currentUser);

      const lessons = await base44.entities.GameLesson.filter({ id: lessonId });
      if (lessons.length === 0) {
        throw new Error("Lesson not found.");
      }

      const lessonData = lessons[0];

      if (!lessonData || !lessonData.questions || lessonData.questions.length === 0) {
        throw new Error("Cannot play lesson: No questions found.");
      }

      // Check if this quest+number has been completed
      const completions = await base44.entities.LessonCompletion.filter({
        user_email: currentUser.email,
        quest_id: lessonData.quest,
        lesson_number: lessonData.number
      });

      if (completions.length > 0 && !isReviewMode) {
        setLesson(lessonData);
        setCompletionData(completions[0]);
        setCurrentScreen("read_only");
        setIsLoading(false);
        return;
      }

      setLesson(lessonData);

      const states = await base44.entities.LumoState.filter({ user_email: currentUser.email });
      if (states.length > 0) {
        setLumoState(states[0]);
      }

      setCurrentScreen("intro");
    } catch (err) {
      console.error("Error loading lesson data:", err);
      alert(err.message || "Failed to load lesson data.");
      navigate(createPageUrl("BubblePopGames"));
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleComplete = async (sessionResults) => {
    if (isReviewMode) {
      navigate(createPageUrl("BubblePopGames"));
      return;
    }

    try {
      let coinsEarned = 0;
      let xpEarned = 0;

      if (!user || !lesson) {
        throw new Error("User or lesson data missing for completion processing.");
      }

      const completions = await base44.entities.LessonCompletion.filter({
        user_email: user.email,
        quest_id: lesson.quest,
        lesson_number: lesson.number
      });

      if (completions.length === 0) {
        coinsEarned = lesson.coins_reward || 0;
        xpEarned = lesson.xp_reward || 0;

        await base44.entities.LessonCompletion.create({
          user_email: user.email,
          lesson_id: lesson.id,
          quest_id: lesson.quest,
          lesson_number: lesson.number,
          score: sessionResults.correctAnswers,
          total_questions: sessionResults.totalQuestions,
          coins_earned: coinsEarned,
          xp_earned: xpEarned,
          completed_date: new Date().toISOString()
        });

        if (lumoState) {
          await base44.entities.LumoState.update(lumoState.id, {
            total_coins: lumoState.total_coins + coinsEarned,
            total_xp: lumoState.total_xp + xpEarned
          });
          setLumoState(prev => ({
              ...prev,
              total_coins: (prev?.total_coins || 0) + coinsEarned,
              total_xp: (prev?.total_xp || 0) + xpEarned
          }));
        }
      }

      setResults({ ...sessionResults, coinsEarned, xpEarned });

      if (lesson?.keyTakeaways && lesson.keyTakeaways.trim()) {
        setCurrentScreen("takeaways");
      } else {
        setCurrentScreen("rewards");
      }
    } catch (err) {
      console.error("Error completing lesson or saving progress:", err);
      setError("Error saving progress: " + err.message);
      setResults({ ...sessionResults, coinsEarned: 0, xpEarned: 0 });
      setCurrentScreen("rewards");
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-[#e0f8f5] to-cyan-100">
        <div className="text-center">
          <div className="text-6xl mb-4 animate-bounce">🫧</div>
          <p className="text-[#00d1ff] font-semibold">Loading...</p>
        </div>
      </div>
    );
  }

  if (error && currentScreen !== "rewards") {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-[#e0f8f5] to-cyan-100">
        <div className="text-center">
          <p className="text-red-600 font-semibold">{error}</p>
          <button
            onClick={() => navigate(createPageUrl("BubblePopGames"))}
            className="mt-4 px-6 py-2 bg-[#00d1ff] text-white rounded-lg"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  if (!lesson || !user) {
      console.error("Critical: Lesson or user data is missing after loading phase, navigating back.");
      navigate(createPageUrl("BubblePopGames"));
      return null;
  }

  if (currentScreen === "read_only") {
    return (
      <ReadOnlyLesson
        lesson={lesson}
        completionData={completionData}
        onExit={() => navigate(createPageUrl("BubblePopGames"))}
      />
    );
  }

  if (currentScreen === "intro") {
    return (
      <LessonIntro
        lesson={lesson}
        isReviewMode={isReviewMode}
        onStart={() => setCurrentScreen("game")}
        onExit={() => navigate(createPageUrl("BubblePopGames"))}
      />
    );
  }

  if (currentScreen === "game") {
    // ✅ Check if it's a matching game
    const isMatchingGame = lesson.type === "match";

    if (isMatchingGame) {
      // Use MatchingBubbleGame for matching games
      return (
        <MatchingBubbleGame
          lesson={lesson}
          onComplete={handleComplete}
          onExit={() => navigate(createPageUrl("BubblePopGames"))}
        />
      );
    }

    // Use BubbleGameSession for MCQ games
    return (
      <BubbleGameSession
        lesson={lesson}
        isReviewMode={isReviewMode}
        onComplete={handleComplete}
        onExit={() => navigate(createPageUrl("BubblePopGames"))}
      />
    );
  }

  if (currentScreen === "takeaways") {
    return (
      <TakeawaysScreen
        keyTakeaways={lesson.keyTakeaways}
        onContinue={() => setCurrentScreen("rewards")}
      />
    );
  }

  if (currentScreen === "rewards") {
    return (
      <RewardsScreen
        results={results}
        lesson={lesson}
        isReviewMode={isReviewMode}
        error={error}
        onContinue={() => navigate(createPageUrl("BubblePopGames"))}
      />
    );
  }

  return null;
}