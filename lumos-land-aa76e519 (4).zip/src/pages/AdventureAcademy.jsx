
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card"; // Card, CardContent still used for "No Quests Available"
import { Button } from "@/components/ui/button";
import { ArrowLeft, CheckCircle, Play, ChevronDown, ChevronUp } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import StatsDisplay from "../components/lumo/StatsDisplay";
import FloatingBubbles from "../components/ui/FloatingBubbles";
import { Badge } from "@/components/ui/badge"; // New import for Badge component

export default function AdventureAcademy() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [lumoState, setLumoState] = useState(null);
  const [lessons, setLessons] = useState([]); // Stores ALL active lessons, including different game_style versions
  const [lessonsByQuest, setLessonsByQuest] = useState({}); // Stores unique lessons (one per quest+number) for display
  const [expandedQuests, setExpandedQuests] = useState({});
  const [completedLessons, setCompletedLessons] = useState([]); // Renamed from 'completions'
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setIsLoading(true);
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      // Load Lumo state
      const [state] = await base44.entities.LumoState.filter({
        user_email: currentUser.email
      });
      setLumoState(state);

      // Load ALL active lessons (including all game_style versions)
      const allActiveLessons = await base44.entities.GameLesson.filter({
        is_active: true
      });
      setLessons(allActiveLessons); // Store all lessons here

      console.log('📚 Loaded total active lessons:', allActiveLessons.length);

      // Group lessons by quest, ensuring only one unique lesson (by quest_id and number) is shown for display purposes.
      // We'll pick the first one encountered for display in the UI.
      const groupedForDisplay = {};
      const uniqueLessonIdentifiers = new Set(); // Tracks 'quest_id_lesson_number'

      allActiveLessons.forEach(lesson => {
        const identifier = `${lesson.quest}_${lesson.number}`;
        if (!uniqueLessonIdentifiers.has(identifier)) {
          if (!groupedForDisplay[lesson.quest]) {
            groupedForDisplay[lesson.quest] = [];
          }
          // Add this lesson as the representative for display
          groupedForDisplay[lesson.quest].push(lesson);
          uniqueLessonIdentifiers.add(identifier);
        }
      });

      // Sort lessons within each quest by number for display
      Object.keys(groupedForDisplay).forEach(questId => {
        groupedForDisplay[questId].sort((a, b) => (a.number || 0) - (b.number || 0));
      });

      setLessonsByQuest(groupedForDisplay); // This will be used for rendering the list of quests and lessons

      // Load completions
      const userCompletions = await base44.entities.LessonCompletion.filter({
        user_email: currentUser.email
      });
      setCompletedLessons(userCompletions);

    } catch (error) {
      console.error('Error loading Adventure Academy:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getLessonCompletion = (lesson) => {
    return completedLessons.find(c =>
      c.quest_id === lesson.quest && c.lesson_number === lesson.number
    );
  };

  const isLessonCompleted = (lesson) => {
    return completedLessons.some(
      (completed) =>
        completed.quest_id === lesson.quest &&
        completed.lesson_number === lesson.number
    );
  };

  const handleStartLesson = async (lesson) => {
    try {
      // ✅ NEW: Find ALL game_style versions of this lesson from the 'lessons' state
      const allVersions = lessons.filter(l =>
        l.quest === lesson.quest &&
        l.number === lesson.number &&
        l.is_active !== false
      );

      console.log(`🎲 Found ${allVersions.length} versions of ${lesson.quest} #${lesson.number}:`,
        allVersions.map(v => v.game_style)
      );

      if (allVersions.length === 0) {
        console.error('❌ No active versions found for this lesson');
        return;
      }

      // ✅ NEW: Randomly select one of the available versions
      const randomIndex = Math.floor(Math.random() * allVersions.length);
      const selectedLesson = allVersions[randomIndex];

      console.log(`✅ Randomly selected: ${selectedLesson.game_style} (ID: ${selectedLesson.id})`);

      // Navigate to the appropriate game page based on game_style
      if (selectedLesson.game_style === 'bubble_pop') {
        navigate(createPageUrl("BubblePopGame") + `?id=${selectedLesson.id}`);
      } else if (selectedLesson.game_style === 'pin_mountain') {
        navigate(createPageUrl("PinMountainGame") + `?id=${selectedLesson.id}`);
      } else if (selectedLesson.game_style === 'glass_bridge') {
        navigate(createPageUrl("GlassBridgeGame") + `?id=${selectedLesson.id}`);
      } else {
        // Fallback for unknown game styles, or a default game handler
        console.warn(`⚠️ Unknown game_style: ${selectedLesson.game_style}. Falling back to generic game container.`);
        // As a fallback, you might redirect to a generic game page if one exists
        // For now, if none match, we do nothing or navigate back
        // Or if the component `LessonGameContainer` should be re-introduced for a generic lesson without specific game_style.
        // For this implementation, we assume game_style is always one of the three.
      }
    } catch (error) {
      console.error('Error starting lesson:', error);
    }
  };

  const toggleQuest = (questId) => {
    setExpandedQuests((prev) => ({
      ...prev,
      [questId]: !prev[questId],
    }));
  };

  // If playing a lesson, show the game container (This logic is removed as we now navigate to specific game pages)
  // If reviewing a completed lesson, show read-only view (This logic is removed as we now navigate to specific game pages or a modal)

  // Show quest selection
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#e0f8f5] to-[#d4f1f4] relative overflow-hidden">
      {/* ✅ Using saved FloatingBubbles component - but commented out for now */}
      {/* <FloatingBubbles count={40} /> */}

      <div className="max-w-7xl mx-auto px-4 py-8 relative z-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="icon"
              onClick={() => navigate(createPageUrl("Home"))}
              className="rounded-full"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-[#1165b3]">
                Adventure Academy
              </h1>
              <p className="text-gray-600">Choose your quest and start learning!</p>
            </div>
          </div>
          {lumoState && (
            <StatsDisplay coins={lumoState.total_coins} xp={lumoState.total_xp} />
          )}
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="text-6xl mb-4 animate-bounce">🎓</div>
              <p className="text-[#1165b3] font-semibold">Loading quests...</p>
            </div>
          </div>
        ) : (
          <div className="space-y-8">
            {Object.keys(lessonsByQuest).length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <div className="text-6xl mb-4">📚</div>
                  <h3 className="text-2xl font-bold text-gray-700 mb-2">
                    No Quests Available
                  </h3>
                  <p className="text-gray-600">
                    Check back soon for new learning adventures!
                  </p>
                </CardContent>
              </Card>
            ) : (
              Object.entries(lessonsByQuest).map(([questId, questLessons]) => {
                // `questLessons` here is already a list of unique display lessons (one per number)
                // from the `loadData` function's `groupedForDisplay`.
                // No need for `lessonsByNumber` re-grouping here from the original outline code,
                // as `questLessons` itself represents the unique lessons.
                const uniqueLessons = questLessons; // Renaming for clarity as per outline's logic.

                const incompleteLessons = uniqueLessons.filter(l => !isLessonCompleted(l));
                const completedLessonsForDisplay = uniqueLessons.filter(l => isLessonCompleted(l)); // Renamed to avoid collision with state
                const isExpanded = expandedQuests[questId];

                // Count unique lessons (not counting game_style versions)
                const questProgress = {
                  completed: completedLessonsForDisplay.length,
                  total: uniqueLessons.length
                };

                return (
                  <motion.div
                    key={questId}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl border-2 border-[#66bfad]/30 overflow-hidden"
                  >
                    {/* Quest Header */}
                    <div
                      className="bg-gradient-to-r from-[#66bfad]/20 to-[#1165b3]/20 p-6 cursor-pointer hover:from-[#66bfad]/30 hover:to-[#1165b3]/30 transition-all"
                      onClick={() => toggleQuest(questId)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <h2 className="text-2xl font-bold text-[#1165b3] mb-2">
                            {questId}
                          </h2>
                          <div className="flex items-center gap-4">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-semibold text-gray-600">
                                Progress:
                              </span>
                              <span className="text-sm font-bold text-[#66bfad]">
                                {questProgress.completed} / {questProgress.total}
                              </span>
                            </div>
                            <div className="flex-1 max-w-xs">
                              <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
                                <motion.div
                                  initial={{ width: 0 }}
                                  animate={{
                                    width: `${(questProgress.completed / questProgress.total) * 100}%`,
                                  }}
                                  className="h-full bg-gradient-to-r from-[#66bfad] to-[#1165b3]"
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-[#1165b3]"
                        >
                          {isExpanded ? (
                            <ChevronUp className="w-6 h-6" />
                          ) : (
                            <ChevronDown className="w-6 h-6" />
                          )}
                        </Button>
                      </div>
                    </div>

                    {/* Lessons List */}
                    <AnimatePresence>
                      {isExpanded && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.3 }}
                          className="overflow-hidden"
                        >
                          <div className="p-6 space-y-4">
                            {incompleteLessons.map((lesson) => {
                              // ✅ Count how many game_style versions exist for this specific lesson (quest_id + number)
                              const versionCount = lessons.filter(l => // Use the 'lessons' state that holds ALL versions
                                l.quest === lesson.quest && l.number === lesson.number
                              ).length;

                              return (
                                <motion.div
                                  key={`${lesson.quest}_${lesson.number}`}
                                  whileHover={{ scale: 1.02 }}
                                  className="bg-gradient-to-r from-[#e0f8f5] to-white p-4 rounded-2xl border-2 border-[#66bfad]/30 hover:border-[#66bfad] transition-all cursor-pointer"
                                  onClick={() => handleStartLesson(lesson)}
                                >
                                  <div className="flex items-center justify-between">
                                    <div className="flex-1">
                                      <div className="flex items-center gap-3 mb-2">
                                        {lesson.is_assessment ? (
                                          <span className="text-3xl">📋</span>
                                        ) : (
                                          <span className="text-3xl">🎮</span>
                                        )}
                                        <div>
                                          <h3 className="text-lg font-bold text-[#1165b3]">
                                            #{lesson.number}: {lesson.name}
                                          </h3>
                                          {lesson.description && (
                                            <p className="text-sm text-gray-600">
                                              {lesson.description}
                                            </p>
                                          )}
                                        </div>
                                      </div>
                                      <div className="flex items-center gap-3 flex-wrap">
                                        <Badge className="bg-[#ffa400] text-white">
                                          {lesson.xp_reward || 50} XP
                                        </Badge>
                                        <Badge className="bg-[#66bfad] text-white">
                                          {lesson.coins_reward || 50} 🪙
                                        </Badge>
                                        {versionCount > 1 && (
                                          <Badge variant="outline" className="border-[#1165b3] text-[#1165b3]">
                                            🎲 {versionCount} game styles
                                          </Badge>
                                        )}
                                        {lesson.is_assessment && (
                                          <Badge variant="outline" className="border-purple-500 text-purple-600">
                                            Assessment
                                          </Badge>
                                        )}
                                      </div>
                                    </div>
                                    <Button className="bg-gradient-to-r from-[#66bfad] to-[#1165b3] text-white">
                                      Start
                                      <Play className="w-4 h-4 ml-2" />
                                    </Button>
                                  </div>
                                </motion.div>
                              );
                            })}

                            {/* Completed Lessons */}
                            {completedLessonsForDisplay.length > 0 && (
                              <details className="mt-6">
                                <summary className="cursor-pointer text-[#66bfad] font-bold hover:text-[#1165b3] transition-colors">
                                  ✅ Completed Lessons ({completedLessonsForDisplay.length})
                                </summary>
                                <div className="mt-4 space-y-3">
                                  {completedLessonsForDisplay.map((lesson) => {
                                    const completion = getLessonCompletion(lesson); // Still need this to display score
                                    const scorePercentage = completion && completion.total_questions > 0
                                      ? Math.round((completion.score / completion.total_questions) * 100)
                                      : 0;

                                    return (
                                      <div
                                        key={`${lesson.quest}_${lesson.number}_completed`}
                                        className="bg-green-50 p-3 rounded-xl border border-green-200"
                                      >
                                        <div className="flex items-center justify-between">
                                          <div className="flex items-center gap-2">
                                            <CheckCircle className="w-5 h-5 text-green-600" />
                                            <span className="font-semibold text-gray-700">
                                              #{lesson.number}: {lesson.name}
                                            </span>
                                          </div>
                                          {completion && (
                                            <span className="text-sm font-bold text-green-600">
                                              {completion.score}/{completion.total_questions} ({scorePercentage}%)
                                            </span>
                                          )}
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              </details>
                            )}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                );
              })
            )}
          </div>
        )}
      </div>
    </div>
  );
}
