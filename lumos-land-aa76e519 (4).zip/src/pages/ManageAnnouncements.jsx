
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Plus, Trash2, Edit } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl, showLumoAlert, showLumoConfirm } from "@/components/utils";

export default function ManageAnnouncements() {
  const navigate = useNavigate();
  const [announcements, setAnnouncements] = useState([]);
  const [editingAnnouncement, setEditingAnnouncement] = useState(null);
  const [formData, setFormData] = useState({
    announcement_id: "",
    title: "",
    message: "",
    announcement_type: "info",
    icon: "📢",
    start_date: "",
    end_date: "",
    is_active: true
  });

  useEffect(() => {
    loadAnnouncements();
  }, []);

  const loadAnnouncements = async () => {
    try {
      const all = await base44.entities.Announcement.list();
      setAnnouncements(all);
    } catch (error) {
      console.error("Error loading announcements:", error);
      showLumoAlert("Oops! Could not load announcements 😟", error.message, "error");
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const data = {
        ...formData,
        start_date: formData.start_date || new Date().toISOString(),
        end_date: formData.end_date || null
      };

      if (editingAnnouncement) {
        await base44.entities.Announcement.update(editingAnnouncement.id, data);
        showLumoAlert("Announcement Updated! ✨", "Your announcement has been updated!", "success");
      } else {
        await base44.entities.Announcement.create(data);
        showLumoAlert("Announcement Created! 📢", "Your announcement is now live!", "success");
      }
      
      resetForm();
      await loadAnnouncements();
    } catch (error) {
      console.error("Error saving announcement:", error);
      showLumoAlert("Oops! Let's try again 🔄", error.message, "error");
    }
  };

  const handleEdit = (announcement) => {
    setEditingAnnouncement(announcement);
    setFormData({
      announcement_id: announcement.announcement_id,
      title: announcement.title,
      message: announcement.message,
      announcement_type: announcement.announcement_type,
      icon: announcement.icon || "📢",
      start_date: announcement.start_date ? announcement.start_date.split('T')[0] : "",
      end_date: announcement.end_date ? announcement.end_date.split('T')[0] : "",
      is_active: announcement.is_active !== false
    });
  };

  const handleDelete = async (id) => {
    showLumoConfirm(
      "Remove this announcement?",
      "This announcement will be permanently deleted. This action cannot be undone.",
      async () => {
        try {
          await base44.entities.Announcement.delete(id);
          showLumoAlert("Announcement Removed! 🗑️", "The announcement has been deleted.", "success");
          await loadAnnouncements();
        } catch (error) {
          console.error("Error deleting announcement:", error);
          showLumoAlert("Oops! Something went wrong 🔄", error.message, "error");
        }
      }
    );
  };

  const resetForm = () => {
    setEditingAnnouncement(null);
    setFormData({
      announcement_id: "",
      title: "",
      message: "",
      announcement_type: "info",
      icon: "📢",
      start_date: "",
      end_date: "",
      is_active: true
    });
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdminPanel"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1165b3]">📢 Manage Announcements</h1>
          <p className="text-gray-600">Create special announcements for users</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Form */}
        <Card>
          <CardHeader>
            <CardTitle>{editingAnnouncement ? "Edit Announcement" : "New Announcement"}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="announcement_id">Announcement ID (unique)</Label>
                <Input
                  id="announcement_id"
                  value={formData.announcement_id}
                  onChange={(e) => setFormData({...formData, announcement_id: e.target.value})}
                  placeholder="e.g., winter_event_2025"
                  required
                  disabled={!!editingAnnouncement}
                />
              </div>

              <div>
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({...formData, title: e.target.value})}
                  placeholder="e.g., Winter Event Starting Soon!"
                  required
                />
              </div>

              <div>
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                  placeholder="Describe the announcement..."
                  rows={3}
                  required
                />
              </div>

              <div>
                <Label htmlFor="announcement_type">Type</Label>
                <Select
                  value={formData.announcement_type}
                  onValueChange={(value) => setFormData({...formData, announcement_type: value})}
                >
                  <SelectTrigger id="announcement_type">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="limited_item">Limited Item</SelectItem>
                    <SelectItem value="double_xp">Double XP</SelectItem>
                    <SelectItem value="event">Event</SelectItem>
                    <SelectItem value="update">Update</SelectItem>
                    <SelectItem value="info">Info</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="icon">Icon (emoji)</Label>
                <Input
                  id="icon"
                  value={formData.icon}
                  onChange={(e) => setFormData({...formData, icon: e.target.value})}
                  placeholder="e.g., 🎉"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="start_date">Start Date</Label>
                  <Input
                    id="start_date"
                    type="date"
                    value={formData.start_date}
                    onChange={(e) => setFormData({...formData, start_date: e.target.value})}
                  />
                  <p className="text-xs text-gray-500 mt-1">Leave empty for immediate start</p>
                </div>

                <div>
                  <Label htmlFor="end_date">End Date</Label>
                  <Input
                    id="end_date"
                    type="date"
                    value={formData.end_date}
                    onChange={(e) => setFormData({...formData, end_date: e.target.value})}
                  />
                  <p className="text-xs text-gray-500 mt-1">Leave empty for no end</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.is_active}
                  onChange={(e) => setFormData({...formData, is_active: e.target.checked})}
                  id="is_active"
                  className="h-4 w-4 text-[#1165b3] focus:ring-[#1165b3] border-gray-300 rounded"
                />
                <Label htmlFor="is_active">Active</Label>
              </div>

              <div className="flex gap-3">
                <Button type="submit" className="flex-1 bg-[#1165b3] hover:bg-[#0e5491]">
                  {editingAnnouncement ? "Update" : "Create"} Announcement
                </Button>
                {editingAnnouncement && (
                  <Button type="button" variant="outline" onClick={resetForm}>
                    Cancel
                  </Button>
                )}
              </div>
            </form>
          </CardContent>
        </Card>

        {/* List */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>All Announcements ({announcements.length})</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {announcements.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No announcements yet.</p>
              ) : (
                announcements.map((announcement) => (
                  <div
                    key={announcement.id}
                    className="p-4 border-2 border-[#66bfad]/30 rounded-xl bg-gradient-to-r from-[#e0f8f5] to-white"
                  >
                    <div className="flex items-start gap-3">
                      <div className="text-3xl">{announcement.icon}</div>
                      <div className="flex-1">
                        <h4 className="font-bold text-[#1165b3]">{announcement.title}</h4>
                        <p className="text-sm text-gray-700 mt-1">{announcement.message}</p>
                        <div className="flex flex-wrap gap-2 mt-2 text-xs text-gray-500">
                          <span className="capitalize">{announcement.announcement_type}</span>
                          {announcement.start_date && <span>• Starts: {new Date(announcement.start_date).toLocaleDateString()}</span>}
                          {announcement.end_date && <span>• Ends: {new Date(announcement.end_date).toLocaleDateString()}</span>}
                        </div>
                        {!announcement.is_active && (
                          <span className="text-xs text-red-600 mt-1 block">Inactive</span>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => handleEdit(announcement)}
                          title="Edit Announcement"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => handleDelete(announcement.id)}
                          title="Delete Announcement"
                        >
                          <Trash2 className="w-4 h-4 text-red-600" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
