import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import MunchiesWelcome from "../components/munchies/MunchiesWelcome";
import MunchiesSpinner from "../components/munchies/MunchiesSpinner";
import MunchiesTimer from "../components/munchies/MunchiesTimer";
import MunchiesJournal from "../components/munchies/MunchiesJournal";
import MunchiesRewards from "../components/munchies/MunchiesRewards";

export default function MindfulMunchies() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState("welcome");
  const [topics, setTopics] = useState([]);
  const [selectedTopic, setSelectedTopic] = useState(null);
  const [recentTopics, setRecentTopics] = useState([]);
  const [timerMinutes, setTimerMinutes] = useState(3);
  const [timerXp, setTimerXp] = useState(0);
  const [journalXp, setJournalXp] = useState(0);
  const [journalCoins, setJournalCoins] = useState(0);

  useEffect(() => {
    loadTopics();
  }, []);

  const loadTopics = async () => {
    try {
      const response = await base44.functions.invoke('mindfulMunchies', {
        action: 'getTopics'
      });
      setTopics(response.data.topics);
    } catch (error) {
      console.error("Error loading topics:", error);
    }
  };

  const handleStart = () => {
    setCurrentStep("spinner");
  };

  const handleSpinComplete = (topic) => {
    setSelectedTopic(topic);
    setRecentTopics(prev => [...prev.slice(-2), topic.id]);
    setCurrentStep("timer");
  };

  const handleTimerComplete = async (minutes) => {
    try {
      const response = await base44.functions.invoke('mindfulMunchies', {
        action: 'completeTimer',
        minutes
      });
      setTimerXp(response.data.xp_earned);
      setCurrentStep("journal");
    } catch (error) {
      console.error("Error completing timer:", error);
    }
  };

  const handleJournalSubmit = async (journalData) => {
    try {
      const response = await base44.functions.invoke('mindfulMunchies', {
        action: 'submitJournal',
        journalData: {
          ...journalData,
          topic_spun: selectedTopic.name
        }
      });
      setJournalXp(response.data.xp_earned);
      setJournalCoins(response.data.coins_earned);
      setCurrentStep("rewards");
    } catch (error) {
      console.error("Error submitting journal:", error);
    }
  };

  const handlePlayAgain = () => {
    setSelectedTopic(null);
    setTimerXp(0);
    setJournalXp(0);
    setJournalCoins(0);
    setCurrentStep("spinner");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#e0f8f5] to-[#66bfad]/20 p-4 sm:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("Hub"))}
            className="rounded-full"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-[#1165b3]" style={{ fontFamily: 'Poppins' }}>
              Lumo's Mindful Munchies Spinner
            </h1>
            <p className="text-gray-600">Slow down and savor your meals together!</p>
          </div>
        </div>

        {currentStep === "welcome" && (
          <MunchiesWelcome onStart={handleStart} />
        )}

        {currentStep === "spinner" && (
          <MunchiesSpinner
            topics={topics}
            recentTopics={recentTopics}
            onSpinComplete={handleSpinComplete}
          />
        )}

        {currentStep === "timer" && (
          <MunchiesTimer
            topic={selectedTopic}
            onComplete={handleTimerComplete}
          />
        )}

        {currentStep === "journal" && (
          <MunchiesJournal
            topic={selectedTopic}
            onSubmit={handleJournalSubmit}
          />
        )}

        {currentStep === "rewards" && (
          <MunchiesRewards
            timerXp={timerXp}
            journalXp={journalXp}
            journalCoins={journalCoins}
            onPlayAgain={handlePlayAgain}
            onGoHome={() => navigate(createPageUrl("Home"))}
          />
        )}
      </div>
    </div>
  );
}