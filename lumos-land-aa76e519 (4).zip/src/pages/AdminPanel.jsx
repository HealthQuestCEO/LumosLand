import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Package, Image, Trophy, Gift, BookOpen, HelpCircle, Book, Trash2, FileJson, AlertCircle, Bug, Download, Calendar, TestTube } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function AdminPanel() {
  const navigate = useNavigate();
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const user = await base44.auth.me();
      if (!user || user.role !== 'admin') {
        navigate(createPageUrl("Home"));
        return;
      }
    } catch (error) {
      navigate(createPageUrl("Home"));
    } finally {
      setIsCheckingAuth(false);
    }
  };

  const adminCards = [
    // HealthQuest Integration (Top Priority)
    {
      title: "🎮 Game Tester",
      description: "Test game styles with JSON - NEW!",
      icon: TestTube,
      color: "from-green-500 to-green-600",
      path: "GameTester",
      badge: "NEW"
    },
    {
      title: "🔗 HealthQuest Bridge",
      description: "Connect to HealthQuest API and sync data",
      icon: BookOpen,
      color: "from-teal-500 to-cyan-600",
      path: "HealthQuestBridge"
    },
    {
      title: "📥 Import Lessons (JSON)",
      description: "Import lessons from HealthQuest JSON",
      icon: BookOpen,
      color: "from-green-500 to-green-600",
      path: "ImportLessonsJSON"
    },
    {
      title: "💾 Export Data",
      description: "Download lessons, shop items, and all content as JSON",
      icon: Download,
      color: "from-blue-500 to-blue-600",
      path: "ExportData"
    },
    {
      title: "⏰ Scheduled Exports",
      description: "Automate daily/weekly exports to HealthQuest",
      icon: Calendar,
      color: "from-purple-500 to-purple-600",
      path: "ScheduledExports"
    },
    {
      title: "🐛 Debug Lessons",
      description: "Check which lessons have questions stored",
      icon: Bug,
      color: "from-red-500 to-pink-600",
      path: "DebugLessons"
    },
    {
      title: "📋 JSON Format Examples",
      description: "See example HealthQuest JSON formats",
      icon: FileJson,
      color: "from-blue-500 to-indigo-600",
      path: "JSONFormatExamples"
    },
    
    // Content Management
    {
      title: "🛍️ Shop Items",
      description: "Manage items in Lumo's Nook",
      icon: Package,
      color: "from-[#66bfad] to-[#1165b3]",
      path: "ManageShopItems"
    },
    {
      title: "🏆 Badges",
      description: "Create and manage achievement badges",
      icon: Trophy,
      color: "from-yellow-500 to-yellow-600",
      path: "ManageBadges"
    },
    {
      title: "🎁 Reward Rules",
      description: "Set XP and coin rewards for activities",
      icon: Gift,
      color: "from-green-500 to-green-600",
      path: "ManageRewardRules"
    },
    {
      title: "⭐ Manage XP Levels",
      description: "Set XP requirements and level rewards",
      icon: Trophy,
      color: "from-yellow-500 to-amber-600",
      path: "ManageXPLevels"
    },
    {
      title: "📢 Announcements",
      description: "Manage special announcements",
      icon: Package,
      color: "from-[#1165b3] to-[#66bfad]",
      path: "ManageAnnouncements"
    },
    {
      title: "🎡 Daily Spinner",
      description: "Manage daily spinner prizes",
      icon: Gift,
      color: "from-[#ffa400] to-[#ff8c00]",
      path: "ManageSpinner"
    },
    
    // Assets & Media
    {
      title: "🖼️ Upload Assets",
      description: "Upload images for Lumo, backgrounds, items",
      icon: Image,
      color: "from-[#ffa400] to-[#ff8c00]",
      path: "UploadAssetImages"
    },
    {
      title: "🎨 Manage Assets",
      description: "View and edit all asset mappings",
      icon: Image,
      color: "from-purple-500 to-purple-600",
      path: "ManageAssets"
    },
    {
      title: "🖼️ Batch Image Download",
      description: "Download all asset images as a ZIP file",
      icon: Download,
      color: "from-orange-500 to-yellow-600",
      path: "BatchImageDownload"
    },
    
    // User Content
    {
      title: "📚 Journal Questions",
      description: "Manage Mood & Moves reflection questions",
      icon: Book,
      color: "from-amber-500 to-amber-600",
      path: "ManageReflectionQuestions"
    },
    
    // Utilities
    {
      title: "📋 Admin Architecture",
      description: "Critical questions answered about data storage, export, and multi-user support",
      icon: AlertCircle,
      color: "from-green-500 to-green-600",
      path: "AdminPanelArchitecture"
    },
    {
      title: "🗑️ Clear Academy Data",
      description: "Wipe Adventure Academy & Glow Ridge data",
      icon: Trash2,
      color: "from-red-500 to-red-600",
      path: "ClearLessonData"
    },
    {
      title: "🌲 Import Glow Ridge",
      description: "Upload NPC conversations",
      icon: BookOpen,
      color: "from-cyan-500 to-teal-600",
      path: "ImportGlowRidgeContent"
    },
    {
      title: "📝 Create Lesson",
      description: "Build single lesson with form or JSON",
      icon: BookOpen,
      color: "from-purple-500 to-purple-600",
      path: "CreateLessonFormat"
    }
  ];

  if (isCheckingAuth) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="text-6xl mb-4 animate-bounce">🔒</div>
          <p className="text-[#1165b3] font-semibold">Checking access...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("Home"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1165b3]">Admin Panel</h1>
          <p className="text-gray-600">Manage content for Lumo's Land (Admins Only)</p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {adminCards.map((card, index) => {
          const Icon = card.icon;
          return (
            <Card
              key={index}
              className="cursor-pointer hover:shadow-xl transition-all duration-300 border-2 border-gray-200 hover:border-[#66bfad] relative"
              onClick={() => navigate(createPageUrl(card.path))}
            >
              {card.badge && (
                <div className="absolute top-2 right-2 bg-green-500 text-white text-xs px-2 py-1 rounded-full font-bold">
                  {card.badge}
                </div>
              )}
              <CardHeader>
                <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${card.color} flex items-center justify-center mb-3`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-xl">{card.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">{card.description}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}