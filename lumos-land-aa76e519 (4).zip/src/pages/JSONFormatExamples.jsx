import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Copy, Check } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useState } from "react";

export default function JSONFormatExamples() {
  const navigate = useNavigate();
  const [copiedIndex, setCopiedIndex] = useState(null);

  const copyToClipboard = (text, index) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const examples = [
    {
      title: "1️⃣ Simple MCQ Lesson",
      description: "HealthQuest format - uses type field, NOT game_format",
      json: `[
  {
    "quest": "BodyImageOdyssey",
    "number": 1,
    "name": "My Body, My Superpower",
    "description": "Learn how amazing your body is",
    "lessonText": "Your body is incredible! It helps you run, play, think, and feel.",
    "type": "mcq",
    "xp_reward": 50,
    "coins_reward": 50,
    "coins_per_correct": 10,
    "keyTakeaways": "Your body is unique and amazing",
    "questions": [
      {
        "question": "What makes your body special?",
        "options": ["It's unique", "It's strong", "It helps me", "All of the above"],
        "answer": 4
      },
      {
        "question": "How should you treat your body?",
        "options": ["With kindness", "With respect", "With care", "All of the above"],
        "answer": 4
      },
      {
        "question": "What does your body help you do?",
        "options": ["Play sports", "Think and learn", "Feel emotions", "All of the above"],
        "answer": 4
      },
      {
        "question": "Is it okay that everyone's body looks different?",
        "options": ["Yes, that's what makes us special", "No, we should all look the same", "Only sometimes", "I don't know"],
        "answer": 1
      },
      {
        "question": "What's the best way to think about your body?",
        "options": ["Focus on what it looks like", "Focus on what it can do", "Compare it to others", "Wish it was different"],
        "answer": 2
      }
    ]
  }
]`
    },
    {
      title: "2️⃣ Matching Lesson",
      description: "HealthQuest format - type: match",
      json: `[
  {
    "quest": "KindnessCrusaders",
    "number": 3,
    "name": "Feelings and Actions",
    "description": "Match feelings with kind actions",
    "lessonText": "When we understand our feelings, we can choose kind actions that help ourselves and others.",
    "type": "match",
    "xp_reward": 50,
    "coins_reward": 50,
    "keyTakeaways": "Different feelings need different responses",
    "questions": [
      {
        "question": "Match each feeling with the kind action that helps:",
        "type": "match",
        "options": [
          {
            "ans": "Feeling Sad",
            "matching_answer": {
              "answerId": "match_0",
              "group": "left"
            }
          },
          {
            "ans": "Talk to a friend or trusted adult",
            "matching_answer": {
              "answerId": "match_0",
              "group": "right"
            }
          },
          {
            "ans": "Feeling Angry",
            "matching_answer": {
              "answerId": "match_1",
              "group": "left"
            }
          },
          {
            "ans": "Take deep breaths and count to 10",
            "matching_answer": {
              "answerId": "match_1",
              "group": "right"
            }
          },
          {
            "ans": "Feeling Anxious",
            "matching_answer": {
              "answerId": "match_2",
              "group": "left"
            }
          },
          {
            "ans": "Do something calming like reading",
            "matching_answer": {
              "answerId": "match_2",
              "group": "right"
            }
          },
          {
            "ans": "Feeling Lonely",
            "matching_answer": {
              "answerId": "match_3",
              "group": "left"
            }
          },
          {
            "ans": "Reach out to connect with someone",
            "matching_answer": {
              "answerId": "match_3",
              "group": "right"
            }
          },
          {
            "ans": "Feeling Happy",
            "matching_answer": {
              "answerId": "match_4",
              "group": "left"
            }
          },
          {
            "ans": "Share your joy with others",
            "matching_answer": {
              "answerId": "match_4",
              "group": "right"
            }
          }
        ]
      }
    ]
  }
]`
    },
    {
      title: "3️⃣ Complete Quest with Assessments",
      description: "HealthQuest nested format - assessments use type: likert",
      json: `{
  "pre_assessment": {
    "quest": "BodyImageOdyssey",
    "number": 0,
    "name": "Pre-Assessment: How You Feel",
    "description": "Tell us how you feel before starting",
    "lessonText": "Before we start, we want to know how you feel about your body right now. There are no wrong answers!",
    "is_assessment": true,
    "assessment_type": "pre",
    "xp_reward": 25,
    "coins_reward": 25,
    "score_mapping": {
      "Strongly Disagree": 1,
      "Disagree": 2,
      "Neutral": 3,
      "Agree": 4,
      "Strongly Agree": 5
    },
    "max_score": 25,
    "feedback": {
      "high_score": {
        "threshold": 20,
        "message": "You have a positive relationship with your body!"
      },
      "medium_score": {
        "threshold": 12,
        "message": "You're on your way! This quest will help you build more confidence."
      },
      "low_score": {
        "threshold": 0,
        "message": "Thank you for being honest. This quest will help you develop a healthier relationship with your body."
      }
    },
    "questions": [
      {
        "question": "I feel good about my body.",
        "options": ["Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree"]
      },
      {
        "question": "I am proud of what my body can do.",
        "options": ["Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree"]
      },
      {
        "question": "I treat my body with kindness.",
        "options": ["Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree"]
      },
      {
        "question": "I feel confident in how I look.",
        "options": ["Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree"]
      },
      {
        "question": "I appreciate my body for what it is.",
        "options": ["Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree"]
      }
    ]
  },
  "lessons": [
    {
      "quest": "BodyImageOdyssey",
      "number": 1,
      "name": "My Body, My Superpower",
      "description": "Learn how amazing your body is",
      "lessonText": "Your body is incredible!",
      "type": "mcq",
      "xp_reward": 50,
      "coins_reward": 50,
      "coins_per_correct": 10,
      "questions": [
        {
          "question": "What makes your body special?",
          "options": ["It's unique", "It's strong", "It helps me", "All of the above"],
          "answer": 4
        },
        {
          "question": "How should you treat your body?",
          "options": ["With kindness", "With respect", "With care", "All of the above"],
          "answer": 4
        },
        {
          "question": "What does your body help you do?",
          "options": ["Play sports", "Think and learn", "Feel emotions", "All of the above"],
          "answer": 4
        },
        {
          "question": "Is it okay that everyone's body looks different?",
          "options": ["Yes, that's what makes us special", "No, we should all look the same", "Only sometimes", "I don't know"],
          "answer": 1
        },
        {
          "question": "What's the best way to think about your body?",
          "options": ["Focus on what it looks like", "Focus on what it can do", "Compare it to others", "Wish it was different"],
          "answer": 2
        }
      ]
    }
  ],
  "post_assessment": {
    "quest": "BodyImageOdyssey",
    "number": 101,
    "name": "Post-Assessment: How You Feel Now",
    "description": "Tell us how you feel after completing the quest",
    "lessonText": "You've completed the quest! Let's see how your feelings have changed.",
    "is_assessment": true,
    "assessment_type": "post",
    "xp_reward": 50,
    "coins_reward": 50,
    "score_mapping": {
      "Strongly Disagree": 1,
      "Disagree": 2,
      "Neutral": 3,
      "Agree": 4,
      "Strongly Agree": 5
    },
    "max_score": 25,
    "feedback": {
      "high_score": {
        "threshold": 20,
        "message": "Amazing growth! You've developed a much more positive relationship!"
      },
      "medium_score": {
        "threshold": 12,
        "message": "Great progress! You're building a healthier relationship."
      },
      "low_score": {
        "threshold": 0,
        "message": "Remember, building confidence takes time. Keep practicing!"
      }
    },
    "questions": [
      {
        "question": "I feel good about my body.",
        "options": ["Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree"]
      },
      {
        "question": "I am proud of what my body can do.",
        "options": ["Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree"]
      },
      {
        "question": "I treat my body with kindness.",
        "options": ["Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree"]
      },
      {
        "question": "I feel confident in how I look.",
        "options": ["Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree"]
      },
      {
        "question": "I appreciate my body for what it is.",
        "options": ["Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree"]
      }
    ]
  },
  "feedbackForm": {
    "quest": "BodyImageOdyssey",
    "number": 102,
    "name": "Reflection: Your Journey",
    "description": "Reflect on what you learned",
    "lessonText": "Congratulations! Let's reflect on your journey.",
    "is_assessment": true,
    "assessment_type": "reflection",
    "xp_reward": 25,
    "coins_reward": 25,
    "score_mapping": {
      "Strongly Disagree": 1,
      "Disagree": 2,
      "Neutral": 3,
      "Agree": 4,
      "Strongly Agree": 5
    },
    "max_score": 15,
    "questions": [
      {
        "question": "I learned something new about my body.",
        "options": ["Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree"]
      },
      {
        "question": "I will use what I learned in my daily life.",
        "options": ["Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree"]
      },
      {
        "question": "I enjoyed this quest.",
        "options": ["Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree"]
      }
    ]
  }
}`
    },
    {
      title: "4️⃣ How Game Styles Work",
      description: "Check the box → Lumo creates 3 versions per lesson",
      json: `// WHAT YOU PASTE (HealthQuest source format):
[
  {
    "quest": "KindnessCrusaders",
    "number": 1,
    "name": "What is Kindness?",
    "type": "mcq",
    "questions": [...]
  }
]

// WHAT LUMO CREATES (when "Create for all game styles" is checked):
// Lumo adds game_style field and creates 3 lessons:

Lesson 1: {...lesson, game_style: "bubble_pop"}
Lesson 2: {...lesson, game_style: "pin_mountain"}  
Lesson 3: {...lesson, game_style: "glass_bridge"}

Students can choose which style they prefer!`
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdminPanel"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1165b3]">📝 JSON Format Examples</h1>
          <p className="text-gray-600">HealthQuest source format (copy exactly as shown)</p>
        </div>
      </div>

      <div className="space-y-6">
        {examples.map((example, index) => (
          <Card key={index} className="border-2 border-[#66bfad]/20">
            <CardHeader>
              <CardTitle className="text-xl text-[#1165b3] flex items-center justify-between">
                <span>{example.title}</span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(example.json, index)}
                  className="gap-2"
                >
                  {copiedIndex === index ? (
                    <>
                      <Check className="w-4 h-4" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      Copy JSON
                    </>
                  )}
                </Button>
              </CardTitle>
              <p className="text-sm text-gray-600">{example.description}</p>
            </CardHeader>
            <CardContent>
              <pre className="bg-gray-50 p-4 rounded-lg overflow-x-auto text-sm border-2 border-gray-200">
                <code>{example.json}</code>
              </pre>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="mt-8 border-2 border-[#ffa400]/30 bg-gradient-to-br from-orange-50 to-white">
        <CardHeader>
          <CardTitle className="text-[#ffa400]">💡 HealthQuest Format Guide</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <p><strong>✅ HealthQuest uses "type" field:</strong></p>
          <ul className="list-disc list-inside pl-4 space-y-1">
            <li><code>"type": "mcq"</code> → Multiple choice questions</li>
            <li><code>"type": "match"</code> → Matching pairs with answerId/group</li>
            <li>Assessments use <code>"is_assessment": true</code> with <code>"assessment_type"</code></li>
          </ul>
          
          <p className="mt-4"><strong>🎮 Lumo adds "game_style" automatically:</strong></p>
          <ul className="list-disc list-inside pl-4 space-y-1">
            <li>NOT in your HealthQuest JSON</li>
            <li>Check the box to create 3 versions: bubble_pop, pin_mountain, glass_bridge</li>
            <li>Students can choose their favorite game style!</li>
          </ul>

          <p className="mt-4"><strong>📋 Lesson Numbers:</strong></p>
          <ul className="list-disc list-inside pl-4 space-y-1">
            <li>0 = pre-assessment</li>
            <li>1-100 = regular lessons</li>
            <li>101 = post-assessment</li>
            <li>102 = feedback/reflection</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}