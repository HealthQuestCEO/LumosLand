import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, Download, BookOpen, Package, Users, Image, CheckCircle2, AlertCircle, FileArchive } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ExportData() {
  const navigate = useNavigate();
  const [isExporting, setIsExporting] = useState(false);
  const [exportStatus, setExportStatus] = useState(null);

  const handleExport = async (action, filename) => {
    setIsExporting(true);
    setExportStatus(null);

    try {
      const response = await base44.functions.invoke('exportLessons', { action });
      
      // Create blob and download
      const blob = new Blob([JSON.stringify(response.data, null, 2)], { type: 'application/json' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename || `export-${Date.now()}.json`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();

      setExportStatus({ success: true, message: 'Export downloaded successfully!' });
    } catch (error) {
      console.error('Export error:', error);
      setExportStatus({ success: false, message: error.message || 'Export failed' });
    } finally {
      setIsExporting(false);
    }
  };

  const handleBatchImageDownload = async () => {
    setIsExporting(true);
    setExportStatus(null);

    try {
      const response = await base44.functions.invoke('exportLessons', { action: 'batchDownloadImages' });
      
      // Create blob and download ZIP
      const blob = new Blob([response.data], { type: 'application/zip' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `lumo-images-${Date.now()}.zip`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();

      setExportStatus({ 
        success: true, 
        message: 'All images downloaded as ZIP! Check your downloads folder.' 
      });
    } catch (error) {
      console.error('Batch download error:', error);
      setExportStatus({ 
        success: false, 
        message: error.message || 'Batch download failed' 
      });
    } finally {
      setIsExporting(false);
    }
  };

  const exportOptions = [
    {
      title: "📚 Export All Lessons",
      description: "Download all lessons from all quests (including pre/post assessments)",
      action: "exportLessons",
      filename: "lumo-lessons.json",
      icon: BookOpen,
      color: "from-blue-500 to-blue-600"
    },
    {
      title: "🛍️ Export Shop Items",
      description: "Download all items from Lumo's Nook",
      action: "exportShopItems",
      filename: "lumo-shop-items.json",
      icon: Package,
      color: "from-green-500 to-green-600"
    },
    {
      title: "🌲 Export Glow Ridge Content",
      description: "Download NPCs and conversations",
      action: "exportNPCs",
      filename: "lumo-npcs.json",
      icon: Users,
      color: "from-purple-500 to-purple-600"
    },
    {
      title: "🖼️ Export Image Manifest",
      description: "List of all images (Lumo assets, shop items, badges, backgrounds)",
      action: "exportImageManifest",
      filename: "lumo-images.json",
      icon: Image,
      color: "from-orange-500 to-orange-600"
    },
    {
      title: "💾 Export Everything",
      description: "Complete export: lessons, shop, NPCs, badges, assets, and more",
      action: "exportAll",
      filename: "lumo-complete-export.json",
      icon: Download,
      color: "from-red-500 to-red-600"
    }
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdminPanel"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1165b3]">Export Data</h1>
          <p className="text-gray-600">Download app content as JSON files</p>
        </div>
      </div>

      {/* Status Alert */}
      {exportStatus && (
        <Alert className={`mb-6 ${exportStatus.success ? 'bg-green-50 border-green-300' : 'bg-red-50 border-red-300'}`}>
          {exportStatus.success ? (
            <CheckCircle2 className="h-4 w-4 text-green-600" />
          ) : (
            <AlertCircle className="h-4 w-4 text-red-600" />
          )}
          <AlertDescription className={exportStatus.success ? 'text-green-800' : 'text-red-800'}>
            {exportStatus.message}
          </AlertDescription>
        </Alert>
      )}

      {/* Image Warning */}
      <Alert className="mb-6 bg-yellow-50 border-yellow-300">
        <AlertCircle className="h-4 w-4 text-yellow-600" />
        <AlertDescription className="text-yellow-800">
          <strong>Important:</strong> Exports contain JSON data and image URLs. 
          Use "Batch Download Images" below to automatically download all images as a ZIP file!
        </AlertDescription>
      </Alert>

      {/* FEATURED: Batch Image Download */}
      <Card className="mb-8 border-4 border-[#ffa400] shadow-xl">
        <CardHeader>
          <div className="w-16 h-16 rounded-lg bg-gradient-to-r from-[#ffa400] to-[#ff8c00] flex items-center justify-center mb-3">
            <FileArchive className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl text-[#1165b3]">🎉 Batch Download All Images (ZIP)</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-gray-700">
            <strong>One-click solution!</strong> Downloads ALL images from Lumo's Land organized by category:
          </p>
          <ul className="list-disc list-inside space-y-1 text-sm text-gray-600 ml-4">
            <li><strong>Lumo Assets</strong> - Character states (Happy, Sad, Angry, etc.) & backgrounds</li>
            <li><strong>Shop Items</strong> - All item images from The Nook</li>
            <li><strong>Badges</strong> - Achievement badge images</li>
            <li><strong>NPCs</strong> - Glow Ridge character images</li>
            <li><strong>Announcements</strong> - Special announcement icons</li>
            <li><strong>Recipes</strong> - Mindful Kitchen recipe photos</li>
          </ul>
          <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
            <p className="text-sm text-blue-800">
              💡 <strong>Tip:</strong> This creates a complete backup of all visual assets. 
              Perfect for migrating to another platform or sharing with your team!
            </p>
          </div>
          <Button
            onClick={handleBatchImageDownload}
            disabled={isExporting}
            className="w-full bg-gradient-to-r from-[#ffa400] to-[#ff8c00] text-white text-lg py-6 hover:shadow-2xl transition-all"
          >
            {isExporting ? (
              <>
                <div className="w-5 h-5 border-3 border-white border-t-transparent rounded-full animate-spin mr-2" />
                Downloading Images...
              </>
            ) : (
              <>
                <FileArchive className="w-6 h-6 mr-2" />
                Download All Images as ZIP
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Export Options */}
      <h2 className="text-2xl font-bold text-[#1165b3] mb-4">📦 Export JSON Data</h2>
      <div className="grid md:grid-cols-2 gap-6">
        {exportOptions.map((option, index) => {
          const Icon = option.icon;
          return (
            <Card key={index} className="border-2 border-gray-200 hover:border-[#66bfad] hover:shadow-xl transition-all">
              <CardHeader>
                <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${option.color} flex items-center justify-center mb-3`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-xl">{option.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600">{option.description}</p>
                <Button
                  onClick={() => handleExport(option.action, option.filename)}
                  disabled={isExporting}
                  className="w-full bg-gradient-to-r from-[#66bfad] to-[#1165b3] text-white"
                >
                  {isExporting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                      Exporting...
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4 mr-2" />
                      Download JSON
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Instructions */}
      <Card className="mt-8 border-2 border-blue-300">
        <CardHeader>
          <CardTitle className="text-blue-900">📋 What To Do With Exports</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-white p-4 rounded-lg border">
            <h4 className="font-bold mb-2">1. Store in Safe Location</h4>
            <ul className="list-disc list-inside text-sm text-gray-700 space-y-1">
              <li>Save JSON files + image ZIP to Dropbox, Google Drive, or GitHub</li>
              <li>Keep dated backups (e.g., lumo-export-2024-01-15.json)</li>
              <li>Share with HealthQuest team if needed</li>
            </ul>
          </div>

          <div className="bg-white p-4 rounded-lg border">
            <h4 className="font-bold mb-2">2. Image Backup (AUTOMATED!)</h4>
            <p className="text-sm text-green-700 mb-2">
              ✅ Use the "Batch Download All Images" button above - it's automatic!
            </p>
            <p className="text-sm text-gray-600">
              The ZIP file contains all images organized by category with a README file explaining the folder structure.
            </p>
          </div>

          <div className="bg-white p-4 rounded-lg border">
            <h4 className="font-bold mb-2">3. Import to Another System</h4>
            <ul className="list-disc list-inside text-sm text-gray-700 space-y-1">
              <li>JSON can be imported to HealthQuest via API</li>
              <li>Use "Import Lessons JSON" to re-import to Lumo's Land</li>
              <li>Share with developers for integration work</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}