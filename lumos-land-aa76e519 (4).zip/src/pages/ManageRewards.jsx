import React, { useState, useEffect } from "react";
import { ShopItem, GameLesson } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle2, AlertCircle, Upload, Download, ArrowLeft, Table, FileSpreadsheet } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ManageRewards() {
  const navigate = useNavigate();
  const [shopItems, setShopItems] = useState([]);
  const [lessons, setLessons] = useState([]);
  const [csvInput, setCsvInput] = useState("");
  const [status, setStatus] = useState({ type: "", message: "" });
  const [isImporting, setIsImporting] = useState(false);
  const [activeTab, setActiveTab] = useState("shop"); // "shop" or "lessons"
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const items = await ShopItem.list();
      const allLessons = await GameLesson.list();
      setShopItems(items);
      setLessons(allLessons);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  };

  // Export to CSV
  const handleExportShopCSV = () => {
    const headers = ["item_id", "item_name", "current_price", "item_type", "treats"];
    const rows = shopItems.map(item => [
      item.item_id,
      item.item_name,
      item.price,
      item.item_type,
      item.treats || ""
    ]);
    
    const csv = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
    downloadFile(csv, "shop_items_prices.csv", "text/csv");
    setStatus({ type: "success", message: "Shop items exported to CSV!" });
  };

  const handleExportLessonsCSV = () => {
    const headers = ["lesson_id", "lesson_name", "quest", "current_xp", "current_coins"];
    const rows = lessons.map(lesson => [
      lesson.id,
      lesson.name,
      lesson.quest,
      lesson.xp_total || 50,
      lesson.coins_total || 50
    ]);
    
    const csv = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
    downloadFile(csv, "lesson_rewards.csv", "text/csv");
    setStatus({ type: "success", message: "Lesson rewards exported to CSV!" });
  };

  const downloadFile = (content, filename, type) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Import from CSV
  const handleFileUpload = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result;
        setCsvInput(content);
        setStatus({ 
          type: "success", 
          message: `File "${file.name}" loaded! Review and click "Import Updates" to apply.` 
        });
      } catch (err) {
        setStatus({ type: "error", message: `Error reading file: ${err.message}` });
      }
    };
    reader.readAsText(file);
  };

  const parseCSV = (csv) => {
    const lines = csv.trim().split("\n");
    const headers = lines[0].split(",").map(h => h.trim());
    
    return lines.slice(1).map(line => {
      const values = line.split(",").map(v => v.trim());
      const obj = {};
      headers.forEach((header, i) => {
        obj[header] = values[i];
      });
      return obj;
    });
  };

  const handleImportShop = async () => {
    setIsImporting(true);
    setStatus({ type: "", message: "" });

    try {
      const data = parseCSV(csvInput);
      let successCount = 0;
      const errors = [];

      for (const row of data) {
        try {
          const existing = shopItems.find(i => i.item_id === row.item_id);
          if (!existing) {
            errors.push(`Item ${row.item_id} not found`);
            continue;
          }

          const newPrice = parseFloat(row.current_price);
          if (isNaN(newPrice) || newPrice < 0) {
            errors.push(`Invalid price for ${row.item_id}: ${row.current_price}`);
            continue;
          }

          await ShopItem.update(existing.id, { price: newPrice });
          successCount++;
        } catch (err) {
          errors.push(`Error updating ${row.item_id}: ${err.message}`);
        }
      }

      await loadData();
      
      if (successCount > 0) {
        setStatus({ 
          type: "success", 
          message: `✅ Updated ${successCount} item price(s)! ${errors.length > 0 ? `${errors.length} failed.` : ''}` 
        });
        setCsvInput("");
      }
      
      if (errors.length > 0 && successCount === 0) {
        setStatus({ type: "error", message: `Failed: ${errors[0]}` });
      }
    } catch (error) {
      setStatus({ type: "error", message: `Import failed: ${error.message}` });
    } finally {
      setIsImporting(false);
    }
  };

  const handleImportLessons = async () => {
    setIsImporting(true);
    setStatus({ type: "", message: "" });

    try {
      const data = parseCSV(csvInput);
      let successCount = 0;
      const errors = [];

      for (const row of data) {
        try {
          const existing = lessons.find(l => l.id === row.lesson_id);
          if (!existing) {
            errors.push(`Lesson ${row.lesson_id} not found`);
            continue;
          }

          const newXP = parseInt(row.current_xp);
          const newCoins = parseInt(row.current_coins);
          
          if (isNaN(newXP) || newXP < 0) {
            errors.push(`Invalid XP for ${row.lesson_id}: ${row.current_xp}`);
            continue;
          }
          if (isNaN(newCoins) || newCoins < 0) {
            errors.push(`Invalid coins for ${row.lesson_id}: ${row.current_coins}`);
            continue;
          }

          await GameLesson.update(existing.id, { 
            xp_total: newXP,
            coins_total: newCoins
          });
          successCount++;
        } catch (err) {
          errors.push(`Error updating ${row.lesson_id}: ${err.message}`);
        }
      }

      await loadData();
      
      if (successCount > 0) {
        setStatus({ 
          type: "success", 
          message: `✅ Updated ${successCount} lesson reward(s)! ${errors.length > 0 ? `${errors.length} failed.` : ''}` 
        });
        setCsvInput("");
      }
      
      if (errors.length > 0 && successCount === 0) {
        setStatus({ type: "error", message: `Failed: ${errors[0]}` });
      }
    } catch (error) {
      setStatus({ type: "error", message: `Import failed: ${error.message}` });
    } finally {
      setIsImporting(false);
    }
  };

  const getShopTemplate = () => {
    return `item_id,item_name,current_price,item_type,treats
golden_apple,Golden Apple,20,physical,hunger
spring_water,Clear Spring Water,15,physical,thirst
bubble_bath,Bubble Wash Kit,25,physical,cleanliness
cheer_up_toy,Cheer-Up Toy,25,emotional,sad
calm_tea,Calming Tea,25,emotional,anxious
rainbow_lamp,Rainbow Lamp,50,decor,`;
  };

  const getLessonsTemplate = () => {
    return `lesson_id,lesson_name,quest,current_xp,current_coins
lesson_1,Lesson Name 1,BodyImageOdyssey,50,50
lesson_2,Lesson Name 2,BodyImageOdyssey,50,50
lesson_3,Lesson Name 3,BodyImageOdyssey,50,50`;
  };

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("ManageLessons"))}
          className="rounded-full"
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1165b3]">💰 Manage Rewards & Prices</h1>
          <p className="text-gray-600">Bulk update prices, XP, and coin rewards via spreadsheet</p>
        </div>
      </div>

      {status.message && (
        <Alert className={`mb-6 ${
          status.type === "success" ? "bg-green-50 border-green-200" :
          status.type === "error" ? "bg-red-50 border-red-200" :
          "bg-blue-50 border-blue-200"
        }`}>
          {status.type === "success" ? <CheckCircle2 className="h-4 w-4 text-green-600" /> : <AlertCircle className="h-4 w-4 text-red-600" />}
          <AlertDescription className={
            status.type === "success" ? "text-green-800" :
            status.type === "error" ? "text-red-800" :
            "text-blue-800"
          }>
            {status.message}
          </AlertDescription>
        </Alert>
      )}

      {/* Tabs */}
      <div className="flex gap-2 mb-6">
        <Button
          onClick={() => { setActiveTab("shop"); setCsvInput(""); setStatus({ type: "", message: "" }); }}
          className={`rounded-full ${activeTab === "shop" ? "bg-gradient-to-r from-[#1165b3] to-[#66bfad] text-white" : "bg-white text-gray-600 border-2"}`}
        >
          🛍️ Shop Item Prices
        </Button>
        <Button
          onClick={() => { setActiveTab("lessons"); setCsvInput(""); setStatus({ type: "", message: "" }); }}
          className={`rounded-full ${activeTab === "lessons" ? "bg-gradient-to-r from-[#1165b3] to-[#66bfad] text-white" : "bg-white text-gray-600 border-2"}`}
        >
          🎓 Lesson Rewards
        </Button>
      </div>

      <div className="grid lg:grid-cols-2 gap-6 mb-6">
        {/* Export Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="w-5 h-5" />
              Step 1: Export Current Values
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-gray-600">
              Download the current {activeTab === "shop" ? "prices" : "rewards"} as a CSV file. Open in Excel/Google Sheets to edit.
            </p>
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm font-semibold mb-2">Current Data:</p>
              <p className="text-2xl font-bold text-[#1165b3]">
                {activeTab === "shop" ? shopItems.length : lessons.length}
              </p>
              <p className="text-sm text-gray-600">
                {activeTab === "shop" ? "Shop Items" : "Lessons"}
              </p>
            </div>
            <Button
              onClick={activeTab === "shop" ? handleExportShopCSV : handleExportLessonsCSV}
              variant="outline"
              className="w-full"
            >
              <FileSpreadsheet className="w-4 h-4 mr-2" />
              Export to CSV
            </Button>
          </CardContent>
        </Card>

        {/* Import Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="w-5 h-5" />
              Step 2: Import Updated Values
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-gray-600">
              After editing, upload the CSV file to apply changes.
            </p>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Upload CSV File
              </label>
              <input
                type="file"
                accept=".csv"
                onChange={handleFileUpload}
                className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-[#66bfad] file:text-white hover:file:bg-[#66bfad]/90"
              />
            </div>
            <Button
              onClick={activeTab === "shop" ? handleImportShop : handleImportLessons}
              disabled={isImporting || !csvInput.trim()}
              className="w-full bg-gradient-to-r from-[#66bfad] to-[#1165b3] text-white"
            >
              {isImporting ? "Importing..." : "Import Updates"}
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* CSV Preview/Input */}
      <Card>
        <CardHeader>
          <CardTitle>CSV Preview / Manual Edit</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            value={csvInput || (activeTab === "shop" ? getShopTemplate() : getLessonsTemplate())}
            onChange={(e) => setCsvInput(e.target.value)}
            placeholder={activeTab === "shop" ? "item_id,item_name,current_price..." : "lesson_id,lesson_name,current_xp..."}
            className="h-64 font-mono text-sm"
          />
          <Button
            variant="outline"
            onClick={() => setCsvInput(activeTab === "shop" ? getShopTemplate() : getLessonsTemplate())}
            className="w-full"
          >
            Load Example Template
          </Button>
        </CardContent>
      </Card>

      {/* Current Values Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Table className="w-5 h-5" />
            Current {activeTab === "shop" ? "Prices" : "Rewards"}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            {activeTab === "shop" ? (
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-left">Item Name</th>
                    <th className="px-4 py-2 text-left">Type</th>
                    <th className="px-4 py-2 text-left">Current Price</th>
                    <th className="px-4 py-2 text-left">Treats</th>
                  </tr>
                </thead>
                <tbody>
                  {shopItems.slice(0, 20).map((item) => (
                    <tr key={item.id} className="border-b">
                      <td className="px-4 py-2">{item.item_name}</td>
                      <td className="px-4 py-2 capitalize">{item.item_type}</td>
                      <td className="px-4 py-2 font-semibold">🪙 {item.price}</td>
                      <td className="px-4 py-2">{item.treats || "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-left">Lesson Name</th>
                    <th className="px-4 py-2 text-left">Quest</th>
                    <th className="px-4 py-2 text-left">Current XP</th>
                    <th className="px-4 py-2 text-left">Current Coins</th>
                  </tr>
                </thead>
                <tbody>
                  {lessons.slice(0, 20).map((lesson) => (
                    <tr key={lesson.id} className="border-b">
                      <td className="px-4 py-2">{lesson.name}</td>
                      <td className="px-4 py-2">{lesson.quest}</td>
                      <td className="px-4 py-2 font-semibold">⚡ {lesson.xp_total || 50}</td>
                      <td className="px-4 py-2 font-semibold">🪙 {lesson.coins_total || 50}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
            {(activeTab === "shop" ? shopItems.length : lessons.length) > 20 && (
              <p className="text-sm text-gray-500 mt-4 text-center">
                Showing first 20 of {activeTab === "shop" ? shopItems.length : lessons.length} items
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Instructions */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>📋 How to Use Spreadsheets</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 text-sm">
            <div>
              <p className="font-semibold mb-2">Workflow:</p>
              <ol className="list-decimal list-inside ml-4 space-y-1">
                <li>Click "Export to CSV" to download current data</li>
                <li>Open the CSV in Excel, Google Sheets, or Numbers</li>
                <li>Edit the {activeTab === "shop" ? "<code>current_price</code>" : "<code>current_xp</code> and <code>current_coins</code>"} column(s)</li>
                <li>Save the file as CSV</li>
                <li>Upload here and click "Import Updates"</li>
              </ol>
            </div>
            
            <Alert className="bg-blue-50 border-blue-200">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-800">
                <strong>Important:</strong> Don't change the <code>item_id</code> or <code>lesson_id</code> columns - they're used to match records. Only edit the {activeTab === "shop" ? "price" : "reward"} values.
              </AlertDescription>
            </Alert>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}