
import React, { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import LessonIntro from "../components/games/LessonIntro";
import GlassBridgeSession from "../components/games/GlassBridgeSession";
import GlassBridgeMatchingSession from "../components/games/GlassBridgeMatchingSession";
import TakeawaysScreen from "../components/games/TakeawaysScreen";
import RewardsScreen from "../components/games/RewardsScreen";
import ReadOnlyLesson from "../components/games/ReadOnlyLesson";

export default function GlassBridgeGame() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const lessonId = searchParams.get("lessonId");
  const isReview = searchParams.get("review") === "true";

  const [lesson, setLesson] = useState(null);
  const [stage, setStage] = useState("loading");
  const [results, setResults] = useState(null);
  const [error, setError] = useState(null);
  const [user, setUser] = useState(null);

  useEffect(() => {
    if (!lessonId) {
      navigate(createPageUrl("GlassBridgeGames"));
      return;
    }
    loadLesson();
  }, [lessonId]);

  const loadLesson = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      const lessonData = await base44.entities.GameLesson.get(lessonId);
      
      if (!lessonData || !lessonData.questions || lessonData.questions.length === 0) {
        alert("Cannot play lesson: No questions found");
        navigate(createPageUrl("GlassBridgeGames"));
        return;
      }

      // Check if this quest+number has been completed (globally)
      const completions = await base44.entities.LessonCompletion.filter({
        user_email: currentUser.email,
        quest_id: lessonData.quest,
        lesson_number: lessonData.number
      });

      if (completions.length > 0 && !isReview) {
        setLesson(lessonData);
        setStage("read_only");
        return;
      }

      setLesson(lessonData);
      setStage("intro");
    } catch (error) {
      console.error("Error loading lesson:", error);
      alert("Failed to load lesson");
      navigate(createPageUrl("GlassBridgeGames"));
    }
  };

  const handleComplete = async (results) => {
    try {
      let coinsEarned = 0;
      let xpEarned = 0;

      if (!isReview) {
        const completions = await base44.entities.LessonCompletion.filter({
          user_email: user.email,
          quest_id: lesson.quest,
          lesson_number: lesson.number
        });

        if (completions.length === 0) {
          coinsEarned = lesson.coins_reward || 0;
          xpEarned = lesson.xp_reward || 0;

          await base44.entities.LessonCompletion.create({
            user_email: user.email,
            lesson_id: lesson.id,
            quest_id: lesson.quest,
            lesson_number: lesson.number,
            score: results.correctAnswers,
            total_questions: results.totalQuestions,
            coins_earned: coinsEarned,
            xp_earned: xpEarned,
            completed_date: new Date().toISOString()
          });

          const lumoStates = await base44.entities.LumoState.filter({ user_email: user.email });
          if (lumoStates.length > 0) {
            await base44.entities.LumoState.update(lumoStates[0].id, {
              total_coins: lumoStates[0].total_coins + coinsEarned,
              total_xp: lumoStates[0].total_xp + xpEarned
            });
          }
        }
      }

      setResults({ ...results, coinsEarned, xpEarned });
      
      if (lesson?.keyTakeaways && lesson.keyTakeaways.trim()) {
        setStage("takeaways");
      } else {
        setStage("rewards");
      }
    } catch (error) {
      console.error("Error completing lesson:", error);
      setError("Error saving progress: " + error.message);
      setResults({ ...results, coinsEarned: 0, xpEarned: 0 });
      setStage("rewards");
    }
  };

  if (stage === "loading" || !lesson) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-cyan-100 to-blue-200">
        <div className="text-center">
          <div className="text-6xl mb-4 animate-bounce">🌉</div>
          <p className="text-cyan-600 font-semibold">Loading...</p>
        </div>
      </div>
    );
  }

  if (stage === "read_only") {
    return (
      <ReadOnlyLesson
        lesson={lesson}
        onExit={() => navigate(createPageUrl("GlassBridgeGames"))}
      />
    );
  }

  if (stage === "intro") {
    return (
      <LessonIntro
        lesson={lesson}
        onStart={() => setStage("playing")}
        onExit={() => navigate(createPageUrl("GlassBridgeGames"))}
      />
    );
  }

  if (stage === "playing") {
    if (lesson.game_format === "matching") {
      return (
        <GlassBridgeMatchingSession
          lesson={lesson}
          isReviewMode={isReview}
          onComplete={handleComplete}
          onExit={() => navigate(createPageUrl("GlassBridgeGames"))}
        />
      );
    }

    return (
      <GlassBridgeSession
        lesson={lesson}
        onComplete={handleComplete}
        onExit={() => navigate(createPageUrl("GlassBridgeGames"))}
      />
    );
  }

  if (stage === "takeaways") {
    return (
      <TakeawaysScreen
        keyTakeaways={lesson.keyTakeaways}
        onContinue={() => setStage("rewards")}
      />
    );
  }

  if (stage === "rewards") {
    return (
      <RewardsScreen
        results={results}
        lesson={lesson}
        isReview={isReview}
        onContinue={() => navigate(createPageUrl("GlassBridgeGames"))}
      />
    );
  }

  return null;
}
