import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Lock, Crown } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';

export default function Hub() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [hasSubscription, setHasSubscription] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    checkSubscription();
  }, []);

  const checkSubscription = async () => {
    try {
      setIsLoading(true);
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      // Check if user has subscription (you can customize this logic)
      // For now, check if user has a subscription field or role
      const hasAccess = currentUser.subscription_status === 'active' || 
                       currentUser.subscription_tier === 'premium' ||
                       currentUser.has_hub_access === true;
      
      setHasSubscription(hasAccess);
    } catch (error) {
      console.error("Error checking subscription:", error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="text-6xl mb-4 animate-bounce">✨</div>
          <p className="text-[#1165b3] font-semibold">Loading...</p>
        </div>
      </div>
    );
  }

  // Show locked screen if no subscription
  if (!hasSubscription) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("Home"))}
            className="rounded-full"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-[var(--color-primary-blue)]">The Hub ✨</h1>
            <p className="text-gray-600">Premium tools to help you feel your best</p>
          </div>
        </div>

        <Card className="border-4 border-[#ffa400] bg-gradient-to-br from-amber-50 to-orange-50">
          <CardHeader className="text-center pb-4">
            <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-[#ffa400] to-[#ff8c00] rounded-full flex items-center justify-center">
              <Crown className="w-10 h-10 text-white" />
            </div>
            <CardTitle className="text-3xl text-[#1165b3]">
              <Lock className="w-8 h-8 inline-block mr-2" />
              Premium Access Required
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center">
              <p className="text-xl font-semibold text-gray-800 mb-4">
                The Hub contains special premium tools:
              </p>
              <div className="space-y-3 text-left max-w-md mx-auto">
                <div className="flex items-start gap-3 bg-white p-4 rounded-xl">
                  <div className="text-3xl">🧠✨</div>
                  <div>
                    <p className="font-semibold text-[#1165b3]">Dopamine Boost Check-In</p>
                    <p className="text-sm text-gray-600">Understand your cravings and feelings</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 bg-white p-4 rounded-xl">
                  <div className="text-3xl">🍽️✨</div>
                  <div>
                    <p className="font-semibold text-[#1165b3]">Mindful Munchies Spinner</p>
                    <p className="text-sm text-gray-600">Family mindful eating activities</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 bg-white p-4 rounded-xl">
                  <div className="text-3xl">🍳✨</div>
                  <div>
                    <p className="font-semibold text-[#1165b3]">Mindful Kitchen</p>
                    <p className="text-sm text-gray-600">Nourishing recipes and cooking tips</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-r from-[#66bfad] to-[#1165b3] text-white p-6 rounded-2xl text-center">
              <p className="text-xl font-bold mb-2">Upgrade to Premium</p>
              <p className="text-sm mb-4">Get full access to all Hub tools and more!</p>
              <div className="flex gap-3 justify-center flex-wrap">
                <Button
                  onClick={() => window.open('https://healthquest.com/subscribe', '_blank')}
                  className="bg-white text-[#1165b3] hover:bg-gray-100 font-bold px-8 py-6 text-lg rounded-2xl"
                >
                  <Crown className="w-5 h-5 mr-2" />
                  Subscribe Now
                </Button>
                <Button
                  onClick={() => navigate(createPageUrl("Home"))}
                  variant="outline"
                  className="border-2 border-white text-white hover:bg-white/20 font-bold px-8 py-6 text-lg rounded-2xl"
                >
                  Back to Home
                </Button>
              </div>
            </div>

            <p className="text-center text-sm text-gray-500">
              💡 Already a subscriber? Contact support to link your account!
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Original Hub content for subscribed users
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("Home"))}
          className="rounded-full"
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[var(--color-primary-blue)]">The Hub ✨</h1>
          <p className="text-gray-600">Discover tools to help you feel your best</p>
        </div>
      </div>

      <div className="space-y-6">
        {/* Dopamine Boost Check-In Card */}
        <motion.div
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Card 
            className="cursor-pointer border-2 border-[#66bfad]/30 hover:border-[#66bfad] hover:shadow-xl transition-all bg-gradient-to-br from-white to-[#e0f8f5]/30"
            onClick={() => navigate(createPageUrl("DopamineCheckIn"))}
          >
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="text-5xl">🧠✨</div>
                <div className="flex-1">
                  <CardTitle className="text-2xl text-[var(--color-primary-blue)]" style={{ fontFamily: 'Poppins' }}>
                    Dopamine Boost Check-In
                  </CardTitle>
                  <p className="text-gray-600 mt-1" style={{ fontFamily: 'Poppins' }}>
                    Feeling snacky? Let's figure out what your brain really needs!
                  </p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex gap-2 text-sm text-gray-600">
                  <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full font-medium">2-5 minutes</span>
                  <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full font-medium">Earn Rewards</span>
                </div>
                <Button className="bg-gradient-to-r from-[#66bfad] to-[#1165b3] text-white rounded-2xl">
                  Start Now
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Mindful Munchies Card */}
        <motion.div
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Card 
            className="cursor-pointer border-2 border-[#66bfad]/30 hover:border-[#66bfad] hover:shadow-xl transition-all bg-gradient-to-br from-white to-[#e0f8f5]/30"
            onClick={() => navigate(createPageUrl("MindfulMunchies"))}
          >
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="text-5xl">🍽️✨</div>
                <div className="flex-1">
                  <CardTitle className="text-2xl text-[var(--color-primary-blue)]" style={{ fontFamily: 'Poppins' }}>
                    Lumo's Mindful Munchies Spinner
                  </CardTitle>
                  <p className="text-gray-600 mt-1" style={{ fontFamily: 'Poppins' }}>
                    Slow down and savor your meals together!
                  </p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex gap-2 text-sm text-gray-600">
                  <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full font-medium">Family Activity</span>
                  <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full font-medium">Earn XP & Coins</span>
                </div>
                <Button className="bg-gradient-to-r from-[#66bfad] to-[#1165b3] text-white rounded-2xl">
                  Start Now
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Mindful Kitchen Card */}
        <motion.div
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Card 
            className="cursor-pointer border-2 border-[#66bfad]/30 hover:border-[#66bfad] hover:shadow-xl transition-all bg-gradient-to-br from-white to-[#e0f8f5]/30"
            onClick={() => navigate(createPageUrl("MindfulKitchen"))}
          >
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="text-5xl">🍳✨</div>
                <div className="flex-1">
                  <CardTitle className="text-2xl text-[var(--color-primary-blue)]" style={{ fontFamily: 'Poppins' }}>
                    Lumo's Mindful Kitchen
                  </CardTitle>
                  <p className="text-gray-600 mt-1" style={{ fontFamily: 'Poppins' }}>
                    Discover nourishing recipes and mindful cooking tips!
                  </p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex gap-2 text-sm text-gray-600">
                  <span className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full font-medium">Recipe Browser</span>
                  <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full font-medium">+20 Coins Per Save</span>
                </div>
                <Button className="bg-gradient-to-r from-[#66bfad] to-[#1165b3] text-white rounded-2xl">
                  Browse Recipes
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}