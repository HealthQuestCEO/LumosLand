import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Plus, Pencil, Trash2, Upload, X, Image as ImageIcon } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ManageReflectionQuestions() {
  const navigate = useNavigate();
  const [questions, setQuestions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [editingQuestion, setEditingQuestion] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [bulkJSON, setBulkJSON] = useState("");
  const [showBulkImport, setShowBulkImport] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);

  const [formData, setFormData] = useState({
    question_id: "",
    question_text: "",
    hint: "",
    category: "emotions",
    image_url: "",
    xp_reward: 30,
    coins_reward: 15,
    sort_order: 0,
    is_active: true
  });

  const exampleJSON = `[
  {
    "question_id": "emotions_001",
    "question_text": "How are you feeling right now?",
    "hint": "Think about your emotions - happy, sad, excited, worried, calm?",
    "category": "emotions",
    "xp_reward": 30,
    "coins_reward": 15,
    "sort_order": 1,
    "is_active": true
  },
  {
    "question_id": "goals_001",
    "question_text": "What's one thing you want to accomplish this week?",
    "hint": "It can be big or small - learning something new, helping someone, or finishing a project",
    "category": "goals",
    "xp_reward": 30,
    "coins_reward": 15,
    "sort_order": 2,
    "is_active": true
  },
  {
    "question_id": "gratitude_001",
    "question_text": "What made you smile today?",
    "hint": "Think about something that brought you joy - big or small",
    "category": "gratitude",
    "xp_reward": 30,
    "coins_reward": 15,
    "sort_order": 3,
    "is_active": true
  },
  {
    "question_id": "growth_001",
    "question_text": "What's something new you learned recently?",
    "hint": "It could be a skill, a fact, or something about yourself",
    "category": "growth",
    "xp_reward": 30,
    "coins_reward": 15,
    "sort_order": 4,
    "is_active": true
  },
  {
    "question_id": "self_care_001",
    "question_text": "What's one way you took care of yourself today?",
    "hint": "Think about healthy choices - exercise, rest, eating well, asking for help",
    "category": "self_care",
    "xp_reward": 30,
    "coins_reward": 15,
    "sort_order": 5,
    "is_active": true
  },
  {
    "question_id": "relationships_001",
    "question_text": "Who made you feel loved or appreciated today?",
    "hint": "Think about family, friends, teachers, or anyone who showed you kindness",
    "category": "relationships",
    "xp_reward": 30,
    "coins_reward": 15,
    "sort_order": 6,
    "is_active": true
  },
  {
    "question_id": "emotions_002",
    "question_text": "What helped you feel better when you were upset?",
    "hint": "Maybe talking to someone, doing an activity, or taking deep breaths?",
    "category": "emotions",
    "xp_reward": 30,
    "coins_reward": 15,
    "sort_order": 7,
    "is_active": true
  },
  {
    "question_id": "goals_002",
    "question_text": "What's something you're proud of this week?",
    "hint": "It could be something you finished, a kind act, or overcoming a challenge",
    "category": "goals",
    "xp_reward": 30,
    "coins_reward": 15,
    "sort_order": 8,
    "is_active": true
  },
  {
    "question_id": "gratitude_002",
    "question_text": "What's something in your life you're thankful for?",
    "hint": "Think about people, places, things, or opportunities you appreciate",
    "category": "gratitude",
    "xp_reward": 30,
    "coins_reward": 15,
    "sort_order": 9,
    "is_active": true
  }
]`;

  useEffect(() => {
    loadQuestions();
  }, []);

  const loadQuestions = async () => {
    try {
      setIsLoading(true);
      const allQuestions = await base44.entities.ReflectionQuestion.list();
      setQuestions(allQuestions.sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0)));
    } catch (error) {
      console.error("Error loading questions:", error);
      alert("Error loading questions: " + error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      question_id: "",
      question_text: "",
      hint: "",
      category: "emotions",
      image_url: "",
      xp_reward: 30,
      coins_reward: 15,
      sort_order: 0,
      is_active: true
    });
    setEditingQuestion(null);
    setShowForm(false);
  };

  const handleEdit = (question) => {
    setFormData({
      question_id: question.question_id,
      question_text: question.question_text,
      hint: question.hint || "",
      category: question.category || "emotions",
      image_url: question.image_url || "",
      xp_reward: question.xp_reward || 30,
      coins_reward: question.coins_reward || 15,
      sort_order: question.sort_order || 0,
      is_active: question.is_active !== false
    });
    setEditingQuestion(question);
    setShowForm(true);
  };

  const handleNew = () => {
    setFormData({
      question_id: `q_${Date.now()}`,
      question_text: "",
      hint: "",
      category: "emotions",
      image_url: "",
      xp_reward: 30,
      coins_reward: 15,
      sort_order: questions.length,
      is_active: true
    });
    setEditingQuestion(null);
    setShowForm(true);
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingImage(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, image_url: file_url });
    } catch (error) {
      console.error("Error uploading image:", error);
      alert("Failed to upload image: " + error.message);
    } finally {
      setUploadingImage(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.question_text.trim()) {
      alert("Please enter a question.");
      return;
    }

    try {
      if (editingQuestion) {
        await base44.entities.ReflectionQuestion.update(editingQuestion.id, formData);
        alert("Question updated!");
      } else {
        await base44.entities.ReflectionQuestion.create(formData);
        alert("Question created!");
      }
      
      resetForm();
      loadQuestions();
    } catch (error) {
      console.error("Error saving question:", error);
      alert("Error: " + error.message);
    }
  };

  const handleDelete = async (question) => {
    if (!confirm("Delete this question? This action cannot be undone.")) return;

    try {
      await base44.entities.ReflectionQuestion.delete(question.id);
      alert("Question deleted!");
      loadQuestions();
    } catch (error) {
      console.error("Error deleting question:", error);
      alert("Error: " + error.message);
    }
  };

  const handleBulkImport = async () => {
    if (!bulkJSON.trim()) {
      alert("Please paste JSON data to import.");
      return;
    }

    try {
      const questionsToImport = JSON.parse(bulkJSON);

      if (!Array.isArray(questionsToImport)) {
        alert("The provided JSON must be an array of question objects.");
        return;
      }

      let imported = 0;
      for (const qData of questionsToImport) {
        if (!qData.question_text || !qData.question_id) {
          console.warn("Skipping question due to missing required fields:", qData);
          continue;
        }

        await base44.entities.ReflectionQuestion.create({
          question_id: qData.question_id,
          question_text: qData.question_text,
          hint: qData.hint || "",
          category: qData.category || "emotions",
          image_url: qData.image_url || "",
          xp_reward: qData.xp_reward !== undefined ? qData.xp_reward : 30,
          coins_reward: qData.coins_reward !== undefined ? qData.coins_reward : 15,
          sort_order: qData.sort_order !== undefined ? qData.sort_order : 0,
          is_active: qData.is_active !== undefined ? qData.is_active : true,
        });
        imported++;
      }

      alert(`Successfully imported ${imported} questions!`);
      setBulkJSON("");
      setShowBulkImport(false);
      await loadQuestions();
    } catch (error) {
      console.error("Error importing:", error);
      alert("Import failed: " + error.message);
    }
  };

  if (showForm) {
    return (
      <div className="max-w-2xl mx-auto p-8">
        <div className="flex items-center gap-4 mb-8">
          <Button variant="outline" size="icon" onClick={() => setShowForm(false)}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold text-[#1165b3]">
            {editingQuestion ? "Edit Question" : "New Question"}
          </h1>
        </div>

        <Card>
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>Question *</Label>
                <Textarea
                  value={formData.question_text}
                  onChange={(e) => setFormData({ ...formData, question_text: e.target.value })}
                  placeholder="What made you smile today?"
                  className="h-24"
                />
              </div>

              <div>
                <Label>Hint (optional)</Label>
                <Input
                  value={formData.hint}
                  onChange={(e) => setFormData({ ...formData, hint: e.target.value })}
                  placeholder="Think about moments that brought you joy..."
                />
              </div>

              <div>
                <Label>Image (optional)</Label>
                <div className="space-y-2">
                  {formData.image_url && (
                    <div className="relative w-full h-48 bg-gray-100 rounded-lg overflow-hidden">
                      <img src={formData.image_url} alt="Question" className="w-full h-full object-contain" />
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute top-2 right-2"
                        onClick={() => setFormData({ ...formData, image_url: "" })}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                  <div className="flex gap-2">
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      disabled={uploadingImage}
                      className="flex-1"
                    />
                    {uploadingImage && <span className="text-sm text-gray-500">Uploading...</span>}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Category</Label>
                  <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="emotions">Emotions</SelectItem>
                      <SelectItem value="goals">Goals</SelectItem>
                      <SelectItem value="gratitude">Gratitude</SelectItem>
                      <SelectItem value="growth">Growth</SelectItem>
                      <SelectItem value="relationships">Relationships</SelectItem>
                      <SelectItem value="self_care">Self Care</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Sort Order</Label>
                  <Input
                    type="number"
                    value={formData.sort_order}
                    onChange={(e) => setFormData({ ...formData, sort_order: parseInt(e.target.value) || 0 })}
                  />
                </div>

                <div>
                  <Label>XP Reward</Label>
                  <Input
                    type="number"
                    value={formData.xp_reward}
                    onChange={(e) => setFormData({ ...formData, xp_reward: parseInt(e.target.value) || 0 })}
                  />
                </div>

                <div>
                  <Label>Coins Reward</Label>
                  <Input
                    type="number"
                    value={formData.coins_reward}
                    onChange={(e) => setFormData({ ...formData, coins_reward: parseInt(e.target.value) || 0 })}
                  />
                </div>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.is_active}
                  onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })}
                  className="w-4 h-4"
                />
                <Label>Active</Label>
              </div>

              <div className="flex gap-3 pt-4">
                <Button type="submit" className="flex-1 bg-[#66bfad]">
                  {editingQuestion ? "Update" : "Create"} Question
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl("AdminPanel"))}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold text-[#1165b3]">Mood & Moves Journal Questions</h1>
          <p className="text-gray-600">Manage reflection questions for the journal</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={handleNew} className="bg-[#66bfad]">
            <Plus className="w-4 h-4 mr-2" />
            Add Question
          </Button>
          <Button onClick={() => setShowBulkImport(!showBulkImport)} variant="outline">
            {showBulkImport ? <X className="w-4 h-4 mr-2" /> : <Upload className="w-4 h-4 mr-2" />}
            {showBulkImport ? "Hide" : "Bulk Import"}
          </Button>
        </div>
      </div>

      {showBulkImport && (
        <Card className="mb-6 border-2 border-[#66bfad]">
          <CardHeader>
            <CardTitle>Bulk Import Questions (JSON)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="block text-sm font-medium mb-2">Paste JSON Array:</Label>
              <Textarea
                value={bulkJSON}
                onChange={(e) => setBulkJSON(e.target.value)}
                placeholder={exampleJSON}
                className="h-64 font-mono text-sm"
              />
            </div>
            <div className="flex gap-3">
              <Button onClick={handleBulkImport} className="bg-[#1165b3]">
                <Upload className="w-4 h-4 mr-2" />
                Import Questions
              </Button>
              <Button variant="outline" onClick={() => setShowBulkImport(false)}>
                Cancel
              </Button>
            </div>
            <details className="mt-4">
              <summary className="cursor-pointer text-sm font-semibold text-gray-700 mb-2">
                📝 Example JSON Format (9 Questions)
              </summary>
              <pre className="bg-gray-100 p-4 rounded-lg text-xs overflow-x-auto">
                {exampleJSON}
              </pre>
            </details>
          </CardContent>
        </Card>
      )}

      {/* Questions List */}
      <div className="space-y-4">
        {isLoading ? (
          <p className="text-center py-8">Loading...</p>
        ) : questions.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <p className="text-gray-500">No questions yet. Add your first one!</p>
            </CardContent>
          </Card>
        ) : (
          questions.map((question) => (
            <Card key={question.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <span className="text-xs bg-[#66bfad]/20 text-[#1165b3] px-2 py-1 rounded capitalize">
                        {question.category}
                      </span>
                      <span className="text-xs text-gray-500">Order: {question.sort_order}</span>
                      <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                        ⚡ {question.xp_reward || 30} XP
                      </span>
                      <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded">
                        🪙 {question.coins_reward || 15} Coins
                      </span>
                      {!question.is_active && (
                        <span className="text-xs bg-red-100 text-red-800 px-2 py-1 rounded">Inactive</span>
                      )}
                    </div>
                    {question.image_url && (
                      <div className="w-32 h-32 bg-gray-100 rounded-lg overflow-hidden mb-2">
                        <img src={question.image_url} alt="Question" className="w-full h-full object-cover" />
                      </div>
                    )}
                    <p className="text-lg font-semibold text-gray-800 mb-1">{question.question_text}</p>
                    {question.hint && (
                      <p className="text-sm text-gray-600 italic">💡 {question.hint}</p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="icon" onClick={() => handleEdit(question)}>
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button variant="outline" size="icon" onClick={() => handleDelete(question)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}