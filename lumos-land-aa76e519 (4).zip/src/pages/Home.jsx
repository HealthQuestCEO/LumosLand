
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import LumoCharacter from "../components/lumo/LumoCharacter";
import EmotionIdentificationGame from "../components/lumo/EmotionIdentificationGame";
import RoomCard from "../components/lumo/RoomCard";
import NeedBar from "../components/lumo/NeedBar";
import DailySpinner from "../components/lumo/DailySpinner";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { add, differenceInHours, differenceInMinutes, differenceInDays, format } from 'date-fns';

const EMOTION_STATES = ["happy", "content", "angry", "sad", "sleepy", "playful", "brave", "confident", "anxious"];

export default function Home() {
  const [lumoState, setLumoState] = useState(null);
  const [user, setUser] = useState(null);
  const [activityLog, setActivityLog] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSleepTime, setIsSleepTime] = useState(false);
  const [showSpinner, setShowSpinner] = useState(false);
  const [announcements, setAnnouncements] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const init = async () => {
      // First, check if user is authenticated
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        // Redirect to base44 login
        base44.auth.redirectToLogin();
        return;
      }

      await loadData();
      await loadAnnouncements();
      checkSleepTime();

      const interval = setInterval(() => {
        checkSleepTime();
        updateNeeds();
      }, 60000);
      return () => clearInterval(interval);
    };
    init();
  }, [user?.email]);

  const loadAnnouncements = async () => {
    try {
      const allAnnouncements = await base44.entities.Announcement.filter({ is_active: true });
      const now = new Date();

      const activeAnnouncements = allAnnouncements.filter((a) => {
        const start = a.start_date ? new Date(a.start_date) : new Date(0);
        const end = a.end_date ? new Date(a.end_date) : new Date('2099-12-31'); // Default far future if no end_date
        return now >= start && now <= end;
      });

      setAnnouncements(activeAnnouncements);
    } catch (error) {
      console.error("Error loading announcements:", error);
    }
  };

  const checkSleepTime = () => {
    if (!user) return;

    const saved = localStorage.getItem(`sleep_schedule_${user.email}`);
    let bedtime = 21;
    let wakeTime = 7;

    if (saved) {
      try {
        const schedule = JSON.parse(saved);
        bedtime = schedule.bedtime;
        wakeTime = schedule.wakeTime;
      } catch (e) {
        console.error("Error parsing sleep schedule from localStorage", e);
      }
    }

    const now = new Date();
    const centralTime = new Date(now.toLocaleString("en-US", { timeZone: "America/Chicago" }));
    const hour = centralTime.getHours();

    if (bedtime > wakeTime) {
      setIsSleepTime(hour >= bedtime || hour < wakeTime);
    } else {
      setIsSleepTime(hour >= bedtime && hour < wakeTime);
    }
  };

  const loadData = async () => {
    setIsLoading(true);
    try {
      const currentUser = await base44.auth.me();
      if (!currentUser) {
        base44.auth.redirectToLogin();
        return;
      }
      setUser(currentUser);

      let states = await base44.entities.LumoState.filter({ user_email: currentUser.email });
      let state;

      if (states.length > 0) {
        state = states[0];

        if (state.emotional_need === undefined) {
          state = await base44.entities.LumoState.update(state.id, {
            emotional_need: 100
          });
        }

        if (state.current_season !== "fall") {
          state = await base44.entities.LumoState.update(state.id, {
            current_season: "fall"
          });
        }

        if (!state.is_missing && state.fly_away_check_time) {
          const now = new Date();
          const checkTime = new Date(state.fly_away_check_time);

          if (now > checkTime) {
            const daysSinceLastCare = Math.min(
              differenceInDays(now, new Date(state.last_fed_time)),
              differenceInDays(now, new Date(state.last_watered_time)),
              differenceInDays(now, new Date(state.last_cleaned_time))
            );

            if (daysSinceLastCare >= 3) {
              state = await base44.entities.LumoState.update(state.id, {
                is_missing: true,
                current_emotion_state: "missing"
              });
            } else {
              state = await base44.entities.LumoState.update(state.id, {
                fly_away_check_time: add(new Date(), { days: 3 }).toISOString()
              });
            }
          }
        }
      } else {
        const now = new Date().toISOString();
        state = await base44.entities.LumoState.create({
          user_email: currentUser.email,
          lumo_name: "Lumo",
          hunger: 100,
          thirst: 100,
          cleanliness: 100,
          emotional_need: 100,
          current_emotion_state: "happy",
          current_season: "fall",
          last_fed_time: now,
          last_watered_time: now,
          last_cleaned_time: now,
          last_emotion_change_time: now,
          fly_away_check_time: add(new Date(), { days: 3 }).toISOString(),
          total_coins: 100,
          total_xp: 0,
          is_missing: false
        });
      }

      const today = format(new Date(), "yyyy-MM-dd");
      let logs = await base44.entities.ActivityLog.filter({ user_email: currentUser.email, activity_date: today });
      if (logs.length > 0) {
        setActivityLog(logs[0]);
      } else {
        const newLog = await base44.entities.ActivityLog.create({
          user_email: currentUser.email,
          activity_date: today,
          care_loop_xp_today: 0,
          care_loop_coins_today: 0,
          guessed_states_today: [],
          lessons_completed: 0,
          journal_entries: 0,
          npc_interactions: 0,
          naps_taken: 0,
          emotion_recognitions: 0
        });
        setActivityLog(newLog);
      }

      calculateCurrentNeeds(state);

    } catch (error) {
      console.error("Error loading data:", error);
    }
    setIsLoading(false);
  };

  const calculateCurrentNeeds = (state) => {
    const now = new Date();

    // ALL needs deplete over 24 hours
    const depletionPerMinute = 100 / (24 * 60);

    const minutesSinceLastFed = differenceInMinutes(now, new Date(state.last_fed_time));
    const minutesSinceLastWatered = differenceInMinutes(now, new Date(state.last_watered_time));
    const minutesSinceLastCleaned = differenceInMinutes(now, new Date(state.last_cleaned_time));
    const minutesSinceEmotionChange = differenceInMinutes(now, new Date(state.last_emotion_change_time));

    const hungerDepletion = minutesSinceLastFed * depletionPerMinute;
    const thirstDepletion = minutesSinceLastWatered * depletionPerMinute;
    const cleanlinessDepletion = minutesSinceLastCleaned * depletionPerMinute;
    const emotionalDepletion = minutesSinceEmotionChange * depletionPerMinute;

    const calculatedState = {
      ...state,
      hunger: Math.max(0, Math.min(100, 100 - hungerDepletion)),
      thirst: Math.max(0, Math.min(100, 100 - thirstDepletion)),
      cleanliness: Math.max(0, Math.min(100, 100 - cleanlinessDepletion)),
      emotional_need: Math.max(0, Math.min(100, 100 - emotionalDepletion))
    };

    setLumoState(calculatedState);
  };

  const updateNeeds = async () => {
    if (!user) return;

    let states = await base44.entities.LumoState.filter({ user_email: user.email });
    if (states.length === 0 || states[0].is_missing) return;

    const currentState = states[0];
    const now = new Date();

    const depletionPerMinute = 100 / (24 * 60);

    const minutesSinceLastFed = differenceInMinutes(now, new Date(currentState.last_fed_time));
    const minutesSinceLastWatered = differenceInMinutes(now, new Date(currentState.last_watered_time));
    const minutesSinceLastCleaned = differenceInMinutes(now, new Date(currentState.last_cleaned_time));
    const minutesSinceEmotionChange = differenceInMinutes(now, new Date(currentState.last_emotion_change_time));

    const newHunger = Math.max(0, Math.min(100, 100 - minutesSinceLastFed * depletionPerMinute));
    const newThirst = Math.max(0, Math.min(100, 100 - minutesSinceLastWatered * depletionPerMinute));
    const newCleanliness = Math.max(0, Math.min(100, 100 - minutesSinceLastCleaned * depletionPerMinute));
    const newEmotionalNeed = Math.max(0, Math.min(100, 100 - minutesSinceEmotionChange * depletionPerMinute));

    let updates = {};
    const nowISO = now.toISOString();

    const allPhysicalNeedsMet = newHunger > 70 && newThirst > 70 && newCleanliness > 70;
    const emotionalNeedMet = newEmotionalNeed > 50;

    // Only change emotion state if NOT sleep time
    if (!isSleepTime) {
      const hoursSinceEmotionChange = minutesSinceEmotionChange / 60;

      if (allPhysicalNeedsMet && emotionalNeedMet && currentState.current_emotion_state !== "happy") {
        updates.current_emotion_state = "happy";
        updates.last_emotion_change_time = nowISO;
      } else if (currentState.current_emotion_state === "happy" && (!emotionalNeedMet || !allPhysicalNeedsMet)) {
        const negativeEmotions = ["sad", "anxious", "angry", "sleepy"];
        updates.current_emotion_state = negativeEmotions[Math.floor(Math.random() * negativeEmotions.length)];
        updates.last_emotion_change_time = nowISO;
      } else if (hoursSinceEmotionChange >= 6 && EMOTION_STATES.includes(currentState.current_emotion_state) && currentState.current_emotion_state !== "happy") {
        const negativeEmotions = EMOTION_STATES.filter((e) => e !== "happy" && e !== "missing");
        const currentEmotion = currentState.current_emotion_state;
        const availableEmotions = negativeEmotions.filter((e) => e !== currentEmotion);
        if (availableEmotions.length > 0) {
          updates.current_emotion_state = availableEmotions[Math.floor(Math.random() * availableEmotions.length)];
          updates.last_emotion_change_time = nowISO;
        }
      }
    }

    if (Object.keys(updates).length > 0) {
      const updatedState = await base44.entities.LumoState.update(currentState.id, updates);
      calculateCurrentNeeds(updatedState);
    } else {
      calculateCurrentNeeds(currentState);
    }
  };

  const handleCorrectGuess = async (guessedState) => {
    const careLoopXpToday = activityLog?.care_loop_xp_today || 0;
    const careLoopCoinsToday = activityLog?.care_loop_coins_today || 0;
    const guessedStatesToday = activityLog?.guessed_states_today || [];

    if (guessedStatesToday.includes(guessedState)) {
      return;
    }

    const xpToAward = careLoopXpToday < 45 ? 15 : 0;
    const coinsToAward = careLoopCoinsToday < 15 ? 5 : 0;

    if (xpToAward > 0 || coinsToAward > 0) {
      const updates = {
        total_coins: (lumoState.total_coins || 0) + coinsToAward,
        total_xp: (lumoState.total_xp || 0) + xpToAward
      };

      const updated = await base44.entities.LumoState.update(lumoState.id, updates);
      setLumoState(updated);

      const newGuessedStates = [...guessedStatesToday, guessedState];
      await base44.entities.ActivityLog.update(activityLog.id, {
        care_loop_xp_today: careLoopXpToday + xpToAward,
        care_loop_coins_today: careLoopCoinsToday + coinsToAward,
        guessed_states_today: newGuessedStates
      });

      await loadData();
    }
  };

  const handleGuess = async () => {
    const updatedLog = await base44.entities.ActivityLog.update(activityLog.id, {
      emotion_recognitions: (activityLog.emotion_recognitions || 0) + 1
    });
    setActivityLog(updatedLog);
  };

  if (isLoading || !lumoState || !activityLog) {
    return (
      <div className="flex items-center justify-center h-full min-h-[calc(100vh-10rem)]">
        <div className="text-center"><div className="text-6xl mb-4 animate-bounce">✨</div><p className="text-[var(--color-primary-blue-border)] font-semibold">Loading Lumo's Land...</p></div>
      </div>);
  }

  if (lumoState.is_missing) {
    return (
      <div className="container mx-auto">
        <Card className="max-w-2xl mx-auto bg-white rounded-2xl shadow-lg border-2 border-orange-300">
          <CardHeader>
            <CardTitle className="text-3xl font-bold text-orange-600 text-center">Lumo is Missing! 😢</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-6 p-8">
            <div className="text-8xl mb-4">🗺️</div>
            <p className="text-gray-700 text-lg">
              Lumo flew away because their needs weren't met for 3 days...
            </p>
            <p className="text-gray-600">
              But don't worry! You can bring them back by purchasing the <strong>Rescue Map</strong> from Lumo's Nook.
            </p>
            <Button
              onClick={() => navigate(createPageUrl("LumosNook"))}
              className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-8 py-4 rounded-2xl text-lg font-bold hover:shadow-xl transition-all">

              Go to Lumo's Nook
            </Button>
          </CardContent>
        </Card>
      </div>);

  }

  return (
    <div className="container mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          <div className="lg:col-span-2 space-y-8">
            <Card className="bg-white rounded-2xl shadow-lg border-2 border-[var(--color-border-blue)]/30">
                <CardHeader>
                    <CardTitle className="text-sky-700 text-2xl font-bold tracking-tight">Welcome Back!</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-[var(--color-border-blue)]">Here's a quick look at your journey with Lumo. Explore the different rooms to learn, play, and grow together!</p>
                    {isSleepTime &&
              <p className="text-purple-600 font-semibold mt-2">🌙 It's bedtime! Lumo is sleeping peacefully.</p>
              }
                </CardContent>
            </Card>

            <Card className="bg-white rounded-2xl shadow-lg border-2 border-[var(--color-border-blue)]/30">
                <CardHeader className="text-sky-700 p-6 flex flex-col space-y-1.5">
                     <CardTitle className="text-2xl font-bold text-[var(--color-border-blue)]">Explore Portals</CardTitle>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <RoomCard title="Adventure Academy" description="Learn and earn rewards" icon="🎓" pageName="AdventureAcademy" gradient="from-[var(--color-primary-teal)] to-[var(--color-primary-teal)]/80" />
                  <RoomCard title="Lumo's Castle" description="Rest, reflect, and recharge" icon="🏰" pageName="LumosCastle" gradient="from-[var(--color-primary-teal)] to-[var(--color-primary-teal)]/80" />
                  <RoomCard title="Lumo's Nook" description="Shop for cool items" icon="🍄" pageName="LumosNook" gradient="from-[var(--color-accent-orange)] to-[var(--color-accent-orange)]/80" />
                  <RoomCard title="Treasure Room" description="See your badges and XP" icon="🏆" pageName="TreasureRoom" gradient="from-[var(--color-accent-orange)] to-[var(--color-accent-orange)]/80" />
                  <RoomCard title="Glow Ridge Path" description="Meet new friends" icon="🌲" pageName="GlowRidgePath" gradient="from-[var(--color-accent-cyan)] to-[var(--color-accent-cyan)]/80" />
                  <RoomCard title="The Hub" description="Discover more" icon="✨" pageName="Hub" gradient="from-[var(--color-accent-cyan)] to-[var(--color-accent-cyan)]/80" />
                </CardContent>
            </Card>

            {/* Daily Spinner Card - Moved here with matching styling */}
            <Card className="bg-white rounded-2xl shadow-lg border-2 border-[var(--color-border-blue)]/30">
              <CardHeader>
                <CardTitle className="text-sky-800 text-2xl font-bold tracking-tight flex items-center gap-2">🎡 Daily Prize Spinner

              </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">Spin once per day for amazing prizes!</p>
                <Button
                onClick={() => setShowSpinner(true)}
                className="w-full bg-gradient-to-r from-[#ffa400] to-[#ff8c00] text-white text-lg py-6 rounded-2xl hover:shadow-xl transition-all">

                  🎰 Spin Now!
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-8">
            <Card className="bg-white rounded-2xl shadow-lg border-2 border-[var(--color-border-blue)]/30">
              <CardContent className="p-4">
                <div className="rounded-3xl overflow-hidden shadow-lg border-2 border-[var(--color-border-blue)]/30">
                    <LumoCharacter lumoState={lumoState} isSleepTime={isSleepTime} />
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-white rounded-2xl shadow-lg border-2 border-[var(--color-border-blue)]/30">
                <CardContent className="p-4">
                     <EmotionIdentificationGame
                lumoState={lumoState}
                activityLog={activityLog}
                onCorrectGuess={handleCorrectGuess}
                onGuess={handleGuess} />

                </CardContent>
            </Card>

            <Card className="bg-white rounded-2xl shadow-lg border-2 border-[var(--color-border-blue)]/30">
                <CardHeader>
                    <CardTitle className="text-sky-700 text-xl font-bold tracking-tight">Lumo's Needs</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                    <NeedBar label="Thirst" value={lumoState.thirst} icon="💧" />
                    <NeedBar label="Hunger" value={lumoState.hunger} icon="🍎" />
                    <NeedBar label="Hygiene" value={lumoState.cleanliness} icon="🧼" />
                    <NeedBar label="Emotional" value={lumoState.emotional_need || 100} icon="💖" />
                </CardContent>
            </Card>

            {/* Announcements Card - Moved here */}
            {announcements.length > 0 &&
          <Card className="bg-white rounded-2xl shadow-lg border-2 border-[var(--color-primary-teal)]/30">
                <CardHeader>
                  <CardTitle className="text-[#1165b3] text-xl font-bold tracking-tight">📢 Special Announcements</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {announcements.map((announcement) =>
              <div key={announcement.id} className="p-4 rounded-xl bg-gradient-to-r from-[#e0f8f5] to-white border-2 border-[#66bfad]/30">
                      <div className="flex items-start gap-3">
                        <div className="text-3xl">{announcement.icon || "📢"}</div>
                        <div className="flex-1">
                          <h4 className="font-bold text-[#1165b3] mb-1">{announcement.title}</h4>
                          <p className="text-gray-700 text-sm">{announcement.message}</p>
                        </div>
                      </div>
                    </div>
              )}
                </CardContent>
              </Card>
          }
          </div>
        </div>

        {/* Spinner Modal */}
        {showSpinner &&
      <DailySpinner
        user={user}
        lumoState={lumoState}
        onClose={() => setShowSpinner(false)}
        onPrizeWon={loadData} />

      }
    </div>);
}