import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, AlertTriangle, CheckCircle, XCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function BackendRebuildGuide() {
  const navigate = useNavigate();

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdminPanel"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1165b3]">Backend Rebuild Guide</h1>
          <p className="text-gray-600">Complete instructions for Adventure Academy rebuild</p>
        </div>
      </div>

      {/* Executive Summary */}
      <Card className="mb-6 border-2 border-orange-300">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-orange-600">
            <AlertTriangle className="w-6 h-6" />
            Executive Summary
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p><strong>Problem:</strong> Adventure Academy is not recognizing `type: "match"` from HealthQuest JSON, causing all matching games to fail.</p>
          <p><strong>Solution:</strong> Complete backend rebuild that:</p>
          <ul className="list-disc pl-6 space-y-1">
            <li>✅ Deletes problematic backend files</li>
            <li>✅ Keeps all working frontend game components</li>
            <li>✅ Rebuilds API to accept HealthQuest JSON as source of truth</li>
            <li>✅ Adds `game_style` assignment only (no data transformation)</li>
          </ul>
        </CardContent>
      </Card>

      {/* Phase 1: File Cleanup */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Phase 1: File Cleanup</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Delete Backend Files */}
          <div>
            <h3 className="text-lg font-bold text-red-600 flex items-center gap-2 mb-3">
              <XCircle className="w-5 h-5" />
              DELETE These Backend Files
            </h3>
            <div className="bg-red-50 border-2 border-red-200 rounded-lg p-4 space-y-2">
              <p className="font-mono text-sm">functions/healthQuestBridge.js - Transforms data incorrectly</p>
              <p className="font-mono text-sm">functions/lessonTransformer.js - Restructures options array</p>
              <p className="font-mono text-sm">functions/matchingGameParser.js - Creates left/right split</p>
              <p className="font-mono text-sm">functions/legacyLessonImport.js - Old import logic</p>
            </div>
          </div>

          {/* Delete Frontend Files */}
          <div>
            <h3 className="text-lg font-bold text-red-600 flex items-center gap-2 mb-3">
              <XCircle className="w-5 h-5" />
              DELETE These Frontend Files (Redundant)
            </h3>
            <div className="bg-red-50 border-2 border-red-200 rounded-lg p-4 space-y-2">
              <p className="font-mono text-sm">components/games/PinMountainMatchingSession.jsx - Pin Mountain is MCQ only</p>
              <p className="font-mono text-sm">components/games/GlassBridgeMatchingSession.jsx - Glass Bridge is MCQ only</p>
              <p className="font-mono text-sm">components/games/MatchingGame.jsx - Duplicate of MatchingBubbleGame</p>
            </div>
            <p className="text-sm text-gray-600 mt-2">
              <strong>Why?</strong> Pin Mountain climbing = MCQ progression. Glass Bridge stepping = MCQ choices. Both are incompatible with matching mechanics.
            </p>
          </div>

          {/* Keep These Files */}
          <div>
            <h3 className="text-lg font-bold text-green-600 flex items-center gap-2 mb-3">
              <CheckCircle className="w-5 h-5" />
              KEEP These Files (Working Correctly)
            </h3>
            <div className="bg-green-50 border-2 border-green-200 rounded-lg p-4 space-y-2">
              <p className="font-mono text-sm">components/games/BubbleGameSession.jsx - MCQ/Assessment game</p>
              <p className="font-mono text-sm">components/games/MatchingBubbleGame.jsx - Universal matching game</p>
              <p className="font-mono text-sm">components/games/SlidingMatchGame.jsx - Drag & drop matching</p>
              <p className="font-mono text-sm">components/games/ConnectDotsMatchGame.jsx - Line-drawing matching</p>
              <p className="font-mono text-sm">components/games/PinMountainSession.jsx - MCQ game only</p>
              <p className="font-mono text-sm">components/games/GlassBridgeSession.jsx - MCQ game only</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Phase 2: HealthQuest JSON Structure */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Phase 2: Understanding HealthQuest JSON</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-4">
            <h3 className="font-bold mb-2">Source of Truth: HealthQuest JSON</h3>
            <p className="text-sm text-gray-700 mb-3">HealthQuest sends lessons with:</p>
            <ul className="list-disc pl-6 space-y-1 text-sm">
              <li><code>type: "mcq"</code> for multiple choice questions</li>
              <li><code>type: "match"</code> for matching pairs</li>
              <li><code>type: "likert"</code> for scaled assessments</li>
            </ul>
          </div>

          <div className="bg-yellow-50 border-2 border-yellow-300 rounded-lg p-4">
            <h3 className="font-bold mb-2">Matching Format (HealthQuest)</h3>
            <pre className="text-xs bg-white p-3 rounded overflow-x-auto">
{`{
  "question": "Match the sense to the food experience.",
  "type": "match",
  "options": [
    { 
      "ans": "Sight",
      "matching_answer": { "answerId": "match_0", "group": "left" }
    },
    {
      "ans": "Colors on a plate",
      "matching_answer": { "answerId": "match_0", "group": "right" }
    }
  ]
}`}
            </pre>
          </div>
        </CardContent>
      </Card>

      {/* Phase 3: New Import Function */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Phase 3: New Import Function (importLessons.js)</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-purple-50 border-2 border-purple-200 rounded-lg p-4">
            <h3 className="font-bold mb-2">Key Responsibilities:</h3>
            <ul className="list-disc pl-6 space-y-2 text-sm">
              <li>Accept HealthQuest JSON as-is (NO transformation)</li>
              <li>Store `questions` array exactly as received</li>
              <li>Auto-detect `type` from first question (mcq/match/likert)</li>
              <li>Assign `game_style` based on admin selection or random</li>
              <li>Create 3 versions per lesson (bubble_pop, pin_mountain, glass_bridge for MCQ)</li>
              <li>Create 3 versions per matching lesson (bubble_pop, sliding_match, connect_dots)</li>
            </ul>
          </div>

          <div className="bg-gray-50 border-2 border-gray-200 rounded-lg p-4">
            <h3 className="font-bold mb-2">Game Style Assignment Logic:</h3>
            <pre className="text-xs bg-white p-3 rounded overflow-x-auto">
{`// For MCQ lessons
const mcqStyles = ['bubble_pop', 'pin_mountain', 'glass_bridge'];

// For Matching lessons
const matchStyles = ['bubble_pop', 'sliding_match', 'connect_dots'];

// For Assessments (pre/post/reflection)
const assessmentStyle = 'bubble_pop'; // ALWAYS bubble_pop`}
            </pre>
          </div>
        </CardContent>
      </Card>

      {/* Phase 4: GameSessionRouter */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Phase 4: GameSessionRouter Logic</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-green-50 border-2 border-green-200 rounded-lg p-4">
            <h3 className="font-bold mb-2">✅ Current Implementation (Correct)</h3>
            <ul className="list-disc pl-6 space-y-2 text-sm">
              <li>All assessments forced to bubble_pop (regardless of game_style)</li>
              <li>MCQ lessons: bubble_pop, pin_mountain, or glass_bridge</li>
              <li>Matching lessons: bubble_pop, sliding_match, or connect_dots</li>
              <li>No Pin Mountain or Glass Bridge matching (correctly removed)</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Testing Guide */}
      <Card>
        <CardHeader>
          <CardTitle>Phase 5: Testing Checklist</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-start gap-2">
              <input type="checkbox" className="mt-1" />
              <span className="text-sm">Import MCQ lesson → Verify 3 game styles created (bubble_pop, pin_mountain, glass_bridge)</span>
            </div>
            <div className="flex items-start gap-2">
              <input type="checkbox" className="mt-1" />
              <span className="text-sm">Import matching lesson → Verify 3 game styles created (bubble_pop, sliding_match, connect_dots)</span>
            </div>
            <div className="flex items-start gap-2">
              <input type="checkbox" className="mt-1" />
              <span className="text-sm">Import pre-assessment → Verify only bubble_pop created</span>
            </div>
            <div className="flex items-start gap-2">
              <input type="checkbox" className="mt-1" />
              <span className="text-sm">Play bubble_pop MCQ → Verify questions display correctly</span>
            </div>
            <div className="flex items-start gap-2">
              <input type="checkbox" className="mt-1" />
              <span className="text-sm">Play bubble_pop matching → Verify pairs match correctly</span>
            </div>
            <div className="flex items-start gap-2">
              <input type="checkbox" className="mt-1" />
              <span className="text-sm">Play sliding_match → Verify drag & drop works</span>
            </div>
            <div className="flex items-start gap-2">
              <input type="checkbox" className="mt-1" />
              <span className="text-sm">Play connect_dots → Verify line-drawing works</span>
            </div>
            <div className="flex items-start gap-2">
              <input type="checkbox" className="mt-1" />
              <span className="text-sm">Complete lesson → Verify rewards (XP/coins) are awarded</span>
            </div>
            <div className="flex items-start gap-2">
              <input type="checkbox" className="mt-1" />
              <span className="text-sm">Check LessonCompletion entity → Verify record created</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}