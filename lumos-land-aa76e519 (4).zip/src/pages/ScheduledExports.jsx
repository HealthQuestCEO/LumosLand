import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Calendar, Mail, Webhook, Cloud, Copy, CheckCircle2, AlertCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function ScheduledExports() {
  const navigate = useNavigate();
  const [deliveryMethod, setDeliveryMethod] = useState('email');
  const [recipients, setRecipients] = useState('');
  const [webhookUrl, setWebhookUrl] = useState('');
  const [schedulerUrl, setSchedulerUrl] = useState('');
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    // Generate the scheduler URL
    const baseUrl = window.location.origin;
    const url = `${baseUrl}/api/scheduledExport`;
    setSchedulerUrl(url);
  }, []);

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(schedulerUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const handleTestExport = async () => {
    setIsTesting(true);
    setTestResult(null);

    try {
      const payload = {
        deliveryMethod,
        recipients: recipients ? recipients.split(',').map(r => r.trim()) : []
      };

      const response = await base44.functions.invoke('scheduledExport', payload);
      
      setTestResult({
        success: true,
        message: response.data.message || 'Export test successful!'
      });
    } catch (error) {
      setTestResult({
        success: false,
        message: error.message || 'Export test failed'
      });
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("AdminPanel"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1165b3]">Scheduled Exports</h1>
          <p className="text-gray-600">Automate data exports to HealthQuest</p>
        </div>
      </div>

      {/* Configuration */}
      <Card className="mb-6 border-2 border-[#66bfad]">
        <CardHeader className="bg-gradient-to-r from-[#66bfad] to-[#1165b3] text-white">
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-6 h-6" />
            Export Configuration
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          {/* Delivery Method */}
          <div className="space-y-2">
            <Label>Delivery Method</Label>
            <Select value={deliveryMethod} onValueChange={setDeliveryMethod}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="email">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    Email (as attachment)
                  </div>
                </SelectItem>
                <SelectItem value="webhook">
                  <div className="flex items-center gap-2">
                    <Webhook className="w-4 h-4" />
                    HealthQuest Webhook
                  </div>
                </SelectItem>
                <SelectItem value="storage">
                  <div className="flex items-center gap-2">
                    <Cloud className="w-4 h-4" />
                    Cloud Storage
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Email Recipients */}
          {deliveryMethod === 'email' && (
            <div className="space-y-2">
              <Label>Email Recipients (comma-separated)</Label>
              <Input
                placeholder="admin@healthquest.com, dev@healthquest.com"
                value={recipients}
                onChange={(e) => setRecipients(e.target.value)}
              />
              <p className="text-xs text-gray-500">
                Exports will be sent as JSON attachments to these email addresses
              </p>
            </div>
          )}

          {/* Webhook URL */}
          {deliveryMethod === 'webhook' && (
            <div className="space-y-2">
              <Label>HealthQuest Webhook URL</Label>
              <Input
                placeholder="https://api.healthquest.com/webhooks/lumo-export"
                value={webhookUrl}
                onChange={(e) => setWebhookUrl(e.target.value)}
              />
              <p className="text-xs text-gray-500">
                Export data will be POSTed to this endpoint as JSON
              </p>
            </div>
          )}

          {/* Test Button */}
          <Button
            onClick={handleTestExport}
            disabled={isTesting}
            className="w-full bg-[#ffa400]"
          >
            {isTesting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                Testing Export...
              </>
            ) : (
              'Test Export Now'
            )}
          </Button>

          {/* Test Result */}
          {testResult && (
            <Alert className={testResult.success ? "bg-green-50 border-green-300" : "bg-red-50 border-red-300"}>
              {testResult.success ? (
                <CheckCircle2 className="h-4 w-4 text-green-600" />
              ) : (
                <AlertCircle className="h-4 w-4 text-red-600" />
              )}
              <AlertDescription className={testResult.success ? "text-green-800" : "text-red-800"}>
                {testResult.message}
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Scheduling Options */}
      <Card className="mb-6 border-2 border-[#ffa400]">
        <CardHeader className="bg-gradient-to-r from-[#ffa400] to-[#ff8c00] text-white">
          <CardTitle>⏰ Schedule Automated Exports</CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <Alert className="bg-blue-50 border-blue-300">
            <AlertCircle className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-800">
              <strong>Use External Cron Service:</strong> Copy the URL below and set up a scheduled job using a service like:
              <ul className="list-disc list-inside mt-2 ml-4 space-y-1">
                <li><strong>cron-job.org</strong> (Free, easy UI)</li>
                <li><strong>GitHub Actions</strong> (If using GitHub)</li>
                <li><strong>Zapier/Make</strong> (No-code automation)</li>
                <li><strong>HealthQuest's Scheduler</strong> (If they have one)</li>
              </ul>
            </AlertDescription>
          </Alert>

          <div className="space-y-2">
            <Label>Scheduler Endpoint URL</Label>
            <div className="flex gap-2">
              <Input
                value={schedulerUrl}
                readOnly
                className="font-mono text-sm"
              />
              <Button onClick={handleCopyUrl} variant="outline">
                {copiedUrl ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </Button>
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg border">
            <h4 className="font-bold mb-2">📝 Setup Instructions:</h4>
            <ol className="list-decimal list-inside space-y-2 text-sm">
              <li>Copy the endpoint URL above</li>
              <li>Go to <a href="https://cron-job.org" target="_blank" className="text-blue-600 underline">cron-job.org</a> (or your preferred service)</li>
              <li>Create a new cron job with this URL</li>
              <li>Set schedule (e.g., "Every day at 2 AM")</li>
              <li>Add header: <code className="bg-gray-200 px-2 py-1 rounded">Authorization: Bearer YOUR_SECRET</code></li>
              <li>Set body to JSON with your config (delivery method, recipients)</li>
            </ol>
          </div>

          <div className="bg-yellow-50 p-4 rounded-lg border-2 border-yellow-300">
            <h4 className="font-bold text-yellow-900 mb-2">🔐 Security Note:</h4>
            <p className="text-sm text-yellow-800">
              You'll need to set a <code className="bg-yellow-200 px-2 py-1 rounded">SCHEDULER_SECRET</code> environment variable 
              in your Base44 app settings. Use this secret in the Authorization header when calling the endpoint.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Recommended Schedules */}
      <Card className="border-2 border-purple-300">
        <CardHeader>
          <CardTitle className="text-purple-900">💡 Recommended Schedules</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
            <h4 className="font-bold text-purple-900">Daily Export (2 AM)</h4>
            <p className="text-sm text-purple-700">Good for: Regular backups, HealthQuest sync</p>
            <code className="text-xs bg-purple-100 px-2 py-1 rounded mt-1 block">0 2 * * *</code>
          </div>

          <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
            <h4 className="font-bold text-purple-900">Weekly Export (Sunday 2 AM)</h4>
            <p className="text-sm text-purple-700">Good for: Weekly reports, less frequent updates</p>
            <code className="text-xs bg-purple-100 px-2 py-1 rounded mt-1 block">0 2 * * 0</code>
          </div>

          <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
            <h4 className="font-bold text-purple-900">Real-time (After Changes)</h4>
            <p className="text-sm text-purple-700">Good for: Immediate HealthQuest sync</p>
            <p className="text-xs text-purple-600 mt-1">Trigger webhook after lesson import/update</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}