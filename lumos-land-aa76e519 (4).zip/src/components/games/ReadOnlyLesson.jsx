import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { X, CheckCircle, Book, Lightbulb, Trophy } from "lucide-react";

/**
 * ReadOnlyLesson - Shows completed lesson with score and takeaways
 * User can review what they learned without playing again
 */
export default function ReadOnlyLesson({ lesson, completion, onClose }) {
  const scorePercentage = completion.total_questions > 0 
    ? Math.round((completion.score / completion.total_questions) * 100)
    : 0;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl shadow-2xl max-w-3xl w-full my-8"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-[#66bfad] to-[#1165b3] text-white p-6 rounded-t-3xl">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle className="w-6 h-6" />
                <span className="text-sm font-semibold bg-white/20 px-3 py-1 rounded-full">
                  COMPLETED
                </span>
                {lesson.is_assessment && (
                  <span className="text-sm font-semibold bg-purple-500 px-3 py-1 rounded-full">
                    {lesson.assessment_type}
                  </span>
                )}
              </div>
              <h2 className="text-2xl md:text-3xl font-bold mb-1">{lesson.name}</h2>
              <p className="text-white/90">{lesson.description}</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="text-white hover:bg-white/20"
            >
              <X className="w-6 h-6" />
            </Button>
          </div>
        </div>

        <CardContent className="p-6 space-y-6">
          {/* Score Card */}
          <Card className="border-2 border-[#66bfad]/30 bg-gradient-to-br from-green-50 to-teal-50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Trophy className="w-6 h-6 text-yellow-600" />
                    <h3 className="text-xl font-bold text-gray-800">Your Score</h3>
                  </div>
                  <p className="text-3xl font-bold text-[#1165b3]">
                    {completion.score} / {completion.total_questions}
                  </p>
                  <p className="text-lg text-gray-600">{scorePercentage}% Correct</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-600 mb-1">Rewards Earned</p>
                  <div className="flex flex-col gap-1">
                    <span className="text-lg font-bold text-[#ffa400]">
                      🪙 {completion.coins_earned} Coins
                    </span>
                    <span className="text-lg font-bold text-[#1165b3]">
                      ⚡ {completion.xp_earned} XP
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Lesson Text */}
          {lesson.lessonText && (
            <Card className="border-2 border-[#00d1ff]/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-[#1165b3]">
                  <Book className="w-5 h-5" />
                  What You Learned
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                  {lesson.lessonText}
                </p>
              </CardContent>
            </Card>
          )}

          {/* Key Takeaways */}
          {lesson.keyTakeaways && (
            <Card className="border-2 border-[#ffa400]/30 bg-gradient-to-br from-orange-50 to-yellow-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-[#1165b3]">
                  <Lightbulb className="w-5 h-5 text-[#ffa400]" />
                  Key Takeaways
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {lesson.keyTakeaways.split('\n').filter(line => line.trim()).map((takeaway, index) => (
                    <div key={index} className="flex items-start gap-2">
                      <span className="text-[#ffa400] mt-1">✓</span>
                      <p className="text-gray-700 flex-1">{takeaway.replace(/^[•\-]\s*/, '')}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Completion Date */}
          <div className="text-center text-sm text-gray-500">
            Completed on {new Date(completion.completed_date).toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'long',
              day: 'numeric'
            })}
          </div>

          {/* Close Button */}
          <Button
            onClick={onClose}
            className="w-full bg-gradient-to-r from-[#66bfad] to-[#1165b3] text-white text-lg py-6 rounded-xl hover:shadow-xl transition-all"
          >
            Close Review
          </Button>
        </CardContent>
      </motion.div>
    </div>
  );
}