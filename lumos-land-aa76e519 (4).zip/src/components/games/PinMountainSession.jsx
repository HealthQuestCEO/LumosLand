
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function PinMountainSession({ lessonData, onComplete, onExit }) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [currentPinPosition, setCurrentPinPosition] = useState(0); // 0-5 (0=start, 5=top)
  const [score, setScore] = useState(0);
  const [wrongAnswers, setWrongAnswers] = useState(0);
  const [coinsEarned, setCoinsEarned] = useState(0);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [hideQuestion, setHideQuestion] = useState(false);
  const [isClimbing, setIsClimbing] = useState(false);
  const [gameComplete, setGameComplete] = useState(false);

  const currentQ = lessonData?.questions?.[currentQuestionIndex];
  const totalQuestions = Math.min(lessonData?.questions?.length || 5, 5); // Max 5 questions
  const isLastQuestion = currentQuestionIndex === totalQuestions - 1;

  const extractText = (value) => {
    if (!value) return "";
    if (typeof value === 'string') return value;
    if (typeof value === 'number') return String(value);
    if (typeof value === 'object') {
      if (value.text) return extractText(value.text);
      if (value.ans) return extractText(value.ans);
      if (value.value) return extractText(value.value);
    }
    return String(value);
  };

  let options = [];
  if (currentQ?.options && Array.isArray(currentQ.options)) {
    options = currentQ.options.map(opt => extractText(opt));
  } else if (currentQ?.answers && Array.isArray(currentQ.answers)) {
    options = currentQ.answers.map(ans => extractText(ans.text || ans.answer || ans));
  }

  const handleAnswer = (answerIndex) => {
    if (showFeedback || isClimbing || hideQuestion) return;

    let correct = false;
    if (currentQ.answer !== undefined) {
      correct = answerIndex === (currentQ.answer - 1);
    } else if (currentQ.answers && Array.isArray(currentQ.answers)) {
      correct = currentQ.answers[answerIndex]?.correct === true;
    }

    setIsCorrect(correct);
    setHideQuestion(true);

    if (correct) {
      // CORRECT - Climb to next pin
      setScore(score + 1);
      if (!lessonData.is_assessment) {
        setCoinsEarned(coinsEarned + (lessonData.coins_per_correct || 10));
      }
      
      setTimeout(() => {
        setIsClimbing(true);
        setCurrentPinPosition(currentPinPosition + 1);
        
        setTimeout(() => {
          setIsClimbing(false);
          setShowFeedback(false);
          
          if (isLastQuestion) {
            setGameComplete(true);
            setTimeout(() => {
              onComplete({
                correctAnswers: score + 1,
                totalQuestions: totalQuestions,
              });
            }, 2000);
          } else {
            setCurrentQuestionIndex(currentQuestionIndex + 1);
            setHideQuestion(false);
          }
        }, 1500);
      }, 500);
    } else {
      // WRONG - Stay at current pin
      setWrongAnswers(wrongAnswers + 1);
      
      setTimeout(() => {
        setShowFeedback(false);
        
        if (isLastQuestion) {
          setGameComplete(true);
          setTimeout(() => {
            onComplete({
              correctAnswers: score,
              totalQuestions: totalQuestions,
            });
          }, 2000);
        } else {
          setCurrentQuestionIndex(currentQuestionIndex + 1);
          setHideQuestion(false);
        }
      }, 1500);
    }
  };

  // Calculate Lumo size based on CURRENT PIN position (not question number)
  // Start: 4x (400px) → Top: 1x (100px)
  const baseLumoSize = 100;
  const lumoScale = 4 - (currentPinPosition * 0.6); // 4, 3.4, 2.8, 2.2, 1.6, 1.0
  const lumoSize = baseLumoSize * lumoScale;

  // Pin positions along 30° diagonal (lower-left to upper-right)
  const pinPositions = [
    { left: 10, bottom: 8 },   // Start
    { left: 25, bottom: 23 },  // Pin 1
    { left: 40, bottom: 38 },  // Pin 2
    { left: 55, bottom: 53 },  // Pin 3
    { left: 70, bottom: 68 },  // Pin 4
    { left: 85, bottom: 83 },  // Pin 5 (Top)
  ];

  const currentPosition = pinPositions[currentPinPosition];

  return (
    <div 
      className="relative min-h-screen overflow-hidden"
      style={{
        backgroundImage: `url('https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68e72a9f947d6831aa76e519/a1f955e0c_GreatJob10.png')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      {/* Top Bar */}
      <div className="relative z-10 max-w-6xl mx-auto px-4 pt-6 pb-4">
        <div className="flex justify-between items-center">
          <div className="bg-white/90 backdrop-blur-md rounded-full px-6 py-3 shadow-lg border-2 border-[#00d1ff]">
            <span className="text-lg font-bold text-[#00d1ff]">
              Question {currentQuestionIndex + 1} / {totalQuestions}
            </span>
          </div>

          {!lessonData.is_assessment && (
            <div className="bg-white/90 backdrop-blur-md rounded-full px-6 py-3 shadow-lg flex items-center gap-4">
              <span className="text-lg font-bold text-[#10b981]">✅ {score}</span>
              <div className="w-px h-6 bg-gray-300" />
              <span className="text-lg font-bold text-red-500">❌ {wrongAnswers}</span>
              <div className="w-px h-6 bg-gray-300" />
              <span className="text-lg font-bold text-[#ffa400]">🪙 {coinsEarned}</span>
            </div>
          )}
        </div>
      </div>

      {/* Pin Markers - Visual path up the mountain */}
      <div className="absolute inset-0 pointer-events-none z-10">
        {pinPositions.slice(1).map((pos, index) => (
          <div
            key={index}
            className={`absolute w-8 h-8 rounded-full border-4 flex items-center justify-center transition-all duration-500 ${
              index < currentPinPosition 
                ? 'bg-[#66bfad] border-[#4a9d8a]' 
                : 'bg-gray-300 border-gray-400'
            }`}
            style={{ left: `${pos.left}%`, bottom: `${pos.bottom}%` }}
          >
            <span className="text-lg">{index < currentPinPosition ? '✓' : '📌'}</span>
          </div>
        ))}
      </div>

      {/* Lumo Character - BEHIND question card (z-5) */}
      <AnimatePresence mode="wait">
        <motion.div
          key={`lumo-pin-${currentPinPosition}`}
          className="absolute pointer-events-none z-5"
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{
            left: `${currentPosition.left}%`,
            bottom: `${currentPosition.bottom}%`,
            opacity: 1,
            scale: 1,
            y: gameComplete ? [0, -15, 0, -15, 0] : (isClimbing ? 0 : [-4, 4, -4]),
          }}
          transition={{
            left: { duration: 1.2, ease: "easeInOut" },
            bottom: { duration: 1.2, ease: "easeInOut" },
            opacity: { duration: 0.5 },
            scale: { duration: 0.5 },
            y: {
              duration: gameComplete ? 1 : 2,
              repeat: Infinity,
              ease: "easeInOut"
            }
          }}
          style={{
            width: `${lumoSize}px`,
            height: `${lumoSize}px`,
            transform: 'translate(-50%, 0)'
          }}
        >
          <img
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68e72a9f947d6831aa76e519/ea90d5151_14.png"
            alt="Lumo"
            className="w-full h-full object-contain"
            style={{ 
              filter: 'drop-shadow(0 8px 20px rgba(0,0,0,0.4))',
              transform: 'scaleX(-1)'
            }}
          />
          {/* Only show celebration emoji when game is complete */}
          {gameComplete && currentPinPosition === 5 && (
            <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 text-6xl animate-bounce">
              🎉
            </div>
          )}
        </motion.div>
      </AnimatePresence>

      {/* Question Card - ABOVE Lumo (z-20) */}
      {!hideQuestion && (
        <div className="relative z-20 max-w-4xl mx-auto px-4 pb-8">
          <motion.div 
            initial={{ opacity: 0, y: -20 }} 
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <div className="bg-white/95 backdrop-blur-md rounded-3xl p-6 md:p-8 shadow-2xl border-4 border-[#00d1ff]">
              <h2 className="text-xl md:text-3xl font-bold text-[#2563eb] text-center mb-6">
                {currentQ?.question}
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 md:gap-4">
                {options.map((option, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleAnswer(idx)}
                    className="bg-gradient-to-br from-[#66bfad] to-[#1165b3] hover:from-[#1165b3] hover:to-[#66bfad] text-white p-4 rounded-xl text-base md:text-lg font-semibold transition-all hover:scale-105 hover:shadow-xl border-2 border-[#66bfad] min-h-[60px] flex items-center justify-center"
                  >
                    <span className="text-center break-words">{option}</span>
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* Completion Message */}
      {gameComplete && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="absolute inset-0 flex items-center justify-center z-50 bg-black/30 backdrop-blur-sm"
        >
          <div className="bg-white rounded-3xl p-8 shadow-2xl text-center max-w-md">
            <h2 className="text-4xl font-bold mb-4">
              {currentPinPosition === 5 ? '🏆 You Made It to the Top!' : '🏔️ Great Effort!'}
            </h2>
            <p className="text-2xl text-gray-700 mb-2">
              Score: {score} / {totalQuestions}
            </p>
            <p className="text-lg text-gray-600">
              {currentPinPosition === 5 
                ? 'Perfect climb! You reached the summit!' 
                : `You climbed to pin ${currentPinPosition}!`}
            </p>
          </div>
        </motion.div>
      )}
    </div>
  );
}
