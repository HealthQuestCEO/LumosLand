
import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Target, CheckCircle } from "lucide-react";

/**
 * Helper to extract text from nested objects
 */
function extractText(value) {
  if (typeof value === 'string') return value;
  if (typeof value === 'number') return String(value);
  if (!value) return '';
  
  if (typeof value === 'object') {
    if (value.ques || value.ans || value.question || value.answer) {
      return extractText(value.ques || value.ans || value.question || value.answer);
    }
    const textProps = ['text', 'displayText', 'value', 'content', 'label'];
    for (const prop of textProps) {
      if (value[prop]) return extractText(value[prop]);
    }
  }
  
  return '';
}

/**
 * Parse matching pairs from lesson data
 */
function parseMatchingPairs(options) {
  if (!Array.isArray(options) || options.length === 0) {
    return [];
  }
  
  const firstOption = options[0];
  
  // Format 1: Base44 String Format
  if (firstOption?.matching_answer && typeof firstOption.matching_answer === 'string') {
    return options.map((option, index) => ({
      id: `pair_${index}`,
      left: extractText(option.ans),
      right: extractText(option.matching_answer)
    })).filter(pair => pair.left && pair.right);
  }
  
  // Format 2: HealthQuest Object Format
  if (firstOption?.matching_answer?.answerId) {
    const pairsMap = {};
    
    options.forEach((option) => {
      if (!option.matching_answer?.answerId) return;
      
      const answerId = option.matching_answer.answerId;
      const group = option.matching_answer.group;
      const text = extractText(option.ans);
      
      if (!pairsMap[answerId]) {
        pairsMap[answerId] = { id: answerId };
      }
      
      if (group === 'left') {
        pairsMap[answerId].left = text;
      } else if (group === 'right') {
        pairsMap[answerId].right = text;
      }
    });
    
    return Object.values(pairsMap).filter(pair => pair.left && pair.right);
  }
  
  return [];
}

/**
 * Sliding Match Game - Drag cards from left column to match with right column
 */
export default function SlidingMatchGame({ lessonData, gameConfig, onComplete, onExit }) {
  const currentQ = lessonData?.questions?.[0] || lessonData;
  const pairs = parseMatchingPairs(currentQ?.options || []);
  const questionText = currentQ?.questionText || currentQ?.question || "Match the pairs by sliding";
  
  const [matches, setMatches] = useState({}); // Stores {pairId: pairId}
  const [draggedItem, setDraggedItem] = useState(null); // Stores pairId of dragged item
  const [wrongMatch, setWrongMatch] = useState(null); // Stores {leftId, rightId}
  const [showSuccess, setShowSuccess] = useState(false);
  const [celebrateMatch, setCelebrateMatch] = useState(null); // Stores rightId to celebrate
  
  // ✅ REVERT: Use simple pair IDs
  const leftItems = pairs.map(p => ({ id: p.id, text: p.left }));
  const rightItems = pairs.map(p => ({ id: p.id, text: p.right }));
  
  const shuffledLeft = React.useMemo(() => [...leftItems].sort(() => Math.random() - 0.5), [pairs.length]);
  const shuffledRight = React.useMemo(() => [...rightItems].sort(() => Math.random() - 0.5), [pairs.length]);
  
  const matchedCount = Object.keys(matches).length;
  const allMatched = matchedCount === pairs.length;

  const lumoUrl = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68e72a9f947d6831aa76e519/0a40a0a5c_Happy13.png";

  if (pairs.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-50 to-orange-50 p-4">
        <div className="bg-white rounded-3xl p-8 shadow-2xl max-w-md text-center">
          <div className="text-6xl mb-4">⚠️</div>
          <h2 className="text-2xl font-bold text-red-600 mb-4">No Matching Pairs Found</h2>
          <p className="text-gray-600 mb-4">Please check the lesson data format or ensure there are options to match.</p>
          <Button onClick={onExit} className="bg-red-500 text-white px-6 py-2 rounded-lg hover:bg-red-600">
            Exit
          </Button>
        </div>
      </div>
    );
  }

  const handleDragStart = (e, leftId) => {
    const item = shuffledLeft.find(i => i.id === leftId);
    if (!item || matches[item.id]) {
      e.preventDefault();
      return;
    }
    setDraggedItem(leftId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e, rightId) => {
    e.preventDefault();
    if (!draggedItem) return;
    
    const leftItem = shuffledLeft.find(i => i.id === draggedItem);
    const rightItem = shuffledRight.find(i => i.id === rightId);

    if (!leftItem || !rightItem) {
        setDraggedItem(null);
        return;
    }
    
    const leftPairId = leftItem.id;
    const rightPairId = rightItem.id;
    
    const isCorrect = leftPairId === rightPairId;
    
    if (isCorrect) {
      setMatches({ ...matches, [leftPairId]: rightPairId });
      setDraggedItem(null);
      
      setCelebrateMatch(rightId);
      setTimeout(() => setCelebrateMatch(null), 1000);
    } else {
      setWrongMatch({ leftId: draggedItem, rightId: rightId });
      setTimeout(() => {
        setWrongMatch(null);
        setDraggedItem(null);
      }, 600);
    }
  };

  const handleComplete = () => {
    setShowSuccess(true);
    setTimeout(() => {
      onComplete({
        correctAnswers: pairs.length,
        totalQuestions: pairs.length,
        coinsEarned: lessonData.coins_reward || 50,
        xpEarned: lessonData.xp_reward || 50
      });
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-100 via-cyan-50 to-blue-50 p-4 relative overflow-hidden">
      {/* Large Translucent Lumo Background */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <img 
          src={lumoUrl}
          alt="Lumo"
          className="w-[600px] h-[600px] object-contain opacity-10"
        />
      </div>

      {/* Header */}
      <div className="relative z-10 max-w-6xl mx-auto mb-6">
        <div className="bg-white shadow-sm rounded-2xl p-4 flex justify-between items-center">
          <Button variant="ghost" onClick={onExit} className="gap-2">
            <ArrowLeft className="w-5 h-5" />
            Back
          </Button>
          <h1 className="text-xl font-bold text-[#374151]">Lumo's Match Quest</h1>
          <div className="flex items-center gap-2 bg-[#66bfad] text-white px-4 py-2 rounded-full font-bold">
            🎯 {matchedCount}/{pairs.length}
          </div>
        </div>
      </div>

      {/* Question Card */}
      <div className="relative z-10 max-w-4xl mx-auto mb-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white border-4 border-[#1165b3] rounded-2xl p-6 shadow-xl"
        >
          <h2 className="text-2xl md:text-3xl font-bold text-[#374151] text-center">
            {questionText}
          </h2>
          <p className="text-center text-[#6b7280] mt-2">Drag cards from Column A to Column B to match them</p>
        </motion.div>
      </div>

      {/* Matching Grid */}
      <div className="relative z-10 max-w-5xl mx-auto grid md:grid-cols-2 gap-8">
        {/* Column A (Left - Draggable) */}
        <div className="space-y-2">
          <div className="bg-gradient-to-r from-[#66bfad] to-[#00d1ff] text-white text-center py-3 rounded-t-lg font-bold text-lg">
            COLUMN A
          </div>
          <div className="space-y-3">
            {shuffledLeft.map((item, idx) => {
              const isMatched = matches[item.id]; // Check against original pair ID
              const isDragging = draggedItem === item.id;
              const isWrong = wrongMatch?.leftId === item.id;

              return (
                <motion.div
                  key={item.id} // Use item.id for key
                  draggable={!isMatched}
                  onDragStart={(e) => handleDragStart(e, item.id)} // Pass item.id
                  initial={{ opacity: 0, x: -50 }}
                  animate={{ 
                    opacity: isMatched ? 0.4 : 1, 
                    x: 0,
                    scale: isDragging ? 1.05 : 1
                  }}
                  transition={{ delay: idx * 0.1 }}
                  className={`
                    bg-white border-2 rounded-xl p-4 shadow-md min-h-[80px] flex items-center
                    ${isMatched ? 'border-[#9ca3af] cursor-not-allowed' : 'border-[#e5e7eb] cursor-move hover:border-[#66bfad] hover:shadow-lg'}
                    ${isDragging ? 'opacity-50' : ''}
                    ${isWrong ? 'border-[#ef4444] bg-red-50' : ''}
                    transition-all
                  `}
                >
                  <div className="flex-1">
                    <p className="text-lg font-semibold text-[#374151]">{item.text}</p>
                  </div>
                  {isMatched && <CheckCircle className="w-6 h-6 text-[#10b981] ml-2" />}
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Column B (Right - Drop Targets) */}
        <div className="space-y-2">
          <div className="bg-gradient-to-r from-[#66bfad] to-[#00d1ff] text-white text-center py-3 rounded-t-lg font-bold text-lg">
            COLUMN B
          </div>
          <div className="space-y-3">
            {shuffledRight.map((item, idx) => {
              const isMatched = matches[item.id]; // Check if this item's ID is a key in matches
              const isWrong = wrongMatch?.rightId === item.id;
              const isCelebrating = celebrateMatch === item.id;

              return (
                <motion.div
                  key={item.id} // Use item.id for key
                  onDragOver={handleDragOver}
                  onDrop={(e) => handleDrop(e, item.id)} // Pass item.id
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className={`
                    bg-white border-2 rounded-xl p-4 shadow-md min-h-[80px] flex items-center relative
                    ${isMatched ? 'border-[#10b981] bg-green-50' : 'border-[#e5e7eb] border-dashed'}
                    ${isWrong ? 'border-[#ef4444] bg-red-50' : ''}
                    ${draggedItem && !isMatched ? 'border-[#ffa400] bg-orange-50' : ''}
                    transition-all
                  `}
                >
                  <div className="flex-1">
                    <p className="text-lg font-semibold text-[#374151]">{item.text}</p>
                  </div>
                  {isMatched && <CheckCircle className="w-6 h-6 text-[#10b981] ml-2" />}
                  
                  {/* Stars Celebration */}
                  {isCelebrating && (
                    <div className="absolute inset-0 pointer-events-none">
                      {[...Array(5)].map((_, i) => (
                        <motion.div
                          key={i}
                          initial={{ scale: 0, x: 0, y: 0, opacity: 1 }}
                          animate={{ 
                            scale: [0, 1.5, 0],
                            x: (Math.random() - 0.5) * 100,
                            y: (Math.random() - 0.5) * 100,
                            opacity: [1, 1, 0]
                          }}
                          transition={{ duration: 0.8, delay: i * 0.1 }}
                          className="absolute top-1/2 left-1/2 text-3xl"
                        >
                          ⭐
                        </motion.div>
                      ))}
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Complete Button */}
      {allMatched && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative z-10 max-w-md mx-auto mt-8"
        >
          <Button
            onClick={handleComplete}
            className="w-full bg-gradient-to-r from-[#10b981] to-[#66bfad] text-white py-6 rounded-2xl text-xl font-bold shadow-xl hover:shadow-2xl transition-all"
          >
            ✨ Check Answers
          </Button>
        </motion.div>
      )}

      {/* Success Feedback */}
      <AnimatePresence>
        {showSuccess && (
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50"
          >
            <div className="bg-white rounded-3xl p-12 shadow-2xl text-center max-w-md">
              <div className="text-8xl mb-4">🎉</div>
              <h2 className="text-4xl font-bold text-[#10b981] mb-2">Perfect Match!</h2>
              <p className="text-xl text-gray-600">All pairs matched correctly!</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mascot Hint */}
      <div className="relative z-10 max-w-4xl mx-auto mt-8">
        <div className="bg-white/80 backdrop-blur rounded-2xl p-4 border-2 border-[#ffa400] flex items-center gap-3">
          <img 
            src={lumoUrl} 
            alt="Lumo" 
            className="h-16 w-auto object-contain flex-shrink-0"
          />
          <p className="text-[#374151] font-medium">
            <strong>Lumo says:</strong> Drag cards from Column A and drop them on Column B to make matches!
          </p>
        </div>
      </div>
    </div>
  );
}
