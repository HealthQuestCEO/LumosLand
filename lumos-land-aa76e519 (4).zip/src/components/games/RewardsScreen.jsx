import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trophy, Coins, Zap, CheckCircle2 } from "lucide-react";

export default function RewardsScreen({ results, lesson, isReviewMode, error, onContinue }) {
  const { correctAnswers, totalQuestions, coinsEarned, xpEarned } = results;
  const percentage = Math.round((correctAnswers / totalQuestions) * 100);
  
  // ✅ Check if this is an assessment (no right/wrong answers)
  const isAssessment = lesson?.is_assessment === true;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#e0f8f5] to-[#00d1ff]/20 flex items-center justify-center p-4">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="max-w-2xl w-full"
      >
        <Card className="bg-white/95 backdrop-blur-md shadow-2xl border-2 border-[#ffa400]">
          <CardHeader className="text-center pb-4">
            <div className="flex justify-center mb-4">
              <motion.div
                initial={{ rotate: -10, scale: 0 }}
                animate={{ rotate: 0, scale: 1 }}
                transition={{ type: "spring", bounce: 0.5 }}
                className="w-24 h-24 bg-gradient-to-br from-[#ffa400] to-[#ff8c00] rounded-full flex items-center justify-center"
              >
                {isAssessment ? (
                  <CheckCircle2 className="w-12 h-12 text-white" />
                ) : (
                  <Trophy className="w-12 h-12 text-white" />
                )}
              </motion.div>
            </div>
            <CardTitle className="text-4xl font-bold text-[#1165b3]">
              {isAssessment ? (
                "Thank You for Sharing!"
              ) : (
                percentage >= 80 ? "Outstanding!" : percentage >= 60 ? "Great Job!" : "Good Effort!"
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Score Display - Different for assessments vs regular lessons */}
            <div className="bg-gradient-to-br from-[#e0f8f5] to-[#66bfad]/10 rounded-2xl p-6 text-center border-2 border-[#66bfad]/30">
              {isAssessment ? (
                <>
                  <div className="text-6xl mb-4">✅</div>
                  <div className="text-3xl font-bold text-[#1165b3] mb-2">
                    Assessment Complete
                  </div>
                  <p className="text-lg text-gray-600">
                    You completed {totalQuestions} {totalQuestions === 1 ? 'question' : 'questions'}
                  </p>
                  <p className="text-sm text-gray-500 mt-3">
                    {lesson?.assessment_type === 'pre' && 'Your responses help us understand your starting point'}
                    {lesson?.assessment_type === 'post' && 'Your responses help us see your growth'}
                    {lesson?.assessment_type === 'reflection' && 'Your feedback helps us improve'}
                  </p>
                </>
              ) : (
                <>
                  <div className="text-6xl font-bold text-[#1165b3] mb-2">
                    {correctAnswers}/{totalQuestions}
                  </div>
                  <p className="text-lg text-gray-600">Correct Answers</p>
                  <div className="mt-4 flex justify-center gap-1">
                    {[...Array(totalQuestions)].map((_, i) => (
                      <div
                        key={i}
                        className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          i < correctAnswers 
                            ? "bg-[#ffa400] text-white" 
                            : "bg-gray-300 text-gray-500"
                        }`}
                      >
                        {i < correctAnswers ? "✓" : "○"}
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>

            {/* Rewards */}
            {!isReviewMode && (coinsEarned > 0 || xpEarned > 0) && (
              <div className="grid grid-cols-2 gap-4">
                {coinsEarned > 0 && (
                  <motion.div
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.2 }}
                    className="bg-gradient-to-br from-[#ffa400] to-[#ff8c00] rounded-2xl p-6 text-center text-white"
                  >
                    <Coins className="w-8 h-8 mx-auto mb-2" />
                    <div className="text-3xl font-bold">+{coinsEarned}</div>
                    <p className="text-sm opacity-90">Coins Earned</p>
                  </motion.div>
                )}
                {xpEarned > 0 && (
                  <motion.div
                    initial={{ x: 20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.3 }}
                    className="bg-gradient-to-br from-[#1165b3] to-[#66bfad] rounded-2xl p-6 text-center text-white"
                  >
                    <Zap className="w-8 h-8 mx-auto mb-2" />
                    <div className="text-3xl font-bold">+{xpEarned}</div>
                    <p className="text-sm opacity-90">XP Earned</p>
                  </motion.div>
                )}
              </div>
            )}

            {isReviewMode && (
              <div className="bg-[#00d1ff]/10 border-2 border-[#00d1ff]/30 rounded-2xl p-4 text-center">
                <p className="text-gray-700">
                  This is a review - no additional rewards earned
                </p>
              </div>
            )}

            {error && (
              <div className="bg-red-50 border-2 border-red-300 rounded-2xl p-4 text-center">
                <p className="text-red-700 font-semibold">{error}</p>
              </div>
            )}

            <Button
              onClick={onContinue}
              className="w-full bg-gradient-to-r from-[#66bfad] to-[#1165b3] text-white py-6 text-lg rounded-2xl hover:shadow-xl transition-all"
            >
              Continue
            </Button>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}