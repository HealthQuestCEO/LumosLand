import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function GlassBridgeSession({ lessonData, onComplete, onExit }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [wrongAnswers, setWrongAnswers] = useState(0);
  const [coinsEarned, setCoinsEarned] = useState(0);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [hideQuestion, setHideQuestion] = useState(false);
  const [lumoFalling, setLumoFalling] = useState(false);
  const [lumoJumping, setLumoJumping] = useState(false);
  const [visualPosition, setVisualPosition] = useState(0);
  const [wrongPanels, setWrongPanels] = useState([]);
  const [crackedPanel, setCrackedPanel] = useState(null);

  const panelRows = useMemo(() => {
    return Array.from({ length: 5 }, () => Math.random() < 0.5 ? 0 : 1);
  }, []);

  const currentQ = lessonData?.questions?.[currentIndex];
  const totalQuestions = lessonData?.questions?.length || 0;
  const isLastQuestion = currentIndex === totalQuestions - 1;

  const extractText = (value) => {
    if (!value) return "";
    if (typeof value === 'string') return value;
    if (typeof value === 'number') return String(value);
    
    if (typeof value === 'object') {
      if (value.text) return extractText(value.text);
      if (value.displayText) return extractText(value.displayText);
      if (value.ans) return extractText(value.ans);
      if (value.answer) return extractText(value.answer);
      if (value.value) return extractText(value.value);
      if (value.content) return extractText(value.content);
      if (value.label) return extractText(value.label);
    }
    
    return String(value);
  };

  let options = [];
  if (currentQ?.options && Array.isArray(currentQ.options)) {
    options = currentQ.options.map(opt => extractText(opt));
  } else if (currentQ?.answers && Array.isArray(currentQ.answers)) {
    options = currentQ.answers.map(ans => extractText(ans.text || ans.answer || ans));
  }

  const lumoDisplayColumn = visualPosition % 5;
  const lumoDisplayRow = panelRows[lumoDisplayColumn];

  const handleAnswer = (answerIndex) => {
    if (showFeedback || lumoFalling || lumoJumping) return;

    // ✅ FIXED: Proper answer validation (not based on row, based on actual correct answer)
    let correct = false;
    
    // Check if this is the correct answer using the lesson data
    if (currentQ.answer !== undefined) {
      // answer field is 1-indexed in some formats
      correct = (answerIndex + 1) === currentQ.answer || answerIndex === currentQ.answer;
    } else if (currentQ.options && Array.isArray(currentQ.options)) {
      const option = currentQ.options[answerIndex];
      if (typeof option === 'object' && option.isCorrect !== undefined) {
        correct = option.isCorrect === true;
      }
    } else if (currentQ.answers && Array.isArray(currentQ.answers)) {
      const answer = currentQ.answers[answerIndex];
      if (typeof answer === 'object' && answer.correct !== undefined) {
        correct = answer.correct === true;
      }
    }

    setIsCorrect(correct);
    setHideQuestion(true);

    if (correct) {
      setScore(score + 1);
      if (!lessonData.is_assessment) {
        setCoinsEarned(coinsEarned + (lessonData.coins_per_correct || 10));
      }
      
      setLumoJumping(true);
      
      setTimeout(() => {
        setLumoJumping(false);
        setVisualPosition(prevVisualPosition => prevVisualPosition + 1);
        
        setShowFeedback(true);
        setTimeout(() => {
          setShowFeedback(false);
          setHideQuestion(false);

          if (isLastQuestion) {
            onComplete({
              correctAnswers: score + 1,
              totalQuestions: lessonData.questions.length,
            });
          } else {
            setCurrentIndex(prevIndex => prevIndex + 1);
          }
        }, 1500);
      }, 800);
    } else {
      // WRONG ANSWER
      setWrongAnswers(prevWrongAnswers => prevWrongAnswers + 1);
      
      const crackedPanelLinearIndex = lumoDisplayColumn + (lumoDisplayRow * 5);
      setCrackedPanel(crackedPanelLinearIndex);
      setWrongPanels(prevWrongPanels => [...prevWrongPanels, crackedPanelLinearIndex]);

      setLumoJumping(true);
      
      setTimeout(() => {
        setLumoJumping(false);
        setLumoFalling(true);
        
        setTimeout(() => {
          setLumoFalling(false);
          setCrackedPanel(null);
          setVisualPosition(0);
          setHideQuestion(false);
          
          setTimeout(() => {
            if (isLastQuestion) {
              onComplete({
                correctAnswers: score,
                totalQuestions: lessonData.questions.length,
              });
            } else {
              setCurrentIndex(prevIndex => prevIndex + 1);
            }
          }, 800);
        }, 3000);
      }, 1000);
    }
  };

  return (
    <div className="relative min-h-screen overflow-hidden" style={{ backgroundColor: '#75d9f0' }}>
      {/* New Background Image */}
      <div 
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: "url('https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68e72a9f947d6831aa76e519/d95040d45_GreatJob.jpg')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      />

      {/* Top Bar */}
      <div className="relative z-10 max-w-6xl mx-auto px-4 pt-6 pb-4">
        <div className="flex justify-between items-center">
          <div className="bg-white/90 backdrop-blur-md rounded-full px-6 py-3 shadow-lg border-2 border-[#00d1ff]">
            <span className="text-lg font-bold text-[#00d1ff]">Step {currentIndex + 1} / {totalQuestions}</span>
          </div>

          {!lessonData.is_assessment && (
            <div className="bg-white/90 backdrop-blur-md rounded-full px-6 py-3 shadow-lg flex items-center gap-4">
              <span className="text-lg font-bold text-[#10b981]">✅ {score}</span>
              <div className="w-px h-6 bg-gray-300" />
              <span className="text-lg font-bold text-red-500">❌ {wrongAnswers}</span>
              <div className="w-px h-6 bg-gray-300" />
              <span className="text-lg font-bold text-[#ffa400]">🪙 {coinsEarned}</span>
            </div>
          )}
        </div>
      </div>

      {/* Main Bridge Game Area */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 pb-20">
        {/* Question Card */}
        {!hideQuestion && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }} 
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-3xl p-6 shadow-2xl mb-8 border-4 border-[#00d1ff]"
          >
            <h2 className="text-2xl font-bold text-center text-[#1165b3] mb-6">
              {extractText(currentQ?.questionText || currentQ?.question)}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {options.map((option, idx) => (
                <motion.button
                  key={idx}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleAnswer(idx)}
                  className="bg-gradient-to-r from-[#00d1ff] to-[#1165b3] text-white p-4 rounded-2xl text-lg font-bold shadow-xl hover:shadow-2xl transition-all"
                >
                  {option}
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}

        {/* Glass Bridge Grid */}
        <div className="relative w-full" style={{ height: '300px' }}>
          {/* START marker */}
          <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-16 bg-green-500 text-white px-4 py-2 rounded-lg font-bold shadow-lg z-20">
            START
          </div>

          {/* FINISH marker */}
          <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-16 bg-orange-500 text-white px-4 py-2 rounded-lg font-bold shadow-lg z-20">
            FINISH
          </div>

          {/* Bridge panels grid */}
          <div className="grid grid-cols-5 gap-4 relative h-full">
            {Array.from({ length: 10 }).map((_, panelIndex) => {
              const col = panelIndex % 5;
              const row = Math.floor(panelIndex / 5);

              const isCracked = crackedPanel === panelIndex;
              const isWrong = wrongPanels.includes(panelIndex);
              
              const isPassedOrCurrent = col < lumoDisplayColumn || (col === lumoDisplayColumn && row === lumoDisplayRow);
              const isCorrectPathPanel = panelRows[col] === row;

              return (
                <motion.div
                  key={panelIndex}
                  initial={{ opacity: 1, y: 0 }}
                  animate={isCracked ? { opacity: 0, y: 100, transition: { duration: 0.5 } } : { opacity: 1, y: 0, transition: { duration: 0.3 } }}
                  className={`
                    aspect-square rounded-2xl border-4 shadow-xl relative overflow-hidden
                    ${isCracked
                        ? 'bg-red-200/50 border-red-500'
                        : isWrong
                          ? 'bg-yellow-200/50 border-yellow-500'
                          : isPassedOrCurrent && isCorrectPathPanel
                            ? 'bg-green-200/50 border-green-500'
                            : 'bg-white/40 border-[#00d1ff]'
                    }
                  `}
                  style={{
                    backdropFilter: 'blur(10px)',
                  }}
                >
                  <div className="absolute inset-2 border-2 border-white/30 rounded-xl" />
                  
                  {isCracked && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute inset-0 flex items-center justify-center"
                    >
                      <svg className="w-full h-full" viewBox="0 0 100 100">
                        <path d="M20,50 L50,20 M50,20 L80,50 M50,20 L50,80" 
                              stroke="rgba(0,0,0,0.8)" 
                              strokeWidth="2" 
                              fill="none" />
                      </svg>
                      <span className="relative z-10 text-5xl animate-bounce">💥</span>
                    </motion.div>
                  )}
                  {isPassedOrCurrent && isCorrectPathPanel && !isCracked && (
                    <div className="absolute inset-0 flex items-center justify-center text-4xl text-green-700">✓</div>
                  )}
                  {isWrong && !isCracked && (
                    <div className="absolute inset-0 flex items-center justify-center text-4xl text-yellow-700">✗</div>
                  )}
                </motion.div>
              );
            })}

            {/* ✅ Lumo character - BIGGER SIZE (w-52 h-52 instead of w-40 h-40) */}
            {!lumoFalling && (
              <motion.div
                animate={{
                  x: `calc(${lumoDisplayColumn} * (100% / 5) + (100% / 5 / 2))`,
                  y: `calc(${lumoDisplayRow} * (100% / 2) + (100% / 2 / 2))`,
                  scale: lumoJumping ? [1, 1.2, 1] : 1,
                }}
                transition={{ duration: lumoJumping ? 0.8 : 0.5, ease: "easeInOut" }}
                className="absolute w-52 h-52 pointer-events-none z-20"
                style={{
                  filter: 'drop-shadow(0 8px 16px rgba(0,0,0,0.3))',
                  transform: 'translate(-50%, -50%) scaleX(-1)',
                }}
              >
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68e72a9f947d6831aa76e519/0a40a0a5c_Happy13.png"
                  alt="Lumo"
                  className="w-full h-full object-contain"
                />
                {/* ✅ Happy emoji for CORRECT answers */}
                {isCorrect && showFeedback && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="absolute -top-16 left-1/2"
                    style={{ transform: 'translateX(-50%) scaleX(-1)' }}
                  >
                    <div className="text-6xl">😊✨</div>
                  </motion.div>
                )}
              </motion.div>
            )}

            {/* Falling Lumo - Also BIGGER */}
            {lumoFalling && (
              <motion.div
                initial={{ 
                  x: `calc(${lumoDisplayColumn} * (100% / 5) + (100% / 5 / 2))`, 
                  y: `calc(${lumoDisplayRow} * (100% / 2) + (100% / 2 / 2))` 
                }}
                animate={{ y: '200%', opacity: 0 }}
                transition={{ duration: 2, ease: "easeIn" }}
                className="absolute w-52 h-52 pointer-events-none z-20"
                style={{
                  filter: 'drop-shadow(0 8px 16px rgba(0,0,0,0.3))',
                  transform: 'translate(-50%, -50%) scaleX(-1)',
                }}
              >
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68e72a9f947d6831aa76e519/0a40a0a5c_Happy13.png"
                  alt="Lumo falling"
                  className="w-full h-full object-contain"
                />
                {/* Scared emoji for WRONG answers */}
                <div className="absolute -top-16 left-1/2 text-6xl animate-bounce" style={{ transform: 'translateX(-50%) scaleX(-1)' }}>
                  😱
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>

      {/* Feedback Messages */}
      <AnimatePresence>
        {showFeedback && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 flex items-center justify-center z-50 pointer-events-none"
          >
            <div className={`text-8xl ${isCorrect ? 'animate-bounce' : 'animate-pulse'}`}>
              {isCorrect ? '✅' : '❌'}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}