
import React, { useState } from "react";
import { motion } from "framer-motion";

/**
 * ✅ FIXED: Universal text extraction that handles ALL formats
 */
function extractText(value) {
  if (typeof value === 'string') return value;
  if (typeof value === 'number') return String(value);
  if (!value) return '';
  
  if (typeof value === 'object') {
    const props = ['text', 'ans', 'ques', 'question', 'answer', 'displayText', 'value', 'content', 'label'];
    for (const prop of props) {
      if (value[prop]) {
        const extracted = extractText(value[prop]);
        if (extracted) return extracted;
      }
    }
  }
  
  return '';
}

/**
 * ✅ FIXED: Parse matching pairs with comprehensive logging
 */
function parseMatchingPairs(options) {
  console.log('🔍 ============ MATCHING PAIRS DEBUG ============');
  console.log('🔍 Raw options:', JSON.stringify(options, null, 2));
  
  if (!options || !Array.isArray(options)) {
    console.error('❌ Invalid options - not an array:', options);
    console.log('🔍 ============ END DEBUG ============');
    return [];
  }
  
  if (options.length === 0) {
    console.error('❌ Empty options array');
    console.log('🔍 ============ END DEBUG ============');
    return [];
  }
  
  console.log(`📊 Processing ${options.length} options`);
  const firstOption = options[0];
  console.log('🔍 First option keys:', Object.keys(firstOption));
  console.log('🔍 First option:', JSON.stringify(firstOption, null, 2));
  
  const pairs = [];
  
  // FORMAT 1: Base44 STRING format (matching_answer is a string)
  if (firstOption.matching_answer && typeof firstOption.matching_answer === 'string') {
    console.log('✅ Detected BASE44 STRING format');
    options.forEach((option, index) => {
      const leftText = extractText(option.ans);
      const rightText = extractText(option.matching_answer);
      
      console.log(`Pair ${index}: "${leftText}" <-> "${rightText}"`);
      
      if (leftText && rightText) {
        pairs.push({ id: `pair_${index}`, left: leftText, right: rightText });
      }
    });
    console.log(`✅ Extracted ${pairs.length} pairs`);
    console.log('Final pairs:', JSON.stringify(pairs, null, 2));
    console.log('🔍 ============ END DEBUG ============');
    return pairs;
  }
  
  // FORMAT 2: HealthQuest OBJECT format (matching_answer has answerId/group)
  if (firstOption.matching_answer && typeof firstOption.matching_answer === 'object') {
    console.log('✅ Detected OBJECT format matching_answer');
    console.log('matching_answer structure:', JSON.stringify(firstOption.matching_answer, null, 2));
    
    if (firstOption.matching_answer.answerId) {
      console.log('✅ Has answerId - using HealthQuest format');
      const pairsMap = {};
      
      options.forEach((option) => {
        if (!option.matching_answer?.answerId) return;
        
        const answerId = option.matching_answer.answerId;
        const group = option.matching_answer.group;
        const text = extractText(option.ans);
        
        console.log(`Processing: answerId=${answerId}, group=${group}, text="${text}"`);
        
        if (!pairsMap[answerId]) {
          pairsMap[answerId] = { id: answerId };
        }
        
        if (group === 'left') {
          pairsMap[answerId].left = text;
        } else if (group === 'right') {
          pairsMap[answerId].right = text;
        }
      });
      
      const extracted = Object.values(pairsMap).filter(pair => pair.left && pair.right);
      console.log(`✅ Extracted ${extracted.length} pairs from HealthQuest format`);
      console.log('Pairs:', JSON.stringify(extracted, null, 2));
      console.log('🔍 ============ END DEBUG ============');
      return extracted;
    }
  }
  
  // FORMAT 3: Nested object format (ques/ans)
  if (firstOption.ques || firstOption.ans) {
    console.log('✅ Detected NESTED OBJECT format');
    options.forEach((option, index) => {
      const leftText = extractText(option.ques || option.question);
      const rightText = extractText(option.ans || option.answer);
      
      console.log(`Pair ${index}: "${leftText}" <-> "${rightText}"`);
      
      if (leftText && rightText) {
        pairs.push({ id: `pair_${index}`, left: leftText, right: rightText });
      }
    });
    console.log(`✅ Extracted ${pairs.length} pairs`);
    console.log('Final pairs:', JSON.stringify(pairs, null, 2));
    console.log('🔍 ============ END DEBUG ============');
    return pairs;
  }
  
  // FORMAT 4: Fallback
  console.log('⚠️ No known format detected - trying fallback extraction');
  options.forEach((option, index) => {
    console.log(`Option ${index}:`, JSON.stringify(option, null, 2));
    
    const possibleLefts = [option.ques, option.question, option.left, option.q];
    const possibleRights = [option.ans, option.answer, option.right, option.a, option.matching_answer];
    
    let leftText = '';
    let rightText = '';
    
    for (const left of possibleLefts) {
      if (left) {
        leftText = extractText(left);
        if (leftText) break;
      }
    }
    
    for (const right of possibleRights) {
      if (right) {
        rightText = extractText(right);
        if (rightText) break;
      }
    }
    
    console.log(`Fallback pair ${index}: "${leftText}" <-> "${rightText}"`);
    
    if (leftText && rightText) {
      pairs.push({ id: `pair_${index}`, left: leftText, right: rightText });
    }
  });
  
  console.log(`✅ Fallback extracted ${pairs.length} pairs`);
  console.log('Final pairs:', JSON.stringify(pairs, null, 2));
  console.log('🔍 ============ END DEBUG ============');
  
  return pairs;
}

function generateDistractorBubbles(count = 25) {
  const colors = ['#66bfad', '#ffa400', '#00d1ff', '#2563eb'];
  const bubbles = [];
  
  for (let i = 0; i < count; i++) {
    bubbles.push({
      id: `distractor-${i}`,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: 60 + Math.random() * 200,
      color: colors[Math.floor(Math.random() * colors.length)],
      duration: 8 + Math.random() * 20,
      delay: Math.random() * 6
    });
  }
  
  return bubbles;
}

export default function MatchingBubbleGame({ lessonData, gameConfig, onComplete, onExit }) {
  console.log('🎮 MatchingBubbleGame received lessonData:', lessonData);
  
  // ✅ FIXED: Properly extract question data from multiple possible structures
  let currentQ = null;
  let questionText = '';
  
  // Structure 1: questions array (MCQ format adapted for matching)
  if (lessonData?.questions && Array.isArray(lessonData.questions) && lessonData.questions.length > 0) {
    currentQ = lessonData.questions[0];
    questionText = currentQ.question || currentQ.questionText || '';
    console.log('✅ Using questions[0] format');
  }
  // Structure 2: Root-level question data (direct matching format)
  else if (lessonData?.question && lessonData?.options) {
    currentQ = {
      question: lessonData.question,
      options: lessonData.options,
      type: lessonData.type
    };
    questionText = lessonData.question;
    console.log('✅ Using root-level question format');
  }
  // Structure 3: Fallback to lessonData itself
  else {
    currentQ = lessonData;
    questionText = lessonData?.question || lessonData?.questionText || 'Match the pairs!';
    console.log('⚠️ Using lessonData directly as fallback');
  }
  
  console.log('📋 Current question:', currentQ);
  console.log('📝 Question text:', questionText);
  console.log('🎯 Options to parse:', currentQ?.options);
  
  const pairs = React.useMemo(() => {
    const options = currentQ?.options || [];
    console.log('🔄 Parsing options:', options);
    return parseMatchingPairs(options);
  }, [currentQ]);

  console.log(`🎮 MatchingBubbleGame initialized with ${pairs.length} pairs`);

  const [matchedPairs, setMatchedPairs] = useState([]);
  const [selectedBubble, setSelectedBubble] = useState(null);
  const [wrongMatch, setWrongMatch] = useState(null);
  const [distractorBubbles] = useState(generateDistractorBubbles());

  // Error screen with HealthQuest branding
  if (pairs.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-cyan-50 via-blue-50 to-teal-50 p-4">
        <div className="bg-white p-6 md:p-8 rounded-3xl shadow-2xl border-4 border-[#00d1ff] max-w-2xl w-full mx-4">
          <div className="text-center mb-6">
            <div className="w-20 h-20 md:w-24 md:h-24 mx-auto mb-4 bg-gradient-to-br from-[#66bfad] to-[#00d1ff] rounded-full flex items-center justify-center shadow-lg">
              <span className="text-4xl md:text-5xl">🎮</span>
            </div>
            <h2 className="text-2xl md:text-3xl font-bold text-[#2563eb] mb-3">Oops! No Matching Pairs Found</h2>
            <p className="text-gray-600 text-base md:text-lg mb-4">
              We couldn't load the matching pairs for this lesson.
            </p>
          </div>
          
          <div className="bg-gradient-to-br from-[#66bfad]/10 to-[#00d1ff]/10 p-4 md:p-6 rounded-2xl mb-6">
            <p className="text-gray-700 text-center mb-3 font-semibold">
              What you can do:
            </p>
            <ul className="text-gray-600 space-y-2 text-sm md:text-base">
              <li className="flex items-start">
                <span className="text-[#66bfad] mr-2 text-xl">•</span>
                <span>Go back and try a different lesson</span>
              </li>
              <li className="flex items-start">
                <span className="text-[#ffa400] mr-2 text-xl">•</span>
                <span>Check your internet connection</span>
              </li>
              <li className="flex items-start">
                <span className="text-[#00d1ff] mr-2 text-xl">•</span>
                <span>Contact support if the problem continues</span>
              </li>
            </ul>
          </div>

          <details className="mb-6">
            <summary className="cursor-pointer font-semibold text-sm md:text-base text-gray-700 bg-gray-100 p-3 md:p-4 rounded-xl hover:bg-gray-200 transition-colors">
              🔍 Technical Details
            </summary>
            <div className="mt-4 bg-gray-50 p-3 md:p-4 rounded-xl">
              <p className="text-xs md:text-sm text-gray-600 mb-2">
                Open browser console (F12) for detailed logs
              </p>
              <pre className="text-xs overflow-auto max-h-48 md:max-h-64 bg-white p-2 md:p-3 rounded-lg border border-gray-200">
                {JSON.stringify(currentQ?.options, null, 2)}
              </pre>
            </div>
          </details>

          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <button 
              onClick={onExit} 
              className="w-full sm:w-auto px-6 md:px-8 py-3 md:py-4 bg-gradient-to-r from-[#66bfad] to-[#00d1ff] text-white rounded-full font-bold text-base md:text-lg shadow-lg hover:shadow-xl hover:scale-105 transition-all"
            >
              ← Go Back
            </button>
            <button 
              onClick={() => window.location.reload()} 
              className="w-full sm:w-auto px-6 md:px-8 py-3 md:py-4 bg-gradient-to-r from-[#ffa400] to-[#ff8800] text-white rounded-full font-bold text-base md:text-lg shadow-lg hover:shadow-xl hover:scale-105 transition-all"
            >
              🔄 Reload
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Separate left and right bubbles with NON-OVERLAPPING positioning
  const leftBubbles = pairs.map((pair, index) => ({
    id: `${pair.id}_left`,
    pairId: pair.id,
    text: pair.left,
    side: 'left',
    matched: matchedPairs.includes(pair.id),
    // Non-overlapping positioning for desktop (left 35% of screen)
    x: 5 + (index % 2) * 15 + Math.random() * 8, // 5-28% - prevents overlap
    y: 5 + (index * 18) + Math.random() * 5, // Spread vertically with buffer
  }));

  const rightBubbles = [...pairs]
    .sort(() => Math.random() - 0.5)
    .map((pair, index) => ({
      id: `${pair.id}_right`,
      pairId: pair.id,
      text: pair.right,
      side: 'right',
      matched: matchedPairs.includes(pair.id),
      // Non-overlapping positioning for desktop (right 35% of screen)
      x: 65 + (index % 2) * 15 + Math.random() * 8, // 65-88% - prevents overlap
      y: 5 + (index * 18) + Math.random() * 5, // Spread vertically with buffer
    }));

  const handleBubbleClick = (bubble) => {
    if (bubble.matched) return;
    
    if (!selectedBubble) {
      setSelectedBubble(bubble);
    } else {
      if (selectedBubble.pairId === bubble.pairId && selectedBubble.id !== bubble.id) {
        setMatchedPairs([...matchedPairs, bubble.pairId]);
        
        if (matchedPairs.length + 1 === pairs.length) {
          setTimeout(() => {
            onComplete({
              correctAnswers: pairs.length,
              totalQuestions: pairs.length
            });
          }, 1000);
        }
      } else {
        setWrongMatch({ first: selectedBubble, second: bubble });
        setTimeout(() => setWrongMatch(null), 500);
      }
      setSelectedBubble(null);
    }
  };

  // Get bubble styling - exact MCQ colors
  const getBubbleStyle = (bubble, index, isSelected, isWrong) => {
    if (bubble.matched) {
      return 'bg-gray-300/30 opacity-30 cursor-not-allowed';
    }
    if (isSelected) {
      return 'bg-yellow-400 ring-4 md:ring-8 ring-yellow-300/50 scale-105 md:scale-110 shadow-2xl';
    }
    if (isWrong) {
      return 'bg-red-500 animate-shake';
    }
    
    if (bubble.side === 'left') {
      // Left side: Alternating Teal and Orange
      return index % 2 === 0 
        ? 'bg-[#66bfad] shadow-[0_4px_16px_rgba(102,191,173,0.4)] md:shadow-[0_8px_32px_rgba(102,191,173,0.4)] hover:shadow-[0_8px_24px_rgba(102,191,173,0.6)] md:hover:shadow-[0_12px_48px_rgba(102,191,173,0.6)]' 
        : 'bg-[#ffa400] shadow-[0_4px_16px_rgba(255,164,0,0.4)] md:shadow-[0_8px_32px_rgba(255,164,0,0.4)] hover:shadow-[0_8px_24px_rgba(255,164,0,0.6)] md:hover:shadow-[0_12px_48px_rgba(255,164,0,0.6)]';
    } else {
      // Right side: Alternating Cyan and Dark Blue
      return index % 2 === 0
        ? 'bg-[#00d1ff] shadow-[0_4px_16px_rgba(0,209,255,0.4)] md:shadow-[0_8px_32px_rgba(0,209,255,0.4)] hover:shadow-[0_8px_24px_rgba(0,209,255,0.6)] md:hover:shadow-[0_12px_48px_rgba(0,209,255,0.6)]'
        : 'bg-[#2563eb] shadow-[0_4px_16px_rgba(37,99,235,0.4)] md:shadow-[0_8px_32px_rgba(37,99,235,0.4)] hover:shadow-[0_8px_24px_rgba(37,99,235,0.6)] md:hover:shadow-[0_12px_48px_rgba(37,99,235,0.6)]';
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-gradient-to-br from-cyan-50 via-blue-50 to-teal-50">
      {/* Animated Distractor Bubbles - 25+ bubbles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {distractorBubbles.map((bubble) => (
          <motion.div
            key={bubble.id}
            className="absolute rounded-full border-2 border-white/20"
            style={{
              width: bubble.size,
              height: bubble.size,
              backgroundColor: bubble.color,
              opacity: 0.2,
              filter: 'blur(1px)',
              boxShadow: `0 4px 20px ${bubble.color}60, inset 0 2px 10px rgba(255,255,255,0.3)`,
              left: `${bubble.x}%`,
              top: `${bubble.y}%`,
            }}
            animate={{
              x: [0, Math.random() * 200 - 100, Math.random() * 150 - 75, 0],
              y: [0, Math.random() * 200 - 100, Math.random() * 150 - 75, 0],
              scale: [1, 1.4, 0.8, 1.2, 1],
              opacity: [0.2, 0.3, 0.15, 0.25, 0.2],
            }}
            transition={{
              duration: bubble.duration,
              repeat: Infinity,
              delay: bubble.delay,
              ease: "easeInOut",
            }}
          >
            {/* Inner shine effect on distractor bubbles */}
            <div 
              className="absolute inset-0 rounded-full"
              style={{
                background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.4), transparent 60%)',
              }}
            />
          </motion.div>
        ))}
      </div>

      {/* Game Content */}
      <div className="relative z-10 p-4 md:p-8 max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white/95 backdrop-blur-sm rounded-2xl md:rounded-3xl p-4 md:p-6 shadow-2xl border-2 md:border-4 border-[#00d1ff] mb-6 md:mb-8">
          <h2 className="text-xl md:text-3xl font-bold text-[#00d1ff] text-center mb-2">
            {questionText}
          </h2>
          <p className="text-center text-gray-600 text-base md:text-xl font-semibold">
            Matched: {matchedPairs.length} / {pairs.length}
          </p>
        </div>

        {/* Hybrid Layout - Scattered on Desktop, Columns on Mobile */}
        <div className="relative">
          {/* Desktop: Scattered positioning - NO OVERLAP */}
          <div className="hidden md:block relative min-h-[800px]">
            {/* Left bubbles - scattered in left half */}
            {leftBubbles.map((bubble, index) => {
              const isSelected = selectedBubble?.id === bubble.id;
              const isWrong = wrongMatch?.first?.id === bubble.id || wrongMatch?.second?.id === bubble.id;
              
              return (
                <motion.button
                  key={bubble.id}
                  className={`absolute w-[180px] h-[180px] rounded-full font-bold text-white text-base transition-all border-4 border-white/30 backdrop-blur-sm ${getBubbleStyle(bubble, index, isSelected, isWrong)}`}
                  style={{
                    left: `${bubble.x}%`,
                    top: `${bubble.y}%`,
                  }}
                  onClick={() => handleBubbleClick(bubble)}
                  disabled={bubble.matched}
                  whileHover={{ scale: bubble.matched ? 1 : 1.05 }}
                  whileTap={{ scale: bubble.matched ? 1 : 0.95 }}
                  animate={{
                    y: [0, -8, 0],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    delay: index * 0.2,
                    ease: "easeInOut",
                  }}
                >
                  {/* Shine effect */}
                  <div className="absolute inset-0 rounded-full bg-gradient-to-br from-white/40 via-transparent to-transparent opacity-50" />
                  
                  <span className="relative flex items-center justify-center h-full text-center leading-tight drop-shadow-lg px-4">
                    {bubble.text}
                  </span>
                </motion.button>
              );
            })}

            {/* Right bubbles - scattered in right half */}
            {rightBubbles.map((bubble, index) => {
              const isSelected = selectedBubble?.id === bubble.id;
              const isWrong = wrongMatch?.first?.id === bubble.id || wrongMatch?.second?.id === bubble.id;
              
              return (
                <motion.button
                  key={bubble.id}
                  className={`absolute w-[180px] h-[180px] rounded-full font-bold text-white text-base transition-all border-4 border-white/30 backdrop-blur-sm ${getBubbleStyle(bubble, index, isSelected, isWrong)}`}
                  style={{
                    left: `${bubble.x}%`,
                    top: `${bubble.y}%`,
                  }}
                  onClick={() => handleBubbleClick(bubble)}
                  disabled={bubble.matched}
                  whileHover={{ scale: bubble.matched ? 1 : 1.05 }}
                  whileTap={{ scale: bubble.matched ? 1 : 0.95 }}
                  animate={{
                    y: [0, -8, 0],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    delay: index * 0.3,
                    ease: "easeInOut",
                  }}
                >
                  {/* Shine effect */}
                  <div className="absolute inset-0 rounded-full bg-gradient-to-br from-white/40 via-transparent to-transparent opacity-50" />
                  
                  <span className="relative flex items-center justify-center h-full text-center leading-tight drop-shadow-lg px-4">
                    {bubble.text}
                  </span>
                </motion.button>
              );
            })}
          </div>

          {/* Mobile: Structured columns */}
          <div className="grid grid-cols-1 md:hidden gap-4">
            {/* LEFT COLUMN - Questions */}
            <div className="flex flex-col gap-3 items-center">
              {leftBubbles.map((bubble, index) => {
                const isSelected = selectedBubble?.id === bubble.id;
                const isWrong = wrongMatch?.first?.id === bubble.id || wrongMatch?.second?.id === bubble.id;
                
                return (
                  <motion.button
                    key={bubble.id}
                    className={`relative w-full max-w-[200px] aspect-square rounded-full font-bold text-white text-sm transition-all border-2 border-white/30 backdrop-blur-sm ${getBubbleStyle(bubble, index, isSelected, isWrong)}`}
                    onClick={() => handleBubbleClick(bubble)}
                    disabled={bubble.matched}
                    whileHover={{ scale: bubble.matched ? 1 : 1.05 }}
                    whileTap={{ scale: bubble.matched ? 1 : 0.95 }}
                    animate={{
                      y: [0, -8, 0],
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      delay: index * 0.2,
                      ease: "easeInOut",
                    }}
                  >
                    {/* Shine effect */}
                    <div className="absolute inset-0 rounded-full bg-gradient-to-br from-white/40 via-transparent to-transparent opacity-50" />
                    
                    <span className="relative block text-center leading-tight drop-shadow-lg flex items-center justify-center h-full p-2">
                      {bubble.text}
                    </span>
                  </motion.button>
                );
              })}
            </div>

            {/* RIGHT COLUMN - Answers */}
            <div className="flex flex-col gap-3 items-center">
              {rightBubbles.map((bubble, index) => {
                const isSelected = selectedBubble?.id === bubble.id;
                const isWrong = wrongMatch?.first?.id === bubble.id || wrongMatch?.second?.id === bubble.id;
                
                return (
                  <motion.button
                    key={bubble.id}
                    className={`relative w-full max-w-[200px] aspect-square rounded-full font-bold text-white text-sm transition-all border-2 border-white/30 backdrop-blur-sm ${getBubbleStyle(bubble, index, isSelected, isWrong)}`}
                    onClick={() => handleBubbleClick(bubble)}
                    disabled={bubble.matched}
                    whileHover={{ scale: bubble.matched ? 1 : 1.05 }}
                    whileTap={{ scale: bubble.matched ? 1 : 0.95 }}
                    animate={{
                      y: [0, -8, 0],
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      delay: index * 0.3,
                      ease: "easeInOut",
                    }}
                  >
                    {/* Shine effect */}
                    <div className="absolute inset-0 rounded-full bg-gradient-to-br from-white/40 via-transparent to-transparent opacity-50" />
                    
                    <span className="relative block text-center leading-tight drop-shadow-lg flex items-center justify-center h-full p-2">
                      {bubble.text}
                    </span>
                  </motion.button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* CSS for shake animation */}
      <style jsx>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-10px); }
          75% { transform: translateX(10px); }
        }
        .animate-shake {
          animation: shake 0.3s ease-in-out;
        }
      `}</style>
    </div>
  );
}
