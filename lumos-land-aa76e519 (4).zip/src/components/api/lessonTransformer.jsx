// Transformer to convert HealthQuest lessons to Lumo's Land format
export function transformHealthQuestLesson(hqLesson) {
  // Detect question type from first question
  let game_format = 'mcq';
  if (hqLesson.questions && hqLesson.questions.length > 0) {
    const firstQ = hqLesson.questions[0];
    if (firstQ.type === 'match') {
      game_format = 'matching';
    } else if (firstQ.type === 'likert') {
      game_format = 'likert';
    }
  }

  // For matching games: KEEP HealthQuest format exactly as-is
  // Only add game_style field
  if (game_format === 'matching') {
    return {
      ...hqLesson,
      quest: hqLesson.quest_id || hqLesson.quest || 'imported',
      number: hqLesson.lesson_number || hqLesson.number || 1,
      name: hqLesson.title || hqLesson.name,
      game_format: 'matching',
      game_style: hqLesson.game_style || 'matching_cards',
      is_active: hqLesson.is_active !== false
    };
  }

  // For MCQ/Likert: Transform as before
  const transformedQuestions = (hqLesson.questions || []).map(q => ({
    question: q.question || q.prompt,
    type: q.type || 'multiple_choice',
    options: q.options || q.choices || [],
    answer: q.correct_answer || q.answer || 1
  }));

  return {
    quest: hqLesson.quest_id || hqLesson.quest || 'imported',
    number: hqLesson.lesson_number || hqLesson.number || 1,
    name: hqLesson.title || hqLesson.name,
    description: hqLesson.description || '',
    lessonText: hqLesson.intro_text || hqLesson.lessonText || '',
    game_format: game_format,
    game_style: hqLesson.game_style || 'bubble_pop',
    is_assessment: hqLesson.is_assessment || false,
    xp_reward: hqLesson.xp_reward || 50,
    coins_reward: hqLesson.coins_reward || 50,
    coins_per_correct: hqLesson.coins_per_correct || 10,
    keyTakeaways: hqLesson.key_takeaways || hqLesson.keyTakeaways || '',
    is_active: hqLesson.is_active !== false,
    questions: transformedQuestions
  };
}

/**
 * Parse matching pairs from HealthQuest options array
 * Used by game components to convert HealthQuest format to pairs
 */
export function parseMatchingPairs(options) {
  const pairs = {};
  
  options.forEach(option => {
    const answerId = option.matching_answer.answerId;
    const group = option.matching_answer.group;
    
    if (!pairs[answerId]) {
      pairs[answerId] = { id: answerId };
    }
    
    pairs[answerId][group] = option.ans;
  });
  
  return Object.values(pairs).map(pair => ({
    id: pair.id,
    left: pair.left,
    right: pair.right
  }));
}

/**
 * Validate matching question format from HealthQuest
 */
export function validateMatchingQuestion(question) {
  if (question.type !== 'match') {
    throw new Error(`Expected type "match", got "${question.type}"`);
  }
  
  if (!Array.isArray(question.options)) {
    throw new Error('Matching question must have "options" array');
  }
  
  question.options.forEach((option, index) => {
    if (!option.ans) {
      throw new Error(`Option ${index} missing "ans" field`);
    }
    
    if (!option.matching_answer) {
      throw new Error(`Option ${index} missing "matching_answer" object`);
    }
    
    if (!option.matching_answer.answerId) {
      throw new Error(`Option ${index} missing "answerId"`);
    }
    
    if (!['left', 'right'].includes(option.matching_answer.group)) {
      throw new Error(`Option ${index} has invalid group "${option.matching_answer.group}"`);
    }
  });
  
  const pairs = {};
  question.options.forEach(option => {
    const id = option.matching_answer.answerId;
    const group = option.matching_answer.group;
    
    if (!pairs[id]) {
      pairs[id] = { left: false, right: false };
    }
    pairs[id][group] = true;
  });
  
  Object.keys(pairs).forEach(id => {
    if (!pairs[id].left || !pairs[id].right) {
      throw new Error(`Incomplete pair for answerId "${id}"`);
    }
  });
  
  return true;
}